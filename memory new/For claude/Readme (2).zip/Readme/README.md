# Archi QC LINE System — Build Package

ระบบ QC อัตโนมัติผ่าน LINE OA สำหรับงานก่อสร้าง/รีโนเวท

```
LINE OA  →  n8n  →  Hub (/api/qc/ingest)  →  OpenAI Vision  →  Supabase
                                   ↓
                            Hub response
                                   ↓
                            n8n → LINE Reply API (reply token)
```

---

## โครงไฟล์

```
qc-line-system/
├── 01-sql/
│   └── 001_init_qc.sql            # schema + seed
├── 02-n8n/
│   └── wf_qc_line.json            # import ลง n8n ได้เลย
├── 03-hub/
│   ├── package.json
│   ├── server.example.js          # ตัวอย่าง bootstrap
│   ├── routes/qc.js               # /api/qc/ingest /list /log-latency
│   └── services/
│       ├── qcRepo.js              # ทุก DB call
│       └── qcAi.js                # OpenAI vision call
├── 04-env/
│   └── .env.example
└── README.md
```

---

## ลำดับการ deploy (ประมาณ 2 ชั่วโมง ถ้าทุกอย่างพร้อม)

### 1. Supabase/Postgres — รัน migration

```bash
psql "$DATABASE_URL" -f 01-sql/001_init_qc.sql
# หรือใน Supabase: SQL Editor → paste → Run
```

เช็ค: `select count(*) from sites;` ควรได้ 3

### 2. Storage — เตรียม bucket สำหรับรูป QC

เลือกอย่างใดอย่างหนึ่ง:
- **Supabase Storage:** สร้าง bucket `qc-photos` (public read), เก็บ service role key
- **Cloudflare R2:** สร้าง bucket `archi-qc`, สร้าง API token PUT-only, ตั้ง custom domain public

ได้ค่ามา 2 ตัว:
- `STORAGE_UPLOAD_URL` — endpoint ที่ PUT ไฟล์ขึ้นได้
- `STORAGE_PUBLIC_URL` — base URL ที่คนทั่วไปเปิดรูปได้

### 3. Hub — ติดตั้ง QC module

```bash
cd 03-hub
npm install
cp ../04-env/.env.example .env
# แก้ .env เติมค่าจริง
npm run dev          # ทดสอบแยกก่อน port 4000
curl http://localhost:4000/api/qc/health
```

ถ้า Archi Hub มี server อยู่แล้ว: copy `routes/` และ `services/` ไปรวมกับ codebase เดิม แล้วเพิ่มบรรทัดเดียว:

```js
app.use('/api/qc', require('./routes/qc'));
```

### 4. LINE OA — สร้าง channel

1. [LINE Developers](https://developers.line.biz) → Provider → Create Messaging API channel
2. เก็บ `Channel secret` และ `Channel access token (long-lived)`
3. เปิด "Use webhook" = ON, กรอก `https://<n8n-domain>/webhook/qc-line`
4. ปิด "Auto-reply messages" และ "Greeting messages" (จะรบกวน)

### 5. n8n — import workflow

1. n8n UI → Workflows → Import from File → `02-n8n/wf_qc_line.json`
2. สร้าง Credentials 3 ตัว:
   - `line-messaging-bearer`: Authorization = `Bearer <LINE_CHANNEL_ACCESS_TOKEN>`
   - `storage-bearer`: Authorization = `Bearer <STORAGE_TOKEN>`
   - `hub-internal`: X-Hub-Key = `<HUB_INTERNAL_KEY>` (ค่าเดียวกับ Hub .env)
3. ตั้ง Environment Variables ใน n8n:
   - `LINE_CHANNEL_SECRET`, `HUB_URL`, `STORAGE_UPLOAD_URL`, `STORAGE_PUBLIC_URL`
4. Activate workflow

### 6. Smoke test

- เพิ่มเพื่อน LINE OA ด้วย QR code
- ส่งข้อความ "BKK-045" + รูปผนังฉาบ
- คาดหวัง: ตอบกลับภายใน ~15 วินาที พร้อมสรุป defect

ตรวจ:
```sql
select line_message_id, pass, severity, ai_summary, latency_ms
from qc_inspections
order by created_at desc limit 5;
```

---

## Test ด้วย curl (bypass LINE ทดสอบ Hub แยก)

```bash
# รูปทดสอบต้องเข้าถึงได้จาก internet (OpenAI จะไปโหลด)
curl -X POST http://localhost:4000/api/qc/ingest \
  -H 'Content-Type: application/json' \
  -H "X-Hub-Key: $HUB_INTERNAL_KEY" \
  -d '{
    "line_message_id": "test-001",
    "line_user_id":    "Utest",
    "photo_url":       "https://example.com/wall.jpg",
    "caption":         "BKK-045 ห้องน้ำชั้น2"
  }'
```

คาดหวัง response:
```json
{
  "inspection_id": "…",
  "site_code": "BKK-045",
  "pass": false,
  "severity": "medium",
  "ai_summary": "...",
  "defects": [...]
}
```

---

## Acceptance Gate (ต้องผ่านก่อน rollout)

- [ ] A1: ส่งรูป → reply ภายใน 15s (p95) จาก 20 การทดสอบ
- [ ] A2: `qc_inspections.status = 'done'` ทุก case ที่ไม่ error
- [ ] A3: Dashboard query `/api/qc/list` แสดงภายใน 30s
- [ ] A4: ส่งรูปเดิมซ้ำ → response `duplicate:true` ไม่เกิด record ซ้ำ
- [ ] A5: รูป off-topic (แมว, สวน, เซลฟี่) → `pass:true severity:none` ไม่ hallucinate
- [ ] A6: LINE signature ผิด → n8n execution fail + no DB write
- [ ] A7: ปิด OpenAI API (set wrong key) → Hub ตอบ 502 + record status='failed'
- [ ] A8: Network tab ใน Dashboard ไม่มี request ไป `api.line.me` หรือ `openai.com` ตรง

---

## Debug cheat sheet

| อาการ | จุดตรวจ |
|---|---|
| LINE ไม่ยิงเข้า n8n | LINE Console > Webhook verify; n8n webhook URL เป็น HTTPS; Use webhook = ON |
| n8n รัน แต่ verify fail | channel secret ถูก channel ใช่ไหม (OA มีหลาย channel ได้) |
| ดาวน์โหลดรูปได้ 401 | ใช้ Channel Access Token ไม่ใช่ LIFF token; endpoint = `api-data.line.me` |
| Hub 502 `ai_failed` | ดู `qc_inspections.error_message`; check OPENAI_API_KEY + quota |
| Response ช้า >15s | ดู `latency_ms`; ถ้า AI เกิน 10s พิจารณา downscale image หรือใช้ `detail: 'low'` |
| AI ตอบ JSON ไม่ถูก | เปิด `ai_raw` ดู raw response; ตรวจว่าใช้ `response_format: json_object` |
| Reply token expired | reply token หมดอายุ 1 นาที → ถ้า AI ช้า ให้ fallback เป็น push message ใช้ `line_user_id` |
| Dashboard เงียบ | ตรวจ X-Hub-Key ใน request header |

---

## Cost projection

| Scenario | รูป/วัน | ต้นทุน/เดือน (บาท) |
|---|---|---|
| Pilot 2 ไซต์ | 30 | ~270 |
| 10 ไซต์ production | 150 | ~1,350 |
| 30 ไซต์ scale | 450 | ~4,050 |

*(คิดที่ GPT-4o vision, high detail, ~2500 tokens/รูป. เปลี่ยนเป็น gpt-4o-mini ลดได้ ~70% แต่ precision ลง ~10–15%)*

---

## ทำอะไรต่อได้บ้าง (phase 2)

1. **Flex Message** — ทำ reply ให้เป็นการ์ดสวย (ใช้ n8n Function node สร้าง Flex JSON แล้วเรียก reply API เหมือนเดิม)
2. **Dashboard QC page** — ฝั่ง Frontend ของ Archi Dashboard เรียก `/api/qc/list` มาแสดงตาราง + filter
3. **Auto-assign PM** — ถ้า severity=high → push แจ้ง PM channel ด้วย ใช้ LINE push message
4. **Eval set** — เก็บรูป labelled 100 รูป (pass/fail, defect categories) รัน regression ทุกครั้งที่ปรับ prompt
5. **Voice note ด้วย** — รับ `message.type=audio` ส่งเข้า Whisper → ต่อเข้า flow เดียวกัน เพิ่ม caption จากเสียง
