# Production Runtime Map

Status: Phase 0.5 discovery only
Date: 2026-07-27

## Scope Guard

No runtime code, database schema, environment variables, deployment configuration, or n8n workflows were modified.

This document uses repository evidence only. It does not confirm live production state.

## Current Production Frontend URL

| Candidate | Evidence | Status |
| --- | --- | --- |
| `https://ap-home-platform.vercel.app` | Exported workflow JSON in `scripts/Finnhouses - Market Intelligence Collector v1*.json` calls `https://ap-home-platform.vercel.app/api/chat`. | Needs Production Verification |
| `https://YOUR-APP.vercel.app` | Placeholder in `DEPLOY_RAILWAY.md`. | Template only |
| `https://ap-home.vercel.app` | Placeholder/proxy example in `docs/hub-v2/03-api-contract.txt` and `services/backend-hub/.env.example`. | Needs Production Verification |

Repository-supported assumption:

- Frontend is deployed on Vercel.
- Exact current production frontend URL is not conclusively confirmed from repository files.

## Current Production Backend / Hub URL

| Candidate | Evidence | Status |
| --- | --- | --- |
| `https://ap-home-platform-production.up.railway.app` | Fallback in `components/AIContent.tsx`; session docs mention Railway/Hub v1. | Needs Production Verification |
| `https://YOUR-REAL-HUB.up.railway.app` | Deployment template in `DEPLOY_RAILWAY.md`. | Template only |
| `https://your-hub.up.railway.app` | Placeholder in `services/backend-hub/.env.example`. | Template only |
| Hub v1 Railway service | `docs/context_brief.md` says Hub v2 cutover was reverted and Hub v1 is production. | Needs live confirmation |
| Hub v2 Railway service | `memory/n8n-workflows/README.md` lists Hub v2 endpoints as active. | Conflicts with `docs/context_brief.md` |

Repository-supported assumption:

- Backend Hub is expected to run on Railway.
- Active Hub version is unresolved from repository evidence alone.

## Active API Ownership

### Next API Routes

| Route Family | Current Owner From Code | Backend Target | Status |
| --- | --- | --- | --- |
| `/api/leads*` | Next API route | Supabase REST via `SUPABASE_SERVICE_KEY` | Active in repo; needs production traffic verification |
| `/api/deals*` | Next API route | Supabase REST via `SUPABASE_SERVICE_KEY` | Active in repo; needs production traffic verification |
| `/api/projects` | Next API route | Supabase REST via `SUPABASE_SERVICE_KEY` | Active in repo; needs production traffic verification |
| `/api/chat` | Next API route | Anthropic + Supabase `content_frames` | Active in repo; external workflow exports reference it |
| `/api/ai` | Next API route | Anthropic | Active in repo |
| `/api/image` | Next API route | OpenAI, Gemini, Ideogram | Active in repo |
| `/api/market-intel*` | Next API routes | n8n webhook and Supabase service-role report/feedback routes | Active in repo |
| `/api/qc/accuracy` | Next API route | Supabase `qc_inspections` via service role | Active in repo |
| `/api/quality-gate*` | Next API routes | Supabase `quality_gate_log` via service role | Active in repo |
| `/api/content/performance` | Next API route | Supabase `content_posts`, `post_performance` via service role | Active in repo |
| `/api/blog*` | Next proxy routes | Hub v1-style `/action/blog*` and `/api/state` | Active in repo; target version needs verification |
| `/api/fb*` | Next proxy routes | Hub v1-style `/action/fb*` or FB backend `/api/fb/publish` | Active in repo |
| `/api/property*` | Next proxy routes | Hub v1-style `/action/property*` and `/api/properties*` | Active in repo |
| `/api/ops*` | Next proxy routes | Hub `/api/ops*` | Active in repo |
| `/api/n8n` | Next API route | n8n API `/api/v1/workflows` | Active in repo; should be protected/reviewed |
| `/api/telegram` | Next API route | Telegram Bot API | Active in repo; should be protected/reviewed |
| `/webhook/n8n` | Next proxy route | Hub `/webhook/n8n` | Active in repo |

### Backend Hub Routes

| Hub Implementation | Routes | Evidence | Status |
| --- | --- | --- | --- |
| Hub v1 `services/backend-hub/server.cjs` | `/api/state`, `/api/ops/*`, `/action/blog/*`, `/action/fb/*`, `/action/property/*`, `/api/properties/*`, `/api/qc/*`, `/webhook/n8n` | Source file and `docs/context_brief.md`. | Likely production, needs live confirmation |
| Hub v2 `services/backend-hub/src/server.ts` | `/api/health`, `/api/qc`, `/api/blog`, `/api/state`, optional `/api/fb`, `/webhook/n8n` | Source files and `.env.example`. | Shadow/new architecture candidate; production status unknown |

### External Services

| Service | Evidence | Current Use | Status |
| --- | --- | --- | --- |
| Supabase | `.env.local.example`, `services/backend-hub/.env.example`, Next API routes, Hub source | Data layer; service-role access in Next and Hub | Project identity needs production confirmation |
| Anthropic | `/api/chat`, `/api/ai`, Hub v2 providers | Text generation | Active in repo |
| OpenAI | `/api/image`, Hub v1 QC vision, Hub v2 provider | Image/QC/AI operations | Active in repo |
| Gemini | `/api/image`, Hub v2 provider | Image fallback | Active in repo |
| Ideogram | `/api/image` | Image generation option | Active in repo |
| n8n | `memory/n8n-workflows`, Next proxy routes, Hub routes | Blog/market automation | Live inventory pending |
| FB backend | `services/fb-backend/server.js`, `/api/fb/publish` | Facebook Graph publishing | Active in repo |
| WordPress | Hub property/blog routes and examples | Blog/property publishing | Active in repo |
| Telegram | `/api/telegram`, Hub notifier | Lead notifications | Active in repo |

## Production Environment Assumptions From Files Only

No secrets are exposed here.

| Environment Variable | Expected Runtime | Evidence | Status |
| --- | --- | --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | Vercel frontend | `.env.local.example`, README | Required; value unknown |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Vercel frontend | `.env.local.example`, README | Required; value unknown |
| `NEXT_PUBLIC_HUB_URL` | Vercel frontend/client | `.env.local.example`, README, comments | Public Hub URL; exact production value unknown |
| `HUB_URL` | Vercel server routes | `app/api/blog*`, `app/api/property*`, `app/api/ops*` | Required for proxies; value unknown |
| `HUB_SECRET` | Vercel server routes and Hub | Next proxy routes, Hub source | Must match Hub; value unknown |
| `SUPABASE_URL` | Next server routes and Hub | Next API routes, Hub source | Required; value unknown |
| `SUPABASE_SERVICE_KEY` | Next server routes and Hub | Next API routes, Hub source | Sensitive; should be removed from Dashboard after migration |
| `ANTHROPIC_API_KEY` | Next server routes and Hub | `/api/chat`, `/api/ai`, Hub source | Sensitive; target owner Hub |
| `OPENAI_API_KEY` | Next server routes and Hub | `/api/image`, Hub source | Sensitive; target owner Hub |
| `GEMINI_API_KEY` | Next server routes and Hub | `/api/image`, Hub source | Sensitive; target owner Hub |
| `IDEOGRAM_API_KEY` | Next server route | `/api/image` | Sensitive; target owner Hub |
| `N8N_MARKET_INTEL_WEBHOOK` | Vercel server routes | `/api/market-intel*` | Required for market-intel proxy; value unknown |
| `N8N_URL`, `N8N_API_KEY` | Vercel server route | `/api/n8n` | Admin API access; must be protected |
| `FB_BACKEND_URL` | Vercel server route and Hub | `/api/fb/publish`, Hub source | Required for FB publish; value unknown |
| `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` | Vercel server route and Hub | `/api/telegram`, Hub source | Sensitive; target owner Hub/notification service |

## Unknowns Requiring Manual Verification

- Exact production frontend URL.
- Exact production Backend Hub URL.
- Whether production is running Hub v1 `server.cjs`, Hub v2 `dist/server.js`, or both.
- Current Vercel environment variable values and whether `SUPABASE_SERVICE_KEY` and AI provider keys are present in Dashboard runtime.
- Current Railway service URLs for Hub, FB backend, and n8n.
- Live n8n active workflows, webhook URLs, credentials, and recent execution history.
- Supabase project reference used by production.
- Production backup status.
- Rollback procedure status.
- Browser network calls from the deployed Dashboard.

## Safety Conclusion

Repository evidence is not enough to approve ADR-006 implementation. Live production verification is required before moving from discovery to protected implementation.
