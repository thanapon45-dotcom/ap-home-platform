# Credentials & Token Registry — Finnhouses Platform

> ⚠️ ไฟล์นี้เก็บ **ที่อยู่** ของ token เท่านั้น — ห้ามเขียนค่า token จริงลงในไฟล์นี้

---

## 🔑 Facebook Page Token

| Field | Value |
|-------|-------|
| ชื่อ | FB_PAGE_TOKEN |
| เก็บที่ | Railway → Service: **easygoing-friendship** → Variables |
| หมดอายุทุก | ~60 วัน |
| อัปเดตล่าสุด | Jul 26, 2026 |
| **หมดอายุประมาณ** | **~Sep 24, 2026** |
| วิธี Renew | Graph API Explorer → User Token (pages_* permissions) → Access Token Debugger → Extend Access Token → `me/accounts` → copy Page token → ใส่ใน Railway easygoing-friendship → `FB_PAGE_ACCESS_TOKEN` |
| Permissions ที่ต้องมี | pages_show_list, business_management, pages_read_engagement, pages_manage_posts |

---

## 🚂 Railway Services

| Service | URL | หน้าที่ |
|---------|-----|---------|
| Backend Hub | ap-home-platform-production.up.railway.app | Express API, state, queue |
| FB Backend | easygoing-friendship-production-e663.up.railway.app | FB publish proxy |
| n8n | primary-production-8158a.up.railway.app | Automation workflows |

> Railway ไม่มีวันหมดอายุ — แต่ถ้า idle นาน service อาจ sleep ได้ถ้า plan ฟรี

---

## ▲ Vercel

| Field | Value |
|-------|-------|
| Project | ap-home-platform |
| URL | ap-home-platform.vercel.app |
| Env Vars | ตั้งที่ Vercel Dashboard → Settings → Environment Variables |
| Token หมดอายุ | ไม่หมด (connected via GitHub auto-deploy) |

---

## 🗃️ Supabase

| Field | Value |
|-------|-------|
| Project | ap-home-platform (ID: `omvpagvqyfmkkhzuuzda`, region: ap-south-1) |
| ค่าจริงเก็บที่ | `D:\ARCHI\01_PROJECTS\.keys\.env.local` |
| Vercel env vars | `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` |
| Railway Hub env vars | `SUPABASE_URL`, `SUPABASE_ANON_KEY` (ต้องเพิ่มใน Hub service) |
| Token หมดอายุ | anon key ไม่หมด (rotate manually ถ้าต้องการ) |
| วิธีดูค่า | Supabase Dashboard → Project Settings → API หรือดูที่ `.keys/.env.local` |
| **service_role key** | เก็บใน `.keys/.env.local` → `SUPABASE_SERVICE_ROLE_KEY=eyJ...` (Jun 7, 2026) |

---

## 📋 Checklist วิธี Renew FB Token (ทุก ~60 วัน)

1. ไปที่ [Meta Graph API Explorer](https://developers.facebook.com/tools/explorer/)
2. เลือก App: **Finnhouses**
3. คลิก **Generate Access Token** → เลือก **Page** (ไม่ใช่ User)
4. Copy token ที่ได้
5. ไปที่ Railway → Service **easygoing-friendship** → Variables
6. แก้ค่า `FB_PAGE_TOKEN` = token ใหม่
7. กด **Deploy** (หรือ Save แล้ว Redeploy)
8. อัปเดตวันใน **ไฟล์นี้** field "อัปเดตล่าสุด" + "หมดอายุประมาณ"

---

## 🔔 Reminder Schedule

| Token | Due Date | Action |
|-------|----------|--------|
| FB_PAGE_ACCESS_TOKEN | ~Sep 17, 2026 | Graph API Explorer long-lived flow → Railway easygoing-friendship |

> เมื่อใกล้ถึงวัน ให้บอก Claude: "FB token ใกล้หมดแล้ว ช่วย remind วิธี renew หน่อย"

---

## ⚠️ Jun 26 vs Aug 2 conflict — RESOLVED (session 25, Jul 16, 2026)

Section นี้ (อัปเดต Jun 3) บอก ~Aug 2, 2026 แต่ section "📁 Master Credentials File" ด้านล่าง (เศษจาก May 21 draft ที่ไม่เคยลบ) บอก Jun 26, 2026 — สองค่าขัดแย้งกันเอง

**ยืนยันแล้ว**: user โพสต์ผ่าน ListingTab สำเร็จจริงวันนี้ (16 Jul 2026) — ถ้า token หมดตั้งแต่ 26 Jun จะโพสต์ไม่ผ่านแน่นอน ข้อเท็จจริงนี้หักล้าง Jun 26 ทันที **สรุป: ~Aug 2, 2026 คือค่าที่ถูกต้อง** ตั้ง reminder จริงล่วงหน้าไว้ที่ ~25 Jul 2026 (1 สัปดาห์ก่อนหมด) อย่ารอให้หมดจริงแล้วค่อยแก้

---

---

## 📁 Master Credentials File

ค่า key จริงทั้งหมดเก็บใน `D:\ARCHI\01_PROJECTS\.keys\.env.local`  
ไม่ต้องหา key ที่อื่น — ดูที่ไฟล์นั้นไฟล์เดียว

| Key | ใช้ใน |
|-----|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | Vercel + Railway Hub (ชื่อ `SUPABASE_URL`) |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Vercel + Railway Hub (ชื่อ `SUPABASE_ANON_KEY`) |
| `ANTHROPIC_API_KEY` | Vercel server-side |
| `OPENAI_API_KEY` | Vercel server-side |
| `GEMINI_API_KEY` | Vercel server-side |
| `IDEOGRAM_API_KEY` | Railway Hub |
| `TELEGRAM_BOT_TOKEN` | Railway Hub |
| `FB_PAGE_ACCESS_TOKEN` | Railway easygoing-friendship (⚠️ Jun 26 ผิด — ดูหัวข้อ "Jun 26 vs Aug 2 conflict — RESOLVED" ด้านบน ค่าจริงคือ ~Aug 2, 2026) |

---

_Last updated: Jul 26, 2026 — FB_PAGE_ACCESS_TOKEN renewed (long-lived flow via Graph API Explorer), n8n credential `easygoing-friendship FB_PAGE_ACCESS_TOKEN` updated by Archi_
