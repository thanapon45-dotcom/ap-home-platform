# Finnhouses — Full Market Intelligence & Positioning Framework

---

## PART 1: แกนสำคัญของโปรเจกต์ (จาก Market Intelligence System)

โปรเจกต์นี้ไม่ใช่แค่เว็บประกาศขายบ้าน และไม่ใช่แค่ AI Automation

แต่คือ:
> "การเปลี่ยนความเข้าใจตลาดอสังหาฯ ให้กลายเป็นระบบที่จำ วิเคราะห์ และต่อยอดได้"

**Core Equation:**
- AI = Tool
- Market Understanding = Asset

**Asset ที่แท้จริง:**
- Market Memory
- Local Intuition
- Buyer Psychology
- Pricing Behavior
- Emotional Signal
- Liquidity Understanding

---

## PART 2: AI Market Positioning Layer

### 2.1 Buyer Psychology (3 ระดับ)

```
LEVEL 3 (ลึกสุด)  →  IDENTITY
                      "คนที่สร้างบ้านเองคือคนฉลาด ไม่ง้อโครงการ"

LEVEL 2 (กลาง)    →  EMOTION
                      "ปลอดภัย, ภูมิใจ, มั่นคง"

LEVEL 1 (ผิวนอก)  →  FEATURE
                      "3 ห้องนอน, วัสดุดี, ทำเลดี"
```

> คู่แข่งส่วนใหญ่สื่อสารแค่ Level 1
> ระบบ Finnhouses ต้องสื่อสาร Level 2–3

### 2.2 Buyer-Context Positioning (4 มิติ)

| มิติ | คำอธิบาย | ตัวอย่าง |
|---|---|---|
| Situational | อยู่ที่ไหน ทำอะไรอยู่ | เพิ่งแต่งงาน / มีที่ดินแล้ว |
| Timeline | อยู่ตรงไหนของ Journey | Awareness → Decision |
| Conversation | มี Trigger อะไร | เพื่อนสร้างบ้านเสร็จ / ดอกเบี้ยขึ้น |
| Problem-Awareness | รู้ตัวแค่ไหน | Unaware → Most Aware |

### 2.3 AI-assisted Market Framing

**Frame ที่แนะนำสำหรับ Finnhouses:**
> "การสร้างบ้านไม่ใช่เรื่องของผู้รับเหมา — มันคือการตัดสินใจทางการเงินที่สำคัญที่สุดในชีวิตคุณ"

Frame นี้เปลี่ยนบทบาท: จาก **ผู้รับเหมา** → **ที่ปรึกษาทางการเงิน/ชีวิต**

---

## PART 3: Intelligence Injection System

### 3.1 สี่ Layer ของ Market Intelligence

```
Layer 1: Search Intelligence    → Google Trends, Keyword gaps
Layer 2: Social Intelligence    → Pantip, FB Group, YouTube Comment
Layer 3: Competitor Intelligence → Content gaps, ไม่มีใครพูดเรื่องอะไร
Layer 4: Timing Intelligence    → ดอกเบี้ย, หน้าฝน, โบนัส, เปิดเทอม
```

### 3.2 Injection Framework

```
STEP 1  COLLECT SIGNAL     →  รวม Search + Social + Competitor data
STEP 2  IDENTIFY TENSION   →  สิ่งที่คนกังวล vs สิ่งที่เขาต้องการ
STEP 3  MATCH CONTENT TYPE →  Tension → Hook → Format → Channel
STEP 4  INJECT SPECIFICITY →  ตัวเลข, สถานที่, สถานการณ์จริง
STEP 5  PUBLISH AT PEAK    →  ยิง Content ตรงจังหวะ
```

### 3.3 Content Engine (Phase ปัจจุบัน → ต่อไป)

```
ตอนนี้:   AI Rewrite Listing → "Describe Property"
Phase 2:  AI-assisted Market Framing → "Position Property Inside Buyer Psychology"
```

ตัวอย่าง Framed Content:
- "บ้านนี้เหมาะกับ first jobber"
- "ต่ำกว่า 1.5 ล้านเริ่มหายาก"
- "คนทำงานรังสิต–ธัญบุรีน่าจะชอบ"
- "บ้าน modern CTR สูงในโซนนี้"

---

## PART 4: Human-AI Intelligence Architecture

### 4.1 System Flow

```
Facebook / Voice Note
        ↓
  Copy / AI Parse
        ↓
   Google Sheet
        ↓
    AI Parse
        ↓
   Supabase DB
        ↓
  Market Intelligence
        ↓
  Positioned Content → WordPress / FB / Line OA
```

### 4.2 Supabase Schema (ปัจจุบัน)

**fb_sellers**
- focus_area, listing_count, seller_type

**fb_listings**
- urgency, emotional_keywords, free_transfer
- negotiable, foreclosure_hint, installment

**fb_listing_history**
- price changes, relist behavior, liquidity signal

### 4.3 Table ที่ควรเพิ่ม (ต่อยอดจาก Positioning Layer)

**market_insights**
- area, village, insight, category, confidence, source_type

**area_memory** ← เชื่อม Buyer-Context โดยตรง
- area, memory, memory_type, confidence, validity

**buyer_context_signals** ← NEW (จาก Positioning Framework)
- trigger_type (ดอกเบี้ย / เพื่อนสร้างบ้าน / มีที่ดิน)
- awareness_level (unaware / problem-aware / solution-aware / most-aware)
- emotional_need (ปลอดภัย / ภูมิใจ / คุ้มค่า / อิสระ)
- content_angle (hook, message, channel)

**content_frames** ← NEW (จาก Market Framing)
- frame_text, target_context, engagement_score
- channel, publish_date, performance_data

---

## PART 5: ตัวอย่าง Area Memory จริง

| พื้นที่ | Memory | ประเภท |
|---|---|---|
| ลาดหลุมแก้ว | คนกลัวน้ำ | Risk Perception |
| รังสิต | Commuter demand สูง | Demand Pattern |
| คลองสาม | บ้าน Modern ปิดไว | Liquidity Signal |

---

## PART 6: Full Stack Intelligence Flow

```
DATA SOURCES              AI PROCESSING           OUTPUT
──────────────────────────────────────────────────────────
Google Trends       ──┐
Pantip / FB Groups  ──┤
Competitor Blog     ──┤  Claude + n8n   ──→  Content Brief
Voice Notes         ──┤  Analyze &           + Buyer Context
FB Listings         ──┤  Synthesize    ──→  + Frame Options
Area Observations   ──┘                ──→  + Posting Schedule
                                       ──→  + WordPress / FB
```

---

## PART 7: Role ที่ชัดเจน

| บทบาท | ใครทำ |
|---|---|
| Market Intuition | คุณ (ไม่มีใครแทนได้) |
| Pattern Recognition | AI |
| Memory Storage | Supabase |
| Content Production | AI + Template |
| Distribution | n8n Automation |
| Framing Strategy | Human-AI Together |

---

## PART 8: เป้าหมายรวม

```
ระยะสั้น  →  ตัดสินใจได้ดีขึ้น + Content ที่ตรงใจตลาด
ระยะกลาง  →  ระบบที่จำวิธีคิดและ Buyer Psychology ได้
ระยะยาว   →  Human-AI Market Intelligence Infrastructure
              ที่เป็น Proprietary Asset ของ Finnhouses
```

---

## สิ่งที่สำคัญที่สุด

> อย่าหลงกับ Technology
> เพราะ AI เปลี่ยนเร็ว, Automation เปลี่ยนเร็ว, Tool เปลี่ยนเร็ว
>
> แต่สิ่งที่สะสมค่าได้คือ:
> **Market Memory · Human Intuition · Proprietary Understanding · Local Behavioral Data**

---

---

## PART 9: Buyer Profile Knowledge Base (Proprietary)

> ข้อมูลชุดนี้มาจากประสบการณ์หน้างานจริง — ไม่มีใน Internet

### 9.1 หลักการคัดเลือกและประเมินทรัพย์

ก่อนทำการตลาดทรัพย์ใดก็ตาม ต้องลงหน้างานจริงเสมอ โดยมองจากมุมของผู้ซื้อ:

```
ดูอะไร?
├── โลเคชั่น + สภาพแวดล้อม
├── ถนน / น้ำ / ไฟ
├── สิ่งอำนวยความสะดวกรอบข้าง
├── ระยะทางจากทรัพย์ → ถนนเมน → ขนส่งสาธารณะ
└── แหล่งทำงาน + โรงเรียนใกล้เคียง
```

> ใครจะซื้อ = ขึ้นอยู่กับว่ามีอะไรอยู่ใกล้ทรัพย์นั้น

---

### 9.2 Segment 1: บ้านมือสอง / หน่วยขาย

```json
{
  "segment": "บ้านมือสอง / หน่วยขาย",
  "area": "ลาดหลุมแก้ว",
  "property_type": "ทาวน์เฮ้าส์ 2 ชั้น",
  "target_buyer": {
    "occupation": "พนักงานที่ทำงานในโรง",
    "employer_nearby": "โรงงานสแตนเลย์",
    "family_status": "มีครอบครัว มีลูก 1-2 คน",
    "income_pattern": "รายสัปดาห์",
    "behavior": [
      "ทำงานจันทร์-เสาร์ อาทิตย์พักผ่อน ตื่นสาย",
      "ดื่มวันศุกร์-เสาร์และวันเงินเดือนออก",
      "จอดรถหน้าบ้านเป็นหลัก ขับเข้าบ้านเมื่อไม่ออกไปไหนแล้ว",
      "ภรรยาซื้อของออนไลน์"
    ]
  },
  "key_selling_points": [
    "จอดรถหน้าบ้านได้ / ในบ้านได้",
    "ขับรถถึงโรงงานสแตนเลย์ 10 นาที",
    "ส่งลูกโรงเรียนบัวแก้วเกษรแล้วเลยไปทำงานได้",
    "ถนนกว้าง ไฟสว่าง ภรรยาขับเข้าออกปลอดภัยกะดึก"
  ],
  "buyer_radius_km": 5,
  "emotional_need": "ความปลอดภัยครอบครัว + ความสะดวกเดินทาง",
  "location_factor": "สำคัญมาก — proximity to employer คือตัวตัดสินใจหลัก",
  "conversion_trigger": "90% ถ้าทรัพย์อยู่ใกล้โรงงานสแตนเลย์"
}
```

**Framed Message ที่ใช้ได้:**
> *"เช้าส่งลูกที่โรงเรียนบัวแก้วเกษร แล้วขับตรงไปโรงงานสแตนเลย์ได้เลย — 10 นาที"*
> *"กะบ่ายออกดึก ไม่ต้องห่วง ถนนกว้าง ไฟสว่าง ภรรยาและลูกกลับบ้านได้ปลอดภัย"*

---

### 9.3 Segment 2: รับสร้างบ้าน

```json
{
  "segment": "รับสร้างบ้าน",
  "target_buyer": {
    "profile": "มีที่ดินอยู่แล้ว ตัดสินใจโลเคชั่นแล้ว",
    "location_factor": "ไม่ใช่ปัจจัยหลัก"
  },
  "emotional_need": "ความเชื่อใจ — สร้างเสร็จตามกำหนด คุณภาพได้มาตรฐาน ดูแลระหว่างก่อสร้าง",
  "sub_segments": [
    {
      "group": "A — Hands-off",
      "description": "ใช้เงินอย่างเดียว ยกให้บริษัทจัดการทั้งหมด",
      "needs": [
        "ความสะดวก ไม่ยุ่งยาก",
        "ออกแบบ ซื้อของ ติดต่อหน่วยงานแทนได้ทั้งหมด"
      ],
      "service_style": "Full-service / Turnkey",
      "key_message": "บอกสิ่งที่อยากได้ เราจัดการให้ครบ"
    },
    {
      "group": "B — Hands-on",
      "description": "อยากเลือกทุกอย่างเอง กระเบื้อง สุขภัณฑ์ โคมไฟ สี",
      "needs": [
        "คำแนะนำระหว่างก่อสร้าง",
        "ตอบคำถาม Customize ได้ เช่น เพิ่มช่องใส่สบู่ เพิ่มไฟส่อง",
        "แจ้งค่าใช้จ่ายเพิ่มเติมได้ชัดเจนและโปร่งใส"
      ],
      "service_style": "Consultative / Personal Touch",
      "key_message": "เราอยู่ตรงนี้ทุกขั้นตอน คุณเลือก เราแนะนำ"
    }
  ]
}
```

---

### 9.4 Segment Comparison

| | บ้านมือสอง | สร้างบ้าน Hands-off | สร้างบ้าน Hands-on |
|---|---|---|---|
| **ปัจจัยหลัก** | โลเคชั่น + ทำเล | ความเชื่อใจ | ความใส่ใจส่วนตัว |
| **กลัวอะไร** | เดินทางไกล / ไม่ปลอดภัย | ผู้รับเหมาทิ้งงาน | ได้ไม่ตรงที่ต้องการ |
| **ต้องการได้ยิน** | ชีวิตประจำวันที่ดีขึ้น | มาตรฐาน + timeline | "เราฟังคุณ" |
| **Service Style** | Listing ที่ Positioned แล้ว | Turnkey | Consultative |

---

### 9.5 Supabase Table เพิ่มเติม (จาก Knowledge นี้)

**buyer_profiles**
- segment_type (resale / build_handoff / build_handson)
- area, property_type
- occupation, employer_nearby
- income_pattern, family_status
- behavior_tags (array)
- key_selling_points (array)
- emotional_need
- buyer_radius_km
- service_style
- framed_messages (array)

---

*ไฟล์นี้รวม: Finnhouses Market Intelligence System + AI Market Positioning + Buyer Psychology + Buyer-Context Positioning + AI-assisted Market Framing + Intelligence Injection Framework + Buyer Profile Knowledge Base (Proprietary)*
