# ADR-006: Hub-Centric Security Remediation

Status: Draft
Date: 2026-07-27

## Context

AP Home Platform is intended to follow a Hub-centric architecture:

```text
Dashboard (Next.js)
        |
        v
Backend Hub
        |
        +---- Supabase
        +---- AI Providers
        +---- n8n
```

The current codebase has drifted from this model. Several Next.js API routes now perform privileged business operations directly:

- Service-role Supabase CRUD for leads, deals, projects, reports, feedback, and market intelligence.
- Direct AI provider calls from Dashboard API routes.
- Dynamic market intelligence table access through a query parameter.
- Server-side external URL fetch from a public route.

This creates security and operational risk:

- `SUPABASE_SERVICE_KEY` bypasses RLS and should not be exposed through unauthenticated Dashboard-owned APIs.
- Public AI routes can create unauthorized provider cost.
- Business rules and authorization are split across the Dashboard and Hub.
- Production migration risk is high because Dashboard components, n8n workflows, Hub v1/v2 routes, and external services have overlapping dependencies.

## Decision

Adopt a staged migration back to Hub-centric ownership.

Backend Hub will be the target owner for:

- Business rules.
- Authentication and authorization checks for privileged operations.
- Service-role Supabase access.
- AI text/image orchestration.
- Usage logging, quota, and cost controls.
- n8n workflow orchestration and callback validation.

Next Dashboard will be limited to:

- UI rendering.
- User interaction.
- Thin compatibility proxies during migration, only where needed.
- Public/non-secret configuration.

Supabase remains the data layer and RLS safety net, not the primary business logic layer.

## Migration Safety Model

Migration must proceed by route family through three modes.

### Observe Mode

- Keep current behavior active.
- Inventory consumers and request/response contracts.
- Log production usage before enforcing new behavior.
- Identify Dashboard, n8n, Hub, and external callers.

### Protected Mode

- Enforce authentication, authorization, validation, allowlists, and rate/cost limits.
- Move newly migrated operations through Hub.
- Keep compatibility proxies temporarily where production workflows require them.
- Keep rollback path controlled and explicit.

### Legacy Removal Mode

- Remove or deprivilege legacy Next API routes that own business logic, service-role database access, or AI provider calls.
- Remove service-role and provider secrets from Dashboard runtime when no longer needed.
- Retain only deliberately approved thin proxies.

## Consequences

Positive:

- Restores clear system ownership.
- Reduces service-role exposure.
- Centralizes security controls.
- Enables AI usage and cost governance.
- Makes n8n and external integration behavior easier to audit.

Trade-offs:

- Requires API contract migration.
- Requires production dependency inventory and owner review before enforcement.
- May temporarily increase route/proxy complexity during compatibility period.
- Requires frontend and Hub deployments to be coordinated carefully.

## Non-Goals

- Do not rewrite the entire platform.
- Do not redesign the Dashboard UI as part of this ADR.
- Do not replace Supabase.
- Do not remove Backend Hub.
- Do not migrate business logic back into the frontend.
- Do not change database schema without a separate migration and rollback plan.
- Do not modify n8n workflows without workflow-owner approval.
- Do not add a new auth vendor or infrastructure dependency without a separate decision.

## Required Approval Gates

Before implementation:

- Current production backup verified.
- Frontend build repaired and passing.
- Backend Hub build passing.
- Route dependency inventory reviewed.
- Rollback procedure tested.
- Owner of each migrated module confirmed.
- No production-impacting change starts without approval.

## Rollback Strategy

- Prefer additive Hub endpoints before Dashboard cutover.
- Keep compatibility proxies during Protected Mode.
- Use route-family migration instead of all-at-once cutover.
- Do not remove legacy routes until production logs show no dependency.
- Avoid destructive database changes in this remediation unless separately approved.

## Status Notes

This ADR is a draft only. It does not approve implementation.

No runtime code, schema, environment, deployment, or n8n workflow changes are approved by this draft.
