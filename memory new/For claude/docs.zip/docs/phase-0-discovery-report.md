# Phase 0 Discovery & Preparation Report

Status: Phase 0 only. No implementation approved.
Date: 2026-07-27

## Scope Guard

No runtime code, database schema, environment variables, deployment configuration, or n8n workflows were modified.

Allowed Phase 0 actions completed:

- Repaired local frontend dependency installation.
- Verified frontend build.
- Verified Backend Hub build check.
- Inventoried API consumers from Dashboard source, Backend Hub source, route proxies, workflow/script exports, and docs.
- Drafted API Contract Map.
- Drafted ADR-006.
- Verified dependency and environment assumptions available from local files.

## Build & Dependency Verification

| Check | Command | Result | Notes |
| --- | --- | --- | --- |
| Root dependency presence | `npm.cmd ls next --depth=0` | Initially failed | `next` was missing from root `node_modules`. |
| Root dependency repair | `npm.cmd install` | Passed | Installed local dependencies. `package.json` and `package-lock.json` were not changed. |
| Frontend production build | `npm.cmd run build` | Passed | Next.js build completed, 48 static/dynamic routes generated. |
| Backend Hub type/build check | `npm.cmd run build:check` in `services/backend-hub` | Passed | `tsc --noEmit` completed successfully. |
| Root dependency versions | `npm.cmd ls next react react-dom @supabase/supabase-js --depth=0` | Passed | `next@15.5.15`, `react@18.3.1`, `react-dom@18.3.1`, `@supabase/supabase-js@2.103.3`. |
| Root npm audit | `npm.cmd audit --audit-level=moderate` | Failed | 30 vulnerabilities: 17 moderate, 13 high. No dependency remediation was performed. |

Dependency risk notes:

- `npm audit` reports high findings for `next`, `postcss`, `sharp`, `ws`, `js-yaml`, and `brace-expansion` dependency chains.
- Some findings report no fix available through the current dependency tree.
- Dependency upgrade/remediation is outside Phase 0 and requires separate approval because it can affect runtime behavior.

## Environment & Architecture Assumptions

Observed from local code/docs only:

| Assumption | Evidence | Status |
| --- | --- | --- |
| Dashboard runs as a Next.js app and has local server API routes. | `app/api/*`, successful `next build`. | Verified locally. |
| Backend Hub exists as separate Node/Express service. | `services/backend-hub`, `server.cjs`, `src/server.ts`. | Verified locally. |
| Backend Hub build check passes. | `npm.cmd run build:check`. | Verified locally. |
| Current production Hub version is ambiguous in docs. | `docs/context_brief.md` says Hub v2 cutover was reverted to Hub v1; `memory/n8n-workflows/README.md` lists active Hub v2 endpoints. | Needs owner review. |
| Hub v1 path/header convention appears to be `/action/*` plus `x-hub-token`. | `docs/context_brief.md`, Next proxy routes, `services/backend-hub/server.cjs`. | Locally supported. |
| Hub v2 source uses `/api/*` plus `X-Hub-Secret` in middleware docs. | `services/backend-hub/src/server.ts`, `src/presentation/middleware/auth.ts`. | Locally supported but production status unclear. |
| Dashboard build reads `.env.local`. | Build output: `Environments: .env.local`. | Verified locally; values were not changed or disclosed. |

Open assumption gaps:

- Confirm whether production traffic currently targets Hub v1 `server.cjs` or Hub v2 `src/server.ts`/dist.
- Confirm active n8n workflow URLs in n8n UI, not only local workflow README.
- Confirm external integrations still calling `https://ap-home-platform.vercel.app/api/chat` from old Market Intelligence workflow JSON exports.
- Confirm owners for CRM, Deals, Land Analyzer, Market Intel, AI Content, Blog/FB queues, Property Review, QC/Quality Gate, and n8n workflows.

## API Consumer Inventory

### Dashboard Usage

| Consumer | Routes Used |
| --- | --- |
| `components/CRM.tsx` | `/api/chat`, `/api/leads`, `/api/leads/{id}` |
| `components/DashboardOS.tsx` | `/api/leads`, `/api/blog/state`, direct `N8N_INTEL_URL` if configured |
| `components/Deals.tsx` | `/api/deals`, `/api/deals/{id}`, `/api/projects?ids=...` |
| `components/LandAnalyzer.tsx` | `/api/projects`, `/api/deals` |
| `components/MarketIntel.tsx` | `/api/market-intel`, `/api/market-intel/insights?table=market_insights`, `/api/market-intel/insights?table=content_frames`, `/api/market-intel/calibration`, `/api/market-intel/feedback` |
| `components/AIContent.tsx` | `/api/chat`, `/api/image`, `/api/fetch-blog`, `/api/fb/publish`, `/api/property/list`, `/api/blog/state`, `/api/fb/queue/build`, `/api/fb/queue/clear`, `/api/market-intel` |
| `components/Marketing.tsx` | `/api/blog/state`, `/api/blog/run`, `/api/blog/reset`, `/api/blog/queue/build`, `/api/blog/queue/clear` |
| `components/PropertyReview.tsx` | `/api/property/pending`, `/api/property/upload-image`, `/api/property/dismiss`, `/api/property/publish` |
| `components/ContentPerformance.tsx` | `/api/content/performance` |
| `components/QualityGateAccuracy.tsx` | `/api/quality-gate/accuracy`, `/api/quality-gate/feedback` |
| `components/QcAccuracy.tsx` | `/api/qc/accuracy` |
| `components/OperationalDashboard.tsx` | ops summary URL from config, `/api/ops/dlq/{id}/retry` |

### Backend Hub Usage

| Owner | Routes / Integrations |
| --- | --- |
| Next proxy routes | Forward `/api/blog/*`, `/api/fb/queue/*`, `/api/property/*`, `/api/ops/*`, `/webhook/n8n` to Hub/FB backend. |
| Hub v1 `server.cjs` | Implements `/api/state`, `/api/ops/*`, `/action/blog/*`, `/action/fb/*`, `/action/property/*`, `/api/properties/*`, `/api/qc/*`, `/webhook/n8n`. |
| Hub v2 `src/server.ts` | Implements `/api/health`, `/api/qc`, `/api/blog`, `/api/state`, optional `/api/fb`, `/webhook/n8n`. |
| FB backend | `services/fb-backend/server.js` exposes `/api/fb/publish` and posts callbacks to Hub webhook URL. |

### n8n Workflows

| Source | Observed Dependency | Status |
| --- | --- | --- |
| `memory/n8n-workflows/README.md` | Lists WF1, WF2, Queue Auto-run, Wake-up as active; mentions Hub v2 endpoints. | Needs owner review against live n8n. |
| `docs/context_brief.md` | States Hub v2 cutover was reverted; Hub v1 is production; queue paths are `/action/blog|fb/queue/*`. | Conflicts with workflow README. |
| `scripts/Finnhouses - Market Intelligence Collector v1*.json` | Calls `https://ap-home-platform.vercel.app/api/chat` from workflow code. | External/old workflow risk; confirm if active. |
| `app/webhook/n8n/route.ts` | Receives n8n callback and proxies to Hub `/webhook/n8n` with HMAC/token behavior. | Existing proxy path. |

### External Integrations

| Integration | Route / Behavior | Notes |
| --- | --- | --- |
| Facebook backend | `/api/fb/publish` via Next proxy or Hub, callback to Hub webhook. | Uses shared Hub secret conventions. |
| Telegram | `/api/telegram` sends Telegram bot messages. | Public GET test endpoint exists; not in critical remediation scope but should be reviewed. |
| WordPress/blog import | `/api/fetch-blog`, property/blog data through Hub routes. | SSRF hardening needed before production changes. |
| AI providers | Anthropic, OpenAI, Gemini, Ideogram from Next API routes. | Target owner should be Hub AI Gateway. |
| Supabase REST | Multiple Next API routes use service-role key. | Target owner should be Hub. |

## API Contract Map

Contract shapes below are inferred from local route handlers and component callers. They must be confirmed with production logs before enforcement.

| Route | Consumer | Request Shape | Response Shape | Current Owner | Target Owner | Migration Status |
| --- | --- | --- | --- | --- | --- | --- |
| `GET /api/leads` | CRM, DashboardOS | none | `{ ok: true, data: Lead[] }` or `{ ok:false,error }` | Next API + Supabase service role | Hub Lead API | Observe pending |
| `POST /api/leads` | CRM lead create/import | lead object or `{ rows: Lead[] }` | `{ ok:true,data: Lead | Lead[] }` | Next API + Supabase service role | Hub Lead API | Observe pending |
| `PATCH /api/leads/{id}` | CRM lead edit | partial lead object | `{ ok:true,data: Lead | null }` | Next API + Supabase service role | Hub Lead API | Observe pending |
| `DELETE /api/leads/{id}` | CRM lead delete | none | `{ ok:true }` | Next API + Supabase service role | Hub Lead API | Observe pending |
| `GET /api/deals` | Deals | none | `{ ok:true,data: Deal[] }` | Next API + Supabase service role | Hub Deal API | Observe pending |
| `POST /api/deals` | Deals, LandAnalyzer | deal object | `{ ok:true,data: Deal | null }` | Next API + Supabase service role | Hub Deal API | Observe pending |
| `PATCH /api/deals/{id}` | Deals | partial deal object | `{ ok:true,data: Deal | null }` | Next API + Supabase service role | Hub Deal API | Observe pending |
| `DELETE /api/deals/{id}` | Deals | none | `{ ok:true }` | Next API + Supabase service role | Hub Deal API | Observe pending |
| `GET /api/projects` | LandAnalyzer | optional `?ids=id1,id2` | `{ ok:true,data: Project[] }` | Next API + Supabase service role | Hub Project API | Observe pending |
| `POST /api/projects` | LandAnalyzer | project object | `{ ok:true,data: Project | null }` | Next API + Supabase service role | Hub Project API | Observe pending |
| `POST /api/chat` | CRM, AIContent, workflow JSON exports | `{ system?, prompt, maxTokens?, model? }` | `{ text }` or `{ error }` | Next API + Anthropic + Supabase context | Hub AI Gateway | Observe pending |
| `POST /api/ai` | AI content generation | `{ platform, style, tone, topic }` | `{ content }` or `{ error }` | Next API + Anthropic | Hub AI Gateway | Observe pending |
| `POST /api/image` | AIContent | `{ topic, style, concept?, model?, referenceImage? }` | likely `{ ok:true,url,model? }` or `{ ok:false,error }` | Next API + image providers | Hub AI Gateway | Observe pending |
| `POST /api/fetch-blog` | AIContent | `{ url }` | `{ text, imageUrl }` or `{ error }` | Next API external fetch | Hub Content Import API or hardened compatibility route | Observe pending |
| `POST /api/market-intel` | MarketIntel, AIContent | arbitrary market intel payload | n8n webhook response passthrough | Next API -> n8n webhook | Hub Market Intel API | Observe pending |
| `POST /api/market-intel/submit` | Historical/alternate submitter | arbitrary market intel payload | n8n webhook response passthrough | Next API -> n8n webhook | Hub Market Intel API | Observe pending |
| `GET /api/market-intel/insights?table=...` | MarketIntel | `table` query string | `{ ok:true,data:any[] }` | Next API + Supabase service role | Hub Market Intel report API | Observe pending |
| `GET /api/market-intel/calibration` | MarketIntel | none | calibration rows/stats object | Next API + Supabase service role | Hub Market Intel report API | Observe pending |
| `PATCH /api/market-intel/feedback` | MarketIntel | `{ id, human_feedback }` inferred | `{ ok:true,data? }` | Next API + Supabase service role | Hub Market Intel feedback API | Observe pending |
| `GET /api/content/performance` | ContentPerformance | none | `{ ok:true,reliable,posts,... }` inferred | Next API + Supabase service role | Hub Reporting API | Observe pending |
| `GET /api/quality-gate/accuracy` | QualityGateAccuracy | none | `{ ok:true,... }` report data | Next API + Supabase service role | Hub QC/Quality report API | Observe pending |
| `PATCH /api/quality-gate/feedback` | QualityGateAccuracy | feedback object with id | `{ ok:true,data? }` | Next API + Supabase service role | Hub QC/Quality feedback API | Observe pending |
| `GET /api/qc/accuracy` | QcAccuracy | none | `{ ok:true,... }` report data | Next API + Supabase service role | Hub QC report API | Observe pending |
| `GET /api/blog/state` | DashboardOS, Marketing, AIContent | none | Hub state passthrough or `{ blog:{status}, error }` | Next proxy -> Hub `/api/state` | Hub Blog/State API | Existing proxy, verify |
| `POST /api/blog/run` | Marketing | run body | Hub response passthrough | Next proxy -> Hub `/action/blog/run` | Hub Blog API | Existing proxy, verify |
| `POST /api/blog/reset` | Marketing | none | Hub response passthrough | Next proxy -> Hub `/action/blog/reset` | Hub Blog API | Existing proxy, verify |
| `POST /api/blog/queue/build` | Marketing | queue build payload | Hub response passthrough | Next proxy -> Hub `/action/blog/queue/build` | Hub Blog API | Existing proxy, verify |
| `POST /api/blog/queue/clear` | Marketing | none | Hub response passthrough | Next proxy -> Hub `/action/blog/queue/clear` | Hub Blog API | Existing proxy, verify |
| `POST /api/blog/queue/run-next` | n8n/ops/manual callers | optional body | Hub response passthrough | Next proxy -> Hub `/action/blog/queue/run-next` | Hub Blog API | Existing proxy, verify |
| `POST /api/fb/publish` | AIContent | post publish payload | FB backend response passthrough | Next proxy -> FB backend | Hub/FB backend | Existing proxy, verify |
| `POST /api/fb/queue/build` | AIContent | queue build payload | Hub response passthrough | Next proxy -> Hub `/action/fb/queue/build` | Hub FB Queue API | Existing proxy, verify |
| `POST /api/fb/queue/clear` | AIContent | none | Hub response passthrough | Next proxy -> Hub `/action/fb/queue/clear` | Hub FB Queue API | Existing proxy, verify |
| `POST /api/fb/queue/run-next` | ops/manual callers | optional body | Hub response passthrough | Next proxy -> Hub `/action/fb/queue/run-next` | Hub FB Queue API | Existing proxy, verify |
| `GET /api/property/list` | AIContent | none | `{ ok, properties }` or Hub passthrough | Next proxy -> Hub `/api/properties/wp-published` | Hub Property API | Existing proxy, verify |
| `GET /api/property/pending` | PropertyReview | none | `{ ok, data }` or Hub passthrough | Next proxy -> Hub `/api/properties/pending` | Hub Property API | Existing proxy, verify |
| `POST /api/property/upload-image` | PropertyReview | upload/image payload | Hub response passthrough | Next proxy -> Hub `/action/property/upload-image` | Hub Property API | Existing proxy, verify |
| `POST /api/property/dismiss` | PropertyReview | property dismiss payload | Hub response passthrough | Next proxy -> Hub `/action/property/dismiss` | Hub Property API | Existing proxy, verify |
| `POST /api/property/publish` | PropertyReview | property publish payload | Hub response passthrough | Next proxy -> Hub `/action/property/publish` | Hub Property API | Existing proxy, verify |
| `GET /api/ops/summary` | OperationalDashboard | none | Hub ops summary passthrough | Next proxy -> Hub `/api/ops/summary` | Hub Ops API | Existing proxy, verify |
| `POST /api/ops/dlq/{id}/retry` | OperationalDashboard | none/body ignored | Hub response passthrough | Next proxy -> Hub `/api/ops/dlq/{id}/retry` | Hub Ops API | Existing proxy, verify |
| `GET /api/n8n` | Manual/admin | none | n8n workflow list passthrough | Next API -> n8n API | Hub/Admin API or protected Next admin route | Observe pending |
| `POST /api/telegram` | Lead/contact form if used | `{ name, phone, area, budget }` | Telegram response or `{ ok }` inferred | Next API -> Telegram | Hub Notification API | Observe pending |
| `GET /api/telegram` | Manual config test | none | Telegram test response | Next API -> Telegram | Remove or protect | Observe pending |
| `POST /webhook/n8n` | n8n callback | callback payload with run id | Hub webhook passthrough | Next proxy -> Hub `/webhook/n8n` | Hub webhook | Existing proxy, verify |

## Route Dependency Inventory Review Status

| Area | Status | Notes |
| --- | --- | --- |
| Dashboard usage | Reviewed from local source | Needs production browser/log confirmation. |
| Backend Hub usage | Reviewed from Hub v1 and v2 source | Production version ambiguity remains. |
| n8n workflows | Reviewed from local README, docs, and exported JSON scripts | Live n8n UI verification still required. |
| External integrations | Reviewed from local source/docs | FB backend, Telegram, AI providers, Supabase, WordPress/blog import need owner confirmation. |

## Phase 0 Findings

1. Frontend build environment is repaired locally and `npm.cmd run build` passes.
2. Backend Hub build check passes.
3. There is a documentation conflict about Hub v1 vs Hub v2 production ownership.
4. Multiple Dashboard components consume service-role-backed Next API routes directly.
5. Old Market Intelligence workflow exports appear to call public `/api/chat`; confirm whether active.
6. Root dependency audit has unresolved high/moderate findings.
7. No production backup, rollback rehearsal, owner assignment, or live n8n verification has been completed in this local Phase 0 pass.

## Production Truth Verification Status

- [ ] Production frontend confirmed
- [ ] Production Backend Hub confirmed
- [ ] Active Hub version confirmed (v1/v2)
- [ ] Browser network calls captured
- [ ] Live n8n workflows confirmed
- [ ] Supabase production project confirmed
- [ ] Backup verification completed
- [ ] Rollback procedure confirmed

## Stop Condition

Phase 0 discovery/preparation is complete from local repo evidence.

Waiting for approval before any implementation.
