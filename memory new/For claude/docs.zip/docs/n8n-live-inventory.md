# n8n Live Inventory

Status: Phase 0.5 discovery only
Date: 2026-07-27

## Scope Guard

No n8n workflows were edited. No n8n credentials, environment variables, or deployment configuration were changed.

This report compares repository evidence against required live production evidence. Live n8n access was not available in this session, so live confirmation is pending.

## Repository Evidence

### `memory/n8n-workflows`

| File | Evidence | Repository Status |
| --- | --- | --- |
| `memory/n8n-workflows/README.md` | Lists active workflows: `WF1 (8_wb_fix).json`, `WF2 (5_hub_v2).json`, `Queue Auto-run (4).json`, `Wake-up workflow.json`. | Claims active Hub v2 endpoints |
| `memory/n8n-workflows/archive/.gitkeep` | Archive placeholder only. | No archived workflow JSON present |

Important conflict:

- `memory/n8n-workflows/README.md` says active workflows use Hub v2 paths such as `/api/blog/queue/run-next`.
- `docs/context_brief.md` says Hub v2 cutover was reverted and Hub v1 is production, using `/action/blog|fb/queue/*` with `x-hub-token`.

### Exported Workflow JSON

| File | Observed External Calls | Status |
| --- | --- | --- |
| `scripts/Finnhouses - Market Intelligence Collector v1 (fixed).json` | Calls `https://ap-home-platform.vercel.app/api/chat`; uses Vercel Dashboard route as an AI parser gateway. | Needs live verification |
| `scripts/Finnhouses - Market Intelligence Collector v1 (env-fixed).json` | Calls `https://ap-home-platform.vercel.app/api/chat`; similar market-intel parser behavior. | Needs live verification |

### Docs

| File | Evidence | Status |
| --- | --- | --- |
| `docs/context_brief.md` | States Hub v2 cutover was reverted to Hub v1; production paths use `/action/blog|fb/queue/*`. | Needs live verification |
| `docs/decisions.md` | Documents failed Hub v2 queue cutover and revert to Hub v1. | Needs live verification |
| `docs/AI_TEAM.md` | Mentions active Hub v1 workflow dependencies for wake-up and QC. | Needs live verification |
| `docs/hub-v2/*` | Describes target/evolved Hub v2 API contracts and migration plans. | Architecture reference, not proof of live state |

## Required Production Evidence

These items must be collected from live n8n before ADR-006 implementation approval.

| Required Evidence | Current Status | Notes |
| --- | --- | --- |
| Active workflows list | Pending | Must be verified in n8n UI/API. |
| Active webhook URLs | Pending | Confirm whether URLs target Vercel, Hub v1, Hub v2, or direct Railway services. |
| Hub endpoint targets | Pending | Confirm `/action/*` vs `/api/*` target paths. |
| Credentials usage | Pending | Confirm whether workflows use service-role keys, anon keys, Hub secret, or provider credentials. Do not expose secret values. |
| Recent execution history | Pending | Confirm last successful/failed runs and payload paths. |
| Disabled/deprecated workflows | Pending | Confirm old Market Intelligence workflow exports are not still active. |
| Callback target for `/webhook/n8n` | Pending | Confirm whether callbacks go to Vercel proxy or directly to Hub. |
| Queue Auto-run target | Pending | Resolve README/docs conflict about Hub v1 vs Hub v2. |
| Wake-up workflow target | Pending | Resolve `/api/health/state`, `/api/state`, or other target path. |

## Live Access Status

Live n8n access was unavailable in this session.

Result:

- Active workflows: Pending
- Webhook URLs: Pending
- Hub endpoint targets: Pending
- Credentials usage: Pending
- Execution history: Pending

## Risk Notes

- If exported Market Intelligence workflows are still active, they may call public `/api/chat`, which conflicts with the target Hub-owned AI gateway.
- If n8n uses service-role Supabase credentials directly, ADR-006 must account for workflow credential migration or scoped service access.
- If production still uses Hub v1 paths, moving Dashboard proxies to Hub v2 paths without a tested cutover will break blog/FB/property workflows.

## Conclusion

n8n production truth is not verified. ADR-006 implementation approval should wait until live n8n workflow targets, credentials usage, and execution history are reviewed.
