# Active Route Inventory

Status: Phase 0.5 discovery only
Date: 2026-07-27

## Scope Guard

No runtime code, database schema, environment variables, deployment configuration, or n8n workflows were modified.

Status labels:

- `Repo Confirmed`: route and consumer are present in source files.
- `Needs Production Verification`: route is present in repo but live traffic/ownership must be confirmed.
- `Conflict`: repository docs disagree.

| Route | Consumer | Current Owner | Target Owner | Evidence | Status |
| --- | --- | --- | --- | --- | --- |
| `/api/leads` | `components/CRM.tsx`, `components/DashboardOS.tsx` | Next API + Supabase service role | Backend Hub Lead API | `fetch("/api/leads")`; `app/api/leads/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/leads/{id}` | `components/CRM.tsx` | Next API + Supabase service role | Backend Hub Lead API | `fetch(\`/api/leads/${id}\`)`; `app/api/leads/[id]/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/deals` | `components/Deals.tsx`, `components/LandAnalyzer.tsx` | Next API + Supabase service role | Backend Hub Deal API | `fetch("/api/deals")`; `app/api/deals/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/deals/{id}` | `components/Deals.tsx` | Next API + Supabase service role | Backend Hub Deal API | `app/api/deals/[id]/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/projects` | `components/LandAnalyzer.tsx`, `components/Deals.tsx` | Next API + Supabase service role | Backend Hub Project API | `fetch("/api/projects")`, `?ids=` lookup | Repo Confirmed; Needs Production Verification |
| `/api/chat` | `components/CRM.tsx`, `components/AIContent.tsx`, exported workflow JSON | Next API + Anthropic + Supabase service role context | Backend Hub AI Gateway | `fetch("/api/chat")`; workflow JSON references Vercel `/api/chat` | Repo Confirmed; external activity Needs Production Verification |
| `/api/ai` | App route exists; likely AI content feature | Next API + Anthropic | Backend Hub AI Gateway | `app/api/ai/route.ts`; no direct component fetch found in current grep | Needs Production Verification |
| `/api/image` | `components/AIContent.tsx` | Next API + OpenAI/Gemini/Ideogram | Backend Hub AI Gateway | `fetch("/api/image")`; `app/api/image/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/blog/state` | `components/DashboardOS.tsx`, `components/Marketing.tsx`, `components/AIContent.tsx` | Next proxy -> Hub `/api/state` | Backend Hub State/Blog API | `app/api/blog/state/route.ts` | Repo Confirmed; Hub version Needs Production Verification |
| `/api/blog/run` | `components/Marketing.tsx` | Next proxy -> Hub `/action/blog/run` | Backend Hub Blog API | `app/api/blog/run/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/blog/reset` | `components/Marketing.tsx` | Next proxy -> Hub `/action/blog/reset` | Backend Hub Blog API | `app/api/blog/reset/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/blog/queue/build` | `components/Marketing.tsx` | Next proxy -> Hub `/action/blog/queue/build` | Backend Hub Blog API | `app/api/blog/queue/build/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/blog/queue/clear` | `components/Marketing.tsx` | Next proxy -> Hub `/action/blog/queue/clear` | Backend Hub Blog API | `app/api/blog/queue/clear/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/blog/queue/run-next` | n8n/ops/manual callers, docs | Next proxy -> Hub `/action/blog/queue/run-next` | Backend Hub Blog API | `app/api/blog/queue/run-next/route.ts`; `memory/n8n-workflows/README.md` | Conflict: repo route targets Hub v1-style action, workflow README says Hub v2 |
| `/api/fb/publish` | `components/AIContent.tsx` | Next proxy -> FB backend `/api/fb/publish` | Backend Hub/FB backend publish API | `app/api/fb/publish/route.ts`; comment says bypasses Hub | Repo Confirmed; Needs Production Verification |
| `/api/fb/queue/build` | `components/AIContent.tsx` | Next proxy -> Hub `/action/fb/queue/build` | Backend Hub FB Queue API | `app/api/fb/queue/build/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/fb/queue/clear` | `components/AIContent.tsx` | Next proxy -> Hub `/action/fb/queue/clear` | Backend Hub FB Queue API | `app/api/fb/queue/clear/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/fb/queue/run-next` | ops/manual callers | Next proxy -> Hub `/action/fb/queue/run-next` | Backend Hub FB Queue API | `app/api/fb/queue/run-next/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/property/list` | `components/AIContent.tsx` | Next proxy -> Hub `/api/properties/wp-published` | Backend Hub Property API | `app/api/property/list/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/property/pending` | `components/PropertyReview.tsx` | Next proxy -> Hub `/api/properties/pending` | Backend Hub Property API | `app/api/property/pending/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/property/upload-image` | `components/PropertyReview.tsx` | Next proxy -> Hub `/action/property/upload-image` | Backend Hub Property API | `app/api/property/upload-image/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/property/dismiss` | `components/PropertyReview.tsx` | Next proxy -> Hub `/action/property/dismiss` | Backend Hub Property API | `app/api/property/dismiss/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/property/publish` | `components/PropertyReview.tsx` | Next proxy -> Hub `/action/property/publish` | Backend Hub Property API | `app/api/property/publish/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/market-intel` | `components/MarketIntel.tsx`, `components/AIContent.tsx`, `components/DashboardOS.tsx` | Next proxy -> n8n webhook | Backend Hub Market Intel API | `app/api/market-intel/route.ts`; `N8N_INTEL_URL = "/api/market-intel"` | Repo Confirmed; Needs Production Verification |
| `/api/market-intel/submit` | Historical/alternate route | Next proxy -> n8n webhook | Backend Hub Market Intel API | `app/api/market-intel/submit/route.ts` | Needs Production Verification |
| `/api/market-intel/insights` | `components/MarketIntel.tsx` | Next API + Supabase service role dynamic table read | Backend Hub Market Intel Report API | `?table=market_insights`, `?table=content_frames` | Repo Confirmed; Needs Production Verification |
| `/api/market-intel/calibration` | `components/MarketIntel.tsx` | Next API + Supabase service role | Backend Hub Market Intel Report API | `app/api/market-intel/calibration/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/market-intel/feedback` | `components/MarketIntel.tsx` | Next API + Supabase service role | Backend Hub Market Intel Feedback API | `app/api/market-intel/feedback/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/qc/accuracy` | `components/QcAccuracy.tsx` | Next API + Supabase service role | Backend Hub QC Report API | `fetch("/api/qc/accuracy")` | Repo Confirmed; Needs Production Verification |
| `/api/quality-gate/accuracy` | `components/QualityGateAccuracy.tsx` | Next API + Supabase service role | Backend Hub Quality Report API | `fetch("/api/quality-gate/accuracy")` | Repo Confirmed; Needs Production Verification |
| `/api/quality-gate/feedback` | `components/QualityGateAccuracy.tsx` | Next API + Supabase service role | Backend Hub Quality Feedback API | `fetch("/api/quality-gate/feedback")` | Repo Confirmed; Needs Production Verification |
| `/api/content/performance` | `components/ContentPerformance.tsx` | Next API + Supabase service role | Backend Hub Reporting API | `fetch("/api/content/performance")` | Repo Confirmed; Needs Production Verification |
| `/api/ops/summary` | `components/OperationalDashboard.tsx` via configured ops URL | Next proxy -> Hub `/api/ops/summary` | Backend Hub Ops API | `app/api/ops/summary/route.ts` | Needs Production Verification |
| `/api/ops/dlq/{id}/retry` | `components/OperationalDashboard.tsx` | Next proxy -> Hub `/api/ops/dlq/{id}/retry` | Backend Hub Ops API | `app/api/ops/dlq/[id]/retry/route.ts` | Repo Confirmed; Needs Production Verification |
| `/api/n8n` | Manual/admin caller | Next API -> n8n API | Protected Admin/Hub Ops API | `app/api/n8n/route.ts` | Needs Production Verification |
| `/api/telegram` | Lead/contact/manual test | Next API -> Telegram Bot API | Backend Hub Notification API or protected route | `app/api/telegram/route.ts` | Needs Production Verification |
| `/webhook/n8n` | n8n callback | Next proxy -> Hub `/webhook/n8n` | Backend Hub webhook | `app/webhook/n8n/route.ts` | Repo Confirmed; Needs Production Verification |

## Service and Script Evidence

| Area | Evidence | Status |
| --- | --- | --- |
| Backend Hub v1 | `services/backend-hub/server.cjs` implements `/action/*`, `/api/qc/*`, `/api/state`, `/webhook/n8n`. | Needs Production Verification |
| Backend Hub v2 | `services/backend-hub/src/server.ts` wires `/api/blog`, `/api/qc`, `/api/state`, `/api/fb`, `/webhook/n8n`. | Needs Production Verification |
| FB backend | `services/fb-backend/server.js` implements `/api/fb/publish` and Hub callback. | Needs Production Verification |
| Market scraper script | `scripts/scrape-market.js` writes to Supabase with anon fallback in code. | Needs owner/security review before use |
| Market Intel exported workflows | `scripts/Finnhouses - Market Intelligence Collector v1*.json` call Vercel `/api/chat`. | Needs live n8n verification |

## Conclusion

The repository confirms the route surface and consumers, but live production traffic must be verified before implementation approval.
