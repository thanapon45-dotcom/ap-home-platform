# 🚀 Context Brief — AP-Home Platform OS
*Generated: 2026-07-04 15:57 — รัน `python context_loader.py` เพื่ออัพเดท*

---

## 📊 System Status

| Service | Status | URL |
|---------|--------|-----|
| Hub v1 | ✅ Live (HUB_URL ชี้ v1 อีกครั้ง หลัง revert) | ap-home-platform-production.up.railway.app |
| Hub v2 Shadow | 🟡 Online แต่**ไม่มี** `/api/fb/queue/*`, `/api/blog/queue/*` implement จริง — ห้าม cutover HUB_URL มาที่นี่จนกว่าจะ verify ครบ | exciting-creativity-production-4b85.up.railway.app |
| n8n | ✅ Live — Queue Auto-run verify ผ่านแล้ว (execution #720) | primary-production-8158a.up.railway.app |
| QC Line | ✅ Active | **`wf_qc_line (2)`** — 16 nodes, เพิ่มปุ่ม feedback "✅ ตรง / ❌ ไม่ตรง" (session 19d) — ตัวเก่า `wf_qc_line` (12 nodes) ปิดไว้เป็น backup |
| Dashboard | 🟡 Live แต่ blog status card เพิ่งแก้ auth header — ยังไม่ verify runtime | ap-home-platform.vercel.app |

---

## 🔴 Pending Tasks

2. 🔴 **Revert temp debug code ใน `blog/state/route.ts`** (commit `764abf4`) — เพิ่ม debug field ชั่วคราวเพื่อ diagnose HUB_SECRET mismatch ต้อง revert ก่อนถือว่าเสร็จสมบูรณ์
3. 🔴 **Verify WF1 + WF2 ยังทำงานปกติหลัง Hub v1 revert** → ยังไม่ได้รันเต็ม article ตั้งแต่ revert (`56dab04`) — trigger 1 รอบเต็ม แล้วดู Notify Hub Published เขียว
5. 🔴 **Verify FB token** → Railway easygoing-friendship → ตรวจ FB_PAGE_ACCESS_TOKEN (tokens.md line 97 บอก "หมด Jun 26" ขัดแย้งกับ Aug 2)
6. 🟡 **Enable RLS** → 6 tables: sites, line_users, qc_inspections, qc_defects, qc_standards, qc_daily_usage
7. 🟡 **Security SQL fixes** → REVOKE anon จาก append_line_image_atomic + DROP hub_state anon_update policy
8. 🟡 **Hub v2 fb/blog queue routes** → ต้องสร้างจริงบน Hub v2 backend ก่อนจะลอง migrate อีกครั้ง (ดู issues-log session 18)
9. 🟡 **TASK-503 Monitor 3 Days** → watch Railway logs สำหรับ Hub v2
10. ⚪ **FB Token renew** → หมดอายุ **Aug 2, 2026** (~32 วัน)
11. ⚪ **Market Intel Form** → กรอก section 1.3, 7.1, 8

### Hub v2 Remaining
- P2 pending: TASK-303 CacheManager (XS), TASK-304 HistoryManager (XS), TASK-313 Property Use Cases (M)
- fb/blog queue routes — ยังไม่ implement เลย (ค้นพบ session 18 — เดิมคิดว่าแค่ path ผิด แต่จริงๆ ไม่มี route)
- Cutover: TASK-601/602/603 (หลัง 3-day monitoring + queue routes เสร็จ)

---

## ⚠️ Open Issues (top 3)

### 🔴→✅ Positioned Content ดูเหมือนทำงาน (Telegram แจ้งเตือนทุกครั้ง) แต่ `content_frames` มี 0 แถวมาตลอด
**อาการ:** user ขอให้เช็คว่า Positioned Content ทำงานได้จริงไหม — query Supabase ตรงพบ `content_frames` count = 0 ทั้งที่ `market_insights` (27 แถว) และ `buyer_context_signals` (11 แถว) มีข้อมูลปกติ
**Root cause:** node "💾 Supabase: content_frames" ส่ง JSON keys `area`, `timing_signal`, `source_type` ที่ไม่ตรงกับคอลัมน์จริงของตาราง (`frame_text, frame_type, target_segment, target_context, keyword, tone, channel, ...`) — PostgREST reject insert ที่มี unknown column ด้วย 400 เสมอ แต่ code จับด้วย try/catch ที่แค่ `console.log` ไม่ throw ต่อ ไม่แจ้งเตือนที่ไหนเลย และ node คืน `saved: true` โดยไม่เช็คผลจริง
**ทำไมไม่มีใครสังเกต:** Telegram notification ที่ user เห็นทุกครั้งดึงข้อความมาจาก node "✨ Claude: Generate Content" (ขั้นตอนก่อนหน้า save) โดยตรง ไม่ได้เช็คว่า save สำเร็จไหม — เลยดูเหมือนระบบทำงานสมบูรณ์มาตลอด 1 เดือน+
**วิธีแก้:** แก้ node ให้ map field ให้ตรงคอลัมน์จริง (พับ area/timing_signal/source_type รวมเป็น string เดียวใน `target_context`) + เพิ่ม success/error status ต่อท้าย Telegram message กันไม่ให้เกิดซ้ำแบบเงียบๆ
**บทเรียนสำคัญ:** try/catch ที่มีแค่ `console.log(e.message)` โดยไม่ throw หรือแจ้งเตือนต่อ = silent failure ที่มองไม่เห็นเลยจนกว่าจะมาเช็ค DB ตรงๆ — ควร surface error กลับไปที่ user-facing notification เสมอ (Telegram/LINE) ไม่ใช่แค่ log ที่ไม่มีใครดู
**ผลกระทบที่กู้คืนไม่ได้:** Positioned Content ทั้งหมดที่สร้างมาก่อน session นี้ (ตั้งแต่ 29 พ.ค.) ไม่ได้เก็บอยู่ใน DB เลย มีแค่ในข้อความ Telegram เก่า
**Backfill ที่ทำแทน:** เขียน FB post ใหม่ 26 โพสต์จาก `market_insights` เดิม (ข้าม 1 แถวที่ confidence=1 "ข้อมูลไม่เพียงพอ") insert ย้อนหลังพร้อม `created_at` ตรงกับวันที่ insight เดิม — เป็นคอนเทนต์ที่เขียนใหม่ให้ตรง insight ไม่ใช่ข้อความต้นฉบับที่เคยส่งจริง (ดู decisions.md "Backfill content_frames")

---

## 2026-07-02 (session 19d) — QC Feedback Loop: n8n Code Sandbox Missing `URLSearchParams`


### 🔴→✅ Code node "Parse Feedback Postback" พัง `ReferenceError: URLSearchParams is not defined`
**อาการ:** เพิ่งเพิ่ม branch ใหม่ใน `wf_qc_line (2)` สำหรับรับปุ่ม feedback ("✅ ตรง / ❌ ไม่ตรง") — พอทดสอบกดปุ่มจริงใน LINE, execution error ใน 45ms ที่ node "Parse Feedback Postback" บรรทัด 6
**Root cause:** n8n รัน Code node ผ่าน task-runner แบบ sandboxed VM (`@n8n/task-runner`) ที่ไม่ expose Node.js/Browser global ทุกตัว — `URLSearchParams` ไม่มีอยู่ใน context นี้ ทั้งที่ปกติเป็น global ของทั้ง browser และ Node.js
**วิธีแก้:** parse query string เอง (`data.split('&').forEach(pair => { const [k,v] = pair.split('='); ... })`) แทนการใช้ `new URLSearchParams(data)`
**ป้องกัน:** Code node อื่นๆ ในโปรเจกต์นี้ทั้งหมดใช้ `require('https')` (Node built-in module) ไม่เคยมีปัญหา — บทเรียนคือ Node **built-in modules** (`https`, `crypto`) ใช้ได้ปกติใน n8n sandbox แต่ **web/global APIs** (`URLSearchParams`, `fetch` แบบ global, `Buffer` ต้องเช็คก่อน) ไม่ชัวร์ว่ามี ต้อง test จริงก่อนเชื่อ หรือเขียน parse เองด้วย string method พื้นฐานจะปลอดภัยกว่าเสมอ
**บริบทงาน:** เป็นส่วนหนึ่งของการเพิ่ม "feedback loop" ให้ QC Line — เก็บว่า inspector ยืนยันว่า AI ตรวจถูกหรือผิด ผ่านปุ่ม LINE Quick Reply → บันทึกลง `qc_inspections.human_feedback` (ดู decisions.md "เริ่มต้น self-improving loop ที่ QC Line ก่อน")

---

## 2026-07-02 (session 19b) — QC Standards: DB Constraint + PowerShell BOM + End-to-End PASS


### 🔴→✅ `qc_standards` table ล็อกไว้แค่ 1 รูปอ้างอิง/หมวด ทั้งที่โค้ดรองรับหลายรูป
**อาการ:** พยายาม insert รูปอ้างอิงเพิ่ม (concrete ref2/ref3 ฯลฯ) แล้วเจอ `ERROR: 23505: duplicate key value violates unique constraint "qc_standards_category_key"`
**Root cause:** ตารางมี `UNIQUE(category)` ตั้งแต่สร้าง — จำกัดไว้ 1 แถว/หมวด โดยไม่ได้ตั้งใจ (โค้ด `qcCallOpenAI()` loop ผ่านหลายรูปได้อยู่แล้ว)
**วิธีแก้:** `apply_migration` ผ่าน Supabase MCP — drop `qc_standards_category_key`, เพิ่ม `UNIQUE(category, photo_url)` แทน
**ผล:** ขยายจาก 4 หมวด (1 รูป/หมวด) เป็น 7 หมวด (14 รูปรวม) — เพิ่มหมวดใหม่ electrical/plumbing/finishing ที่ไม่เคยมีรูปอ้างอิงเลย
**แหล่งรูป:** `D:\Finnhouses brand\` (โฟลเดอร์งานจริง Finnhouses) — เจอเอกสาร QC checklist จริงของบริษัทเป็นของแถม (`02 QC List Revise02 2018.xlsx`, `inspect โครงสร้าง.pdf`) มีเกณฑ์ตัวเลขจริง (concrete ≥200 ksc, คาน L/360, ท่อน้ำ 100 psi) ที่ยังไม่ได้เอาไปใส่ใน QC_SYSTEM_PROMPT (งานค้างสำหรับ session ถัดไป)
**ยังไม่มีรูปอ้างอิง:** structure (มีแต่ PDF checklist ข้อความ), cleanliness (ไม่มีแหล่งข้อมูลเลย)


---

## 🧠 Glossary Snapshot

### Platform Modules
| Term | ความหมาย |
|------|-----------|
| AI Content | Full Content Studio — Claude Haiku + Gemini image gen |
| Blog Runner | n8n 10-stage pipeline → WordPress finnhouses.com |
| Land Analyzer | วิเคราะห์ที่ดิน: ทำเล/Risk/ราคา + AI vision |
| Budget Tool | คำนวณงบสร้างบ้าน + Lead capture → Telegram |
| OS Dashboard / DashboardOS | หน้าภาพรวมระบบทั้งหมด |
| CRM | Lead Kanban 5-stage + 6 tabs: Overview/Content/Saved/Leads/Market/Nurture |
| QC Line | ระบบตรวจงานก่อสร้างผ่าน LINE OA — AI Vision ≤15s |

### Technical Terms
| Term | ความหมาย |
|------|-----------|
| Hub | services/backend-hub — Express server บน Railway = single source of truth |
| n8n | Automation orchestrator — run บน Railway |
| Topic Engine PRO | ระบบเลือก keyword 32 ตัว แบ่ง 4 pool |
| BRAND_FACTS | Lock ป้องกัน hallucinate — ห้ามปั้นราคา/จังหวัดผิด |
| hub-state.json | State file ของ Blog pipeline (ควร migrate → Supabase) |
| Binary Guard | n8n node ที่ sanitize binary ก่อน upload WordPress |
| Publish Guard | n8n node ตรวจ 10 conditions ก่อน create post |
| Vision QA | GPT-4o Vision ตรวจรูปสถาปัตย์ ≥80 pts |
| wf_qc_line | n8n workflow QC Line เวอร์ชันเก่า (11 nodes) — **ปิดไว้เป็น backup** ตั้งแต่ session 19d, ตัวที่ active จริงคือ `wf_qc_line (2)` |
| wf_qc_line (2) | n8n workflow QC Line เวอร์ชันปัจจุบัน (16 nodes) — เพิ่ม Quick Reply ปุ่ม "✅ ตรง / ❌ ไม่ตรง" หลังผลตรวจทุกครั้ง + branch รับ postback บันทึก feedback ผ่าน `POST /api/qc/feedback` |
| human_feedback loop | กลไกเก็บว่า inspector ยืนยันว่าผลตรวจ AI ถูกหรือผิด — คอลัมน์ `human_feedback` (`correct`\|`incorrect`) + `human_feedback_at` ใน `qc_inspections` — จุดเริ่มต้นของ "self-improving loop" (ยังเก็บแค่ raw data ยังไม่มี dashboard สรุป) |
| content_frames | ตาราง Supabase เก็บ Facebook post ("Positioned Content") ที่ AI สร้างจาก Market Intel — คอลัมน์จริง: `frame_text, frame_type, target_segment, target_context, keyword, tone, channel, ...` (ไม่มี `area`/`timing_signal`/`source_type` — เคยพลาดส่ง field พวกนี้ทำให้ insert fail เงียบๆ มาตลอด แก้ session 19e) |
| RLS | Row Level Security ใน Supabase |
| Webhook v2.1 body wrap | n8n Webhook node typeVersion ≥2 จะ wrap POST body ไว้ใน `.body` key — ต้องอ่านด้วย `$input.first().json.body.field` หรือใช้ pattern `const wb = $input.first().json.body \|\| $input.first().json` |
| wb pattern | วิธีอ่าน Webhook payload ที่ใช้ได้ทั้ง v1 และ v2.1: `const wb = $input.first().json.body \|\| $input.first().json;` แล้ว `wb.fieldName` |
| hub_callback_url | URL ที่ Hub ส่งมาพร้อม n8n trigger — รูปแบบ `${HUB_PUBLIC_BASE_URL}/webhook/n8n?token=<HMAC>` — ใช้สำหรับ n8n callback กลับ Hub หลัง publish |
| `.git/index.lock` | ไฟล์ lock ค้างจาก git process ก่อนหน้าที่ crash/ค้าง — แก้ด้วย `Remove-Item ".git\index.lock" -Force` แล้ว retry (Known Bug #3 ใน CLAUDE.md root) |
| Full-repo header/convention audit | เทคนิค verify ว่า migration/revert ครบจริง: `grep -rn "x-hub-token\|x-hub-secret" app/api` (หรือ pattern ที่เกี่ยวข้อง) ทั้ง repo แทนที่จะเชื่อว่าไฟล์ที่จำได้ครบแล้ว |
| qc_standards | ตาราง Supabase เก็บรูปอ้างอิงมาตรฐาน QC — คอลัมน์: category, label_th, photo_url, description, active — รองรับหลายรูป/หมวด (แก้ constraint session 19b) |
| UTF-8 BOM | 3 byte นำหน้าไฟล์ (`\xEF\xBB\xBF`) บอก encoding — จำเป็นสำหรับ `.ps1` ที่มีอักขระไทย ไม่งั้น Windows PowerShell 5.1 อ่านผิด codepage แล้ว parse error (ดู decisions.md) |

### n8n Workflows
| ไฟล์ | ทำอะไร | สถานะ |
|------|---------|-------|
| `Finnhouses WF1 — Article + Publish (4).json` | Blog Runner — Topic Engine PRO 32 keywords, Publish Guard, WP post | ✅ Active (keyword lock ✅) |
| `Finnhouses WF2 — Image + Patch (4_fixed).json` | Image gen → Vision QA → WP upload → Patch featured image → Notify Hub | ✅ Active (x-hub-token fixed Jun 29) |
| `wf_qc_line (1).json` | QC LINE 12-node — sig verify → download → upload Storage → Hub ingest → GPT-4o → LINE reply | ✅ Active (v8 binary ✅) |
| `CRM Note Parser — leads → buyer_context_signals.json` | Parse leads.notes → intent/urgency + buyer_context_signals | ✅ Active (22:00 daily) |
| `FB Post Performance Tracker (3).json` | ดึง FB posts → post_performance → Telegram digest | ✅ Active |
| `Finnhouses — Market Intelligence Collector v1 (1).json` | FB/Manual webhook → Claude parse → Supabase → content_frames → Telegram | ✅ Active |
| `Finnhouses — Telegram → Market Intel.json` | Telegram trigger → Market Intel webhook | ✅ Active |
| `Finnhouses_LINE_Seller_Intake_v6.json` | LINE seller intake → Hub → Supabase → WP image | ✅ Active |
| `Queue Auto-run (FB + Blog) (2).json` | Schedule → /api/fb/queue/run-next + n8n /webhook/blog-run | ✅ Active |
| `Wake-up (09_02 daily.json` | 09:02 daily ping → WordPress + Hub /health + FB Backend /health | ✅ Active |
| `🔍 System Health Check (1).json` | 08:50 daily → Blog Queue status → Telegram | ✅ Active |
| `FB Market Intelligence — Sheet to Supabase (2).json` | Google Sheet → OpenAI parse → Supabase fb_listings | ⏸ Inactive |

---

## 🚫 Hard Rules

- ห้าม call Railway URL โดยตรงจาก client-side code
- ห้าม suggest action ใดๆ โดยไม่มีหลักฐานก่อน
- Never store secrets in code — ใช้ Railway/Vercel env vars เท่านั้น
- n8n Webhook v2.1: ใช้ `wb = $input.first().json.body || $input.first().json` เสมอ
- ห้าม revert fetch() ใน Code node
- ห้าม revert HTTP Request + keypairs สำหรับ endpoint ที่ใช้ express.json()
- Architectural decisions → ChatGPT review ก่อน implement
- Renew secret → update ALL services พร้อมกันก่อน old หมดอายุ
- FB Long-lived token: exchange Short-lived → Long-lived เสมอก่อนเก็บ
- Claude implements, ไม่ตัดสินใจ architecture เอง — document แล้วถาม

---

## 📁 Key Files

| ไฟล์ | ใช้สำหรับ |
|------|-----------|
| `Handoff/HANDOFF.md` | สถานะระบบ + pending ทั้งหมด |
| `Glossary/glossary.md` | คำศัพท์มาตรฐาน + workflow list |
| `Glossary/issues-log.md` | ประวัติปัญหา + วิธีแก้ |
| `Glossary/decisions.md` | Pending decisions |
| `n8n-workflows/` | WF JSON — import เข้า n8n เมื่อ fix |
| `tokens.md` | Token expiry dates |

## 🔗 Key URLs

| Service | URL |
|---------|-----|
| Dashboard | https://ap-home-platform.vercel.app |
| Hub v1 (Prod) | https://ap-home-platform-production.up.railway.app |
| Hub v2 (Shadow) | https://exciting-creativity-production-4b85.up.railway.app |
| n8n | https://primary-production-8158a.up.railway.app |
| WordPress | https://finnhouses.com |
