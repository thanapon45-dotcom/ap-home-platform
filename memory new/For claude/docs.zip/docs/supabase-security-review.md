# Supabase Security Review

Status: Phase 0.5 read-only review
Date: 2026-07-27

## Scope Guard

No Supabase policies, schema, migrations, data, environment variables, or application code were modified.

This review uses repository evidence only. It does not confirm live Supabase project configuration or RLS state.

## Tables Accessed by Next API Routes

| Table / Object | Next Route | Access Pattern | Credential Path | Risk |
| --- | --- | --- | --- | --- |
| `leads` | `/api/leads`, `/api/leads/{id}` | GET, POST, PATCH, DELETE | `SUPABASE_SERVICE_KEY` | Critical: public service-role CRUD surface |
| `reno_deals` | `/api/deals`, `/api/deals/{id}` | GET, POST, PATCH, DELETE | `SUPABASE_SERVICE_KEY` | Critical: public service-role CRUD surface |
| `projects` | `/api/projects` | GET, POST; `?ids=` filter | `SUPABASE_SERVICE_KEY` | Critical: public service-role CRUD surface |
| dynamic table from `?table=` | `/api/market-intel/insights` | GET `select=*` | `SUPABASE_SERVICE_KEY` | High: privileged table exposure |
| `market_insights` | `/api/market-intel/calibration`, `/api/market-intel/feedback` | GET, PATCH | `SUPABASE_SERVICE_KEY` | High: privileged report/feedback path |
| `content_frames` | `/api/chat` | GET prompt context | `SUPABASE_SERVICE_KEY` | Medium/High: context read from public AI route |
| `content_posts` | `/api/content/performance` | GET report query | `SUPABASE_SERVICE_KEY` | Medium: privileged reporting route |
| `post_performance` | `/api/content/performance` | GET report query | `SUPABASE_SERVICE_KEY` | Medium: privileged reporting route |
| `quality_gate_log` | `/api/quality-gate/accuracy`, `/api/quality-gate/feedback` | GET, PATCH | `SUPABASE_SERVICE_KEY` | Medium/High: privileged reporting and feedback |
| `qc_inspections` | `/api/qc/accuracy` | GET report query | `SUPABASE_SERVICE_KEY` | Medium: privileged reporting route |

## Tables / Objects Accessed by Backend Hub

From `services/backend-hub/server.cjs` and `services/backend-hub/src`:

| Table / Object | Hub Area | Access Pattern | Credential Path | Notes |
| --- | --- | --- | --- | --- |
| `hub_state` | Hub state manager | Read/upsert by key | `SUPABASE_SERVICE_KEY` | Expected Hub-owned state table |
| `content_queue` | Blog queue | Queue build/clear/run/callback updates | `SUPABASE_SERVICE_KEY` | Hub-owned workflow state |
| `content_posts` | Blog/FB/content performance | Insert/read/update inferred from source/docs | `SUPABASE_SERVICE_KEY` | Confirm exact production use |
| `post_performance` | Performance tracking | Read in Next, likely written by workflow | mixed/unknown | Live workflow credential review required |
| `qc_inspections` | QC line system | Insert/list/feedback | `SUPABASE_SERVICE_KEY` | Hub v1 implements `/api/qc/*` |
| `quality_gate_log` | Quality gate workflow | Workflow/Next feedback path | mixed/unknown | Docs mention n8n service-role logging |
| `properties` / property intake objects | Property publish/review | Read/update/publish/dismiss | `SUPABASE_SERVICE_KEY` and WordPress | Exact table names should be confirmed |
| `market_insights` | Market intelligence | Report/feedback; workflow inserts likely | mixed/unknown | Dynamic table exposure exists in Next route |
| `market_listings` | `scripts/scrape-market.js` | Upsert via REST | anon fallback in script | Script should not be run without review |
| RPC `append_line_image_atomic` | Property image append | RPC call | `SUPABASE_SERVICE_KEY` | Hub-owned atomic append path |

## Service-Role Usage Locations

| Location | Usage | Target State |
| --- | --- | --- |
| `app/api/leads/*` | CRUD with `SUPABASE_SERVICE_KEY` | Move to Hub; remove from Dashboard runtime |
| `app/api/deals/*` | CRUD with `SUPABASE_SERVICE_KEY` | Move to Hub; remove from Dashboard runtime |
| `app/api/projects/route.ts` | CRUD/read with `SUPABASE_SERVICE_KEY` | Move to Hub; remove from Dashboard runtime |
| `app/api/market-intel/*` | Report/feedback/dynamic table reads with `SUPABASE_SERVICE_KEY` | Move to Hub; enforce allowlisted reports |
| `app/api/content/performance/route.ts` | Reporting query with `SUPABASE_SERVICE_KEY` | Move to Hub Reporting API |
| `app/api/qc/accuracy/route.ts` | Reporting query with `SUPABASE_SERVICE_KEY` | Move to Hub QC API |
| `app/api/quality-gate/*` | Reporting/feedback with `SUPABASE_SERVICE_KEY` | Move to Hub Quality Gate API |
| `app/api/chat/route.ts` | Reads `content_frames` via service role | Move prompt context lookup to Hub AI Gateway |
| `services/backend-hub/*` | Hub-owned service-role data access | Expected final owner, but must be authenticated and audited |
| `scripts/*` | Some scripts include Supabase URL/key fallback or SQL | Must be reviewed before use; do not run against production without approval |
| n8n workflows | Docs mention service-role usage in workflow fixes | Live credential usage pending verification |

## RLS Assumptions

Repository docs repeatedly state that certain tables were locked down and routed through service-role server APIs:

| Table | Repository Assumption | Evidence | Verification Status |
| --- | --- | --- | --- |
| `leads` | RLS locked down; anon denied; service-role proxy used | Comments in `app/api/leads/route.ts`, docs | Needs Supabase live verification |
| `projects` | RLS locked down; service-role proxy used | Comments in `app/api/projects/route.ts`, docs | Needs Supabase live verification |
| `reno_deals` | RLS enabled with dropped anon read policy | Comments in `app/api/deals/route.ts`, docs | Needs Supabase live verification |
| `quality_gate_log` | Server-side service-role reporting/feedback | Route comments/docs | Needs Supabase live verification |
| `market_insights` | Server-side feedback/calibration | Route comments/docs | Needs Supabase live verification |
| `qc_inspections` | Hub/Next service-role reporting | Route comments/docs | Needs Supabase live verification |

Important: repository comments are not proof of live RLS policies. Production Supabase policy inspection is required before implementation approval.

## Potential Privileged Access Paths

| Path | Risk | Recommended Direction |
| --- | --- | --- |
| Public Next CRUD routes with service-role key | Full data read/write/delete if exposed without auth | Move to Hub and require auth/authorization |
| `/api/market-intel/insights?table=` | Privileged dynamic table reads | Remove dynamic table names; Hub report endpoints only |
| `/api/chat` reading `content_frames` and calling Anthropic | Public AI spend plus service-role context read | Hub AI Gateway with auth, quota, logging |
| n8n workflows with direct service-role credentials | Workflow compromise can bypass app authorization | Inventory credentials; move to Hub-scoped operations where possible |
| Scripts with embedded anon fallback | Accidental writes to production if run locally | Remove hardcoded key fallback in a separately approved implementation phase |
| `/api/n8n` with n8n API key | Potential admin workflow disclosure/control | Protect or move to Hub admin/ops route |

## Required Live Supabase Verification

- Confirm production Supabase project ref.
- Confirm current RLS enabled/disabled state for listed tables.
- Confirm active policies for anon/authenticated/service roles.
- Confirm whether Dashboard production env contains `SUPABASE_SERVICE_KEY`.
- Confirm whether n8n credentials include service-role key.
- Confirm recent writes by source, if audit logs are available.
- Confirm backup status before protected implementation.

## Conclusion

Supabase production security cannot be approved from repository evidence alone. The major repository-confirmed issue is privileged service-role access in Dashboard-owned Next API routes. Live Supabase policy and credential verification is required before ADR-006 implementation.
