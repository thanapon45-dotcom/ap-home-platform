# AP Home Platform Security & Architecture Remediation Plan

Status: Proposal only. No code changes approved.
Date: 2026-07-27

Implementation rule: no runtime code, database schema, environment, deployment, or workflow changes are allowed until this proposal is explicitly approved.

## 1. Executive Summary

AP Home Platform currently has several Next.js API routes acting as privileged backend services. These routes use `SUPABASE_SERVICE_KEY` or paid AI provider keys directly from the Dashboard layer, which bypasses the intended Hub-centric architecture.

Severity summary:

| Severity | Area | Production Impact |
| --- | --- | --- |
| Critical | Public service-role CRUD endpoints | Unauthorized users may read, create, update, or delete CRM, deal, and project data while bypassing Supabase RLS. |
| High | Market Intelligence table exposure | A public query parameter can select privileged Supabase tables through service-role access. |
| High | AI endpoint abuse | Public callers can trigger paid Anthropic, OpenAI, Gemini, or Ideogram requests without auth, quota, or rate limits. |
| Medium | SSRF in blog fetcher | Server can be made to fetch attacker-supplied URLs, including possible internal/private network targets. |
| Medium | XSS in AI Content UI | External titles are rendered as raw HTML. |

Why this must be fixed:

- Service-role keys intentionally bypass RLS and must only live behind trusted business logic.
- The Dashboard is currently doing work that belongs in Backend Hub.
- Public AI endpoints create direct cost and abuse exposure.
- The architecture has drifted away from the intended production control plane.

The recommended direction is to preserve the production UI while moving business logic, privileged database access, AI orchestration, auth, authorization, logging, and quota controls into Backend Hub.

### ADR-006 Requirement

This architecture change requires a formal ADR before implementation begins.

Required ADR:

```text
docs/ADR/ADR-006-hub-centric-security-remediation.md
```

ADR-006 must document:

- Decision to restore Backend Hub as the owner of business logic, privileged database access, authentication, authorization, and AI orchestration.
- Explicit rejection of Dashboard-owned service-role CRUD as a long-term architecture.
- Migration strategy from Next API routes to Hub-owned APIs.
- Compatibility period and removal criteria for legacy Next API routes.
- Security acceptance criteria for production rollout.
- Rollback strategy.

ADR-006 must be reviewed and approved before any implementation work starts.

## 1.1 Non-Goals

This remediation is intentionally scoped. It must not become a rewrite or unnecessary redesign.

Non-goals:

- Do not rewrite the entire AP Home Platform.
- Do not redesign the Dashboard UI unless required to preserve existing workflows.
- Do not remove Backend Hub.
- Do not move business logic back into the frontend.
- Do not replace Supabase as the data layer.
- Do not change database schema without a separate migration plan and rollback plan.
- Do not change n8n workflows unless a specific dependency requires it.
- Do not introduce a new authentication vendor or infrastructure dependency without explicit approval.
- Do not optimize unrelated code, visual design, or copy as part of this security remediation.

## 2. Current Architecture Analysis

### Current State

```text
Current State

Next Dashboard
        |
        +---- Next API routes acting as backend
        |          |
        |          +---- Supabase via SUPABASE_SERVICE_KEY
        |          +---- AI Providers via provider API keys
        |          +---- external fetch targets
        |
        +---- Backend Hub for selected workflow/proxy paths
                   |
                   +---- Supabase
                   +---- AI Providers
                   +---- n8n
```

### API Routes Acting as Backend

These routes contain backend/business behavior in the Dashboard layer:

| Route | Responsibility |
| --- | --- |
| `app/api/leads/route.ts` | Lead list and create |
| `app/api/leads/[id]/route.ts` | Lead update and delete |
| `app/api/deals/route.ts` | Deal list and create |
| `app/api/deals/[id]/route.ts` | Deal update and delete |
| `app/api/projects/route.ts` | Project list and create |
| `app/api/market-intel/insights/route.ts` | Market insight table reads |
| `app/api/content/performance/route.ts` | Content performance aggregation |
| `app/api/quality-gate/accuracy/route.ts` | Quality gate reporting |
| `app/api/qc/accuracy/route.ts` | QC reporting |
| `app/api/chat/route.ts` | Claude chat generation |
| `app/api/ai/route.ts` | Anthropic content generation |
| `app/api/image/route.ts` | Image generation orchestration |
| `app/api/fetch-blog/route.ts` | Server-side external URL fetch |

### Routes Using `SUPABASE_SERVICE_KEY`

Observed service-role usage:

| Route | Access Pattern |
| --- | --- |
| `app/api/leads/route.ts` | Read/create `leads` |
| `app/api/leads/[id]/route.ts` | Update/delete `leads` |
| `app/api/deals/route.ts` | Read/create `reno_deals` |
| `app/api/deals/[id]/route.ts` | Update/delete `reno_deals` |
| `app/api/projects/route.ts` | Read/create `projects` |
| `app/api/market-intel/insights/route.ts` | Dynamic table read |
| `app/api/content/performance/route.ts` | Read `content_posts` and `post_performance` |
| `app/api/quality-gate/accuracy/route.ts` | Read quality gate logs |
| `app/api/quality-gate/feedback/route.ts` | Patch quality gate feedback |
| `app/api/qc/accuracy/route.ts` | Read QC inspections |
| `app/api/market-intel/calibration/route.ts` | Read market insight calibration data |
| `app/api/market-intel/feedback/route.ts` | Patch market insight feedback |
| `app/api/chat/route.ts` | Read `content_frames` for prompt context |

### Routes Calling AI Providers

| Route | Provider / Function |
| --- | --- |
| `app/api/chat/route.ts` | Anthropic Messages API |
| `app/api/ai/route.ts` | Anthropic Messages API |
| `app/api/image/route.ts` | OpenAI, Gemini, Ideogram image generation |

### Routes Bypassing Backend Hub

These routes talk directly to Supabase or AI providers instead of delegating to Backend Hub:

| Route | Bypass Type |
| --- | --- |
| `app/api/leads/*` | Direct database CRUD |
| `app/api/deals/*` | Direct database CRUD |
| `app/api/projects/route.ts` | Direct database CRUD |
| `app/api/market-intel/insights/route.ts` | Direct database read |
| `app/api/content/performance/route.ts` | Direct reporting query |
| `app/api/quality-gate/*` | Direct reporting/feedback query |
| `app/api/qc/accuracy/route.ts` | Direct reporting query |
| `app/api/market-intel/calibration/route.ts` | Direct reporting query |
| `app/api/market-intel/feedback/route.ts` | Direct feedback update |
| `app/api/chat/route.ts` | Direct AI call and direct Supabase context read |
| `app/api/ai/route.ts` | Direct AI call |
| `app/api/image/route.ts` | Direct AI image provider calls |

### Production Dependency Map

This map must be validated against production logs, browser calls, and n8n workflows before implementation.

| Route | Current Owner | Consumer | Target Owner | Migration Status |
| --- | --- | --- | --- | --- |
| `app/api/leads/route.ts` | Next Dashboard API | CRM, Budget/lead intake, CSV/import flows if present | Backend Hub Lead API | Pending inventory |
| `app/api/leads/[id]/route.ts` | Next Dashboard API | CRM lead edit/delete actions | Backend Hub Lead API | Pending inventory |
| `app/api/deals/route.ts` | Next Dashboard API | Deals pipeline UI | Backend Hub Deal API | Pending inventory |
| `app/api/deals/[id]/route.ts` | Next Dashboard API | Deals edit/delete actions | Backend Hub Deal API | Pending inventory |
| `app/api/projects/route.ts` | Next Dashboard API | Land Analyzer, Deals linked project lookup | Backend Hub Project API | Pending inventory |
| `app/api/market-intel/insights/route.ts` | Next Dashboard API | Market Intel UI | Backend Hub Market Intel report API | Pending inventory |
| `app/api/content/performance/route.ts` | Next Dashboard API | Content Performance UI | Backend Hub Reporting API | Pending inventory |
| `app/api/quality-gate/accuracy/route.ts` | Next Dashboard API | Quality Gate UI | Backend Hub QC/Quality report API | Pending inventory |
| `app/api/quality-gate/feedback/route.ts` | Next Dashboard API | Quality Gate feedback UI | Backend Hub QC/Quality feedback API | Pending inventory |
| `app/api/qc/accuracy/route.ts` | Next Dashboard API | QC Accuracy UI | Backend Hub QC report API | Pending inventory |
| `app/api/market-intel/calibration/route.ts` | Next Dashboard API | Market Intel calibration UI | Backend Hub Market Intel report API | Pending inventory |
| `app/api/market-intel/feedback/route.ts` | Next Dashboard API | Market Intel feedback UI | Backend Hub Market Intel feedback API | Pending inventory |
| `app/api/chat/route.ts` | Next Dashboard API | CRM tabs, AI Content, image concept generation | Backend Hub AI Gateway | Pending inventory |
| `app/api/ai/route.ts` | Next Dashboard API | AI Content generation UI | Backend Hub AI Gateway | Pending inventory |
| `app/api/image/route.ts` | Next Dashboard API | AI image generation UI | Backend Hub AI Gateway | Pending inventory |
| `app/api/fetch-blog/route.ts` | Next Dashboard API | AI Content / blog import UI | Backend Hub Fetch/Content Import API or hardened Next compatibility route | Pending inventory |
| `app/api/blog/*` | Mixed Next proxy to Hub | Dashboard blog controls | Backend Hub Blog API | Existing Hub path, verify |
| `app/api/fb/*` | Mixed Next proxy to Hub/FB backend | Dashboard FB controls | Backend Hub/Facebook backend | Existing proxy path, verify |
| `app/api/property/*` | Mixed Next proxy to Hub | Property review/publishing UI | Backend Hub Property API | Existing proxy path, verify |

## 3. Security Findings Mapping

### Critical: Public Service-Role CRUD Endpoints

Files:

```text
app/api/leads/route.ts
app/api/leads/[id]/route.ts
app/api/deals/route.ts
app/api/deals/[id]/route.ts
app/api/projects/route.ts
```

Problems:

- No user authentication.
- No authorization.
- Supabase RLS is bypassed by `SUPABASE_SERVICE_KEY`.
- Request bodies are forwarded to Supabase with minimal validation.
- Public deployment exposure can become full data compromise.

Recommended fix: Option A, move logic into Backend Hub.

Trade-off:

| Option | Pros | Cons | Recommendation |
| --- | --- | --- | --- |
| A. Move logic into Backend Hub | Restores architecture, centralizes auth/business rules, keeps service role in one trusted service, easier logging and rate limiting | Requires API contract work and frontend route updates | Recommended |
| B. Add authentication layer to Next API | Faster patch, smaller immediate frontend change | Preserves architecture drift, duplicates auth/business rules, leaves Dashboard as privileged backend | Temporary only if emergency hotfix is needed |

Proposed remediation:

- Add Hub endpoints for lead, deal, and project CRUD.
- Put schema validation and authorization in Hub.
- Keep Next routes only as thin compatibility proxies during migration, or remove them after frontend cutover.
- Reject unauthenticated requests before any service-role operation.

### High: Market Intelligence Table Exposure

File:

```text
app/api/market-intel/insights/route.ts
```

Problem:

```text
?table=
```

The route interpolates the client-provided table name into a privileged Supabase REST query.

Proposed remediation:

- Immediate containment: replace dynamic `table` with an allowlist such as `market_insights`, `market_feedback`, or other explicitly approved read models.
- Add schema validation for query params.
- Prefer moving query responsibility to Hub so the Dashboard requests named reports, not raw table names.
- Return curated DTOs instead of `select=*`.

### High: AI Endpoint Abuse

Files:

```text
app/api/chat/route.ts
app/api/ai/route.ts
app/api/image/route.ts
```

Problems:

- No authentication.
- No rate limit.
- No quota control.
- No centralized usage logging.
- Public callers can create direct AI API spend.

Proposed remediation:

- Move AI orchestration to Backend Hub.
- Add AI gateway endpoints in Hub for text and image generation.
- Enforce user/session or internal secret auth.
- Add usage logging by route, user, feature, provider, model, estimated tokens, and cost.
- Add token budget and request limits per day.
- Add model allowlists and max payload size.
- Keep provider API keys only in Hub runtime.

### Medium: SSRF

File:

```text
app/api/fetch-blog/route.ts
```

Problems:

- Accepts arbitrary `http*` URLs.
- Server performs outbound fetch.
- No private IP blocking.
- No domain allowlist.
- No content size limit.

Proposed remediation:

- Restrict to approved domains, initially `finnhouses.com` and explicit subdomains if required.
- Resolve hostnames and block private, loopback, link-local, metadata, and localhost ranges.
- Enforce response content-type and max content length.
- Keep timeout.
- Log rejected URLs without logging secrets or full private payloads.

### Medium: XSS

File:

```text
components/AIContent.tsx
```

Problems:

- `dangerouslySetInnerHTML` renders external title content.
- Titles may come from WordPress, scraped data, or third-party feeds.

Proposed remediation:

- Prefer rendering titles as plain text.
- If HTML entities are required, decode entities server-side or client-side and render text.
- If formatting is genuinely required, sanitize with a narrow allowlist before rendering.

## 4. Proposed Target Architecture

```text
Target State

Next Dashboard
        |
        | Authenticated UI requests
        v
Backend Hub
        |
        +----------------+
        |                |
        v                v
   Supabase            AI Providers
   Data Layer          Text/Image
        |
        v
      n8n
 Workflow Layer
```

### API Ownership

| Layer | Owns |
| --- | --- |
| Next Dashboard | UI rendering, user interactions, thin calls to Hub |
| Backend Hub | Business rules, authentication, authorization, validation, AI orchestration, privileged database access |
| Supabase | Data persistence, RLS safety net, storage/query layer |
| n8n | Workflow automation called by Hub or approved webhook paths |

### Authentication Flow

Recommended flow:

1. User accesses Dashboard.
2. Dashboard obtains authenticated session or internal operator token.
3. Dashboard calls Backend Hub.
4. Hub validates authentication and authorization.
5. Hub executes business operation against Supabase, AI provider, or n8n.
6. Hub returns curated response DTOs.

Interim compatibility flow:

1. Dashboard calls existing Next API route.
2. Next API route validates auth.
3. Next API route forwards request to Hub.
4. Hub performs privileged work.
5. Next API route returns response.

The interim flow should be time-boxed and removed after frontend cutover.

### Data Flow

- CRUD data: Dashboard -> Hub -> Supabase.
- AI generation: Dashboard -> Hub AI Gateway -> AI Provider -> Hub usage log -> Dashboard.
- Market intelligence: Dashboard -> Hub report endpoint -> Supabase curated queries.
- n8n workflows: Dashboard -> Hub -> n8n, or n8n -> Hub webhook with verified secret.

### Secret Management

- `SUPABASE_SERVICE_KEY` must exist only in Backend Hub and trusted server runtime.
- AI provider keys must exist only in Backend Hub.
- Public Dashboard env vars should be limited to public URLs and non-secret config.
- Hub secret headers must be consistent and verified with timing-safe comparison where applicable.

## 5. Implementation Plan

### Migration Safety Model

The migration must progress through three controlled modes. Each route family should move independently so production behavior can be observed before enforcement.

#### Observe Mode

Purpose: learn real production usage before blocking or changing behavior.

Rules:

- Keep existing behavior active.
- Add request logging, route ownership tags, consumer identification where possible, and auth-readiness checks.
- Record anonymous usage, n8n usage, Dashboard usage, payload shape, response shape, latency, and error rates.
- Do not reject requests solely because they fail future-state auth rules.
- Do not remove legacy routes.

Exit criteria:

- Known consumers are mapped.
- Contract snapshots exist for critical routes.
- No unknown high-volume callers remain unexplained.

#### Protected Mode

Purpose: enforce security while preserving production workflows.

Rules:

- Require authentication, internal service token, or approved Hub secret before privileged operations.
- Route newly migrated operations through Backend Hub.
- Keep compatibility proxies for existing Dashboard paths where needed.
- Add allowlists, validation, rate limits, and cost controls.
- Keep rollback path to legacy behavior only behind an explicitly controlled emergency flag.

Exit criteria:

- Anonymous access to service-role CRUD and AI spend is blocked.
- Dashboard workflows pass regression tests.
- Hub logs prove successful production traffic handling.

#### Legacy Removal Mode

Purpose: remove architecture drift after the Hub-owned path is stable.

Rules:

- Remove or deprivilege old Next API routes that contain business logic, service-role access, or provider keys.
- Remove temporary compatibility flags after the agreed observation window.
- Remove service-role and AI provider secrets from Dashboard runtime if no longer needed.
- Keep only thin UI-facing routes when there is a deliberate platform reason.

Exit criteria:

- Dashboard no longer owns privileged business operations.
- Backend Hub owns CRUD, AI orchestration, and authorization.
- Production monitoring shows no calls to removed legacy paths.

### Phase 1: Security Critical Fix

Goal: reduce immediate production exposure without full rewrite.

Tasks:

- Add authentication/authorization gate before all service-role Next API routes.
- Disable or restrict public service-role CRUD endpoints.
- Add allowlist to `market-intel/insights`.
- Add coarse rate limits or temporary shared internal secret for AI endpoints until Hub migration is complete.
- Remove or guard dynamic `select=*` access patterns where possible.

Exit criteria:

- Anonymous users cannot read or mutate leads, deals, or projects.
- Anonymous users cannot trigger AI spend.
- Dynamic table names are not accepted.

### Phase 2: Architecture Alignment

Goal: move business logic to Backend Hub.

Tasks:

- Implement Hub CRUD endpoints for leads, deals, and projects.
- Implement Hub market intelligence report endpoints.
- Implement Hub AI gateway for text and image generation.
- Move validation schemas into Hub.
- Update Dashboard calls to use Hub contracts.
- Keep compatibility proxies only during cutover.
- Remove service-role key usage from Dashboard API routes after cutover.

Exit criteria:

- Dashboard does not call Supabase with service-role access.
- Dashboard does not call AI providers directly.
- Hub owns business rules and AI orchestration.

### Phase 3: Hardening

Goal: make the corrected architecture resilient.

Tasks:

- Add SSRF protection to blog fetch behavior or move it into Hub.
- Remove unnecessary `dangerouslySetInnerHTML`.
- Add rate limiting by user, IP, feature, and provider.
- Add AI usage and cost monitoring.
- Add structured audit logs for privileged operations.
- Add API security tests.
- Add build and regression verification.

Exit criteria:

- Security-sensitive endpoints have tests.
- Usage/cost logs exist for AI routes.
- Build verification passes for Dashboard and Backend Hub.

## 6. Risk Assessment

### Risk Matrix

| Risk | Category | Likelihood | Impact | Mitigation |
| --- | --- | --- | --- | --- |
| Frontend breaks due to API contract change | Technical | Medium | High | Use compatibility proxies, migrate one feature at a time, add regression tests. |
| Existing CRM workflows fail after auth gate | Business | Medium | High | Inventory current callers, add approved service tokens for automation, test CRM flows before deploy. |
| Lead data cannot be accessed by operators | Business | Low-Medium | High | Stage auth rollout, keep rollback flag for route forwarding. |
| Data loss from CRUD migration bug | Migration | Low | Critical | No schema rewrite in Phase 1, backup tables before Phase 2, test with staging data. |
| AI generation UX slows due to Hub routing | Technical | Low | Medium | Use Hub timeouts, async job pattern for image generation if needed. |
| n8n workflow loses access after endpoint lockdown | Business | Medium | Medium | Identify n8n callers and issue scoped Hub tokens before enforcement. |
| Cost logging inaccurate initially | Technical | Medium | Low | Start with estimated token/cost logs, reconcile later with provider reports. |

### Technical Risks

- Database migration risk if Hub endpoints require schema changes.
- Existing frontend may depend on exact JSON shapes from Next API routes.
- API contract changes can break CRM, Deals, Land Analyzer, AI Content, and Market Intel screens.
- Backend Hub deployment must be stable before traffic is moved.
- Current root Next build cannot be verified until frontend dependencies are repaired.

### Business Risks

- CRM may become temporarily unusable if auth is enforced before callers are updated.
- Lead intake or CSV import may fail if POST contracts change.
- Deals pipeline may stop updating during migration.
- Production downtime is possible if Dashboard and Hub are deployed out of order.
- AI Content Studio may be temporarily unavailable while AI gateway is moved.

### Migration Risk

Backup requirements:

- Backup `leads`.
- Backup `reno_deals`.
- Backup `projects`.
- Backup market intelligence tables used by current UI.
- Export current environment variables and route configuration.

Rollback approach:

- Phase 1 rollback: restore previous Next route behavior behind an emergency feature flag or revert the auth-gate commit.
- Phase 2 rollback: keep compatibility proxies until Hub endpoints are verified; switch Dashboard base URL back to previous route layer if needed.
- Database rollback: avoid destructive schema changes in early phases; if schema changes are required later, prepare additive migrations and rollback SQL before deployment.

## 7. Budget / Resource Estimate

### Development Effort

| Task | Estimated Time | Complexity | Risk |
| --- | --- | --- | --- |
| Inventory all callers and route contracts | 2-4 hours | Medium | Medium |
| Add emergency auth gates to critical Next API routes | 4-8 hours | Medium | High |
| Add `market-intel/insights` allowlist and validation | 1-2 hours | Low | Medium |
| Add temporary AI endpoint auth/rate limit | 3-6 hours | Medium | Medium |
| Move Lead CRUD to Hub | 6-10 hours | Medium | Medium |
| Move Deal CRUD to Hub | 6-10 hours | Medium | Medium |
| Move Project CRUD to Hub | 4-8 hours | Medium | Medium |
| Move Market Intelligence reports to Hub | 6-12 hours | Medium | Medium |
| Build Hub AI gateway | 10-20 hours | High | High |
| Add AI usage logging and daily budgets | 6-12 hours | Medium | Medium |
| Add SSRF protections | 3-6 hours | Medium | Medium |
| Remove/sanitize raw HTML rendering | 1-3 hours | Low | Low |
| Add API security/regression tests | 8-16 hours | Medium | Medium |
| Production deployment and rollback rehearsal | 4-8 hours | Medium | High |
| Migration contingency buffer | 12-24 hours | Medium | High |

Estimated total:

- Phase 1: 1-2 engineering days.
- Phase 2: 3-6 engineering days.
- Phase 3: 2-4 engineering days.
- Contingency buffer: 1.5-3 engineering days for unknown consumers, production-only route usage, auth rollout issues, build repair, and rollback rehearsal.
- Total including contingency: 7.5-15 engineering days depending on current Hub readiness, production dependency findings, and test coverage.

### Cost Impact

| Area | Expected Impact |
| --- | --- |
| AI API cost | Should decrease or become controlled after auth, quota, and usage limits. |
| Infrastructure | No required increase if Backend Hub has capacity. Possible minor increase if AI image jobs require longer execution or background processing. |
| Database | No additional cost expected for Phase 1. Minimal impact from audit/usage log tables if added later. |
| Additional services | None required for Phase 1. Rate limiting can start in-memory or database-backed; Redis/Upstash would be optional later. |

Additional monthly cost: $0 for Phase 1 if existing infrastructure is used.

Potential future optional cost:

- Redis/rate-limit service: only if production traffic needs distributed rate limiting.
- Observability/log storage: only if current logging is insufficient.

## 8. Testing Plan

Before production:

| Test Type | Required Coverage |
| --- | --- |
| Unit test | Hub validation schemas, authorization checks, AI budget calculation, URL safety checks. |
| API security test | Anonymous requests to leads/deals/projects must return 401/403. Dynamic market table names must be rejected. |
| Authentication test | Valid operator/session can perform approved actions. Invalid or missing token cannot. |
| Authorization test | Non-admin role cannot delete or mutate restricted resources. |
| Regression test | CRM lead list/create/update/delete, Deals CRUD, Project create/list, Market Intel reads, AI Content generation. |
| SSRF test | Reject localhost, private IPs, link-local, metadata IPs, and unapproved domains. |
| XSS test | Titles containing HTML/script are rendered as inert text. |
| Build verification | `npm.cmd run build` for Dashboard and `npm.cmd run build:check` for Backend Hub. |

Known verification blocker:

- Current Dashboard build fails because `node_modules/next/dist/bin/next` is missing. Dependencies must be repaired before reliable frontend build verification.

## 9. Migration Order

Recommended order:

1. Freeze risky surface: avoid adding new Dashboard API routes that use service-role keys or AI provider keys.
2. Repair frontend dependency install so `npm.cmd run build` can run.
3. Inventory Dashboard callers for leads, deals, projects, market intel, and AI routes.
4. Add Phase 1 auth gates and allowlists to current production routes.
5. Add Hub CRUD endpoints for leads.
6. Migrate Dashboard lead calls to Hub.
7. Add Hub CRUD endpoints for deals.
8. Migrate Dashboard deal calls to Hub.
9. Add Hub CRUD/report endpoints for projects and market intelligence.
10. Migrate Dashboard project and market intel calls to Hub.
11. Add Hub AI gateway and usage logging.
12. Migrate Dashboard AI and image generation calls to Hub.
13. Remove or deprivilege old Next API routes.
14. Add SSRF and XSS hardening.
15. Run full regression and production rollback rehearsal.

## 10. Approval Gate

### Production Approval Checklist

Before implementation approval:

- [ ] Current production backup verified
- [ ] Frontend build repaired and passing
- [ ] Backend Hub build passing
- [ ] Route dependency inventory reviewed
- [ ] Rollback procedure tested
- [ ] Owner of each migrated module confirmed
- [ ] No production-impacting change starts without approval

Remediation plan completed.

Waiting for approval before implementation.

No code changes, schema changes, environment changes, deployment changes, or n8n workflow changes are allowed until approval is granted.
