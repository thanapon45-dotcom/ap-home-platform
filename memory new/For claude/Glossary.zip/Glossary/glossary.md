# Glossary — Finnhouses

## Platform Modules
| Term | ความหมาย |
|------|-----------|
| AI Content | Full Content Studio — Claude Haiku + Gemini image gen |
| Blog Runner | n8n 10-stage pipeline → WordPress finnhouses.com |
| Land Analyzer | วิเคราะห์ที่ดิน: ทำเล/Risk/ราคา + AI vision |
| Budget Tool | คำนวณงบสร้างบ้าน + Lead capture → Telegram |
| OS Dashboard / DashboardOS | หน้าภาพรวมระบบทั้งหมด |
| CRM | Lead Kanban 5-stage + 6 tabs: Overview/Content/Saved/Leads/Market/Nurture |
| QC Line | ระบบตรวจงานก่อสร้างผ่าน LINE OA — AI Vision ≤15s |

## Technical Terms
| Term | ความหมาย |
|------|-----------|
| Hub | services/backend-hub — Express server บน Railway = single source of truth |
| n8n | Automation orchestrator — run บน Railway |
| Topic Engine PRO | ระบบเลือก keyword 32 ตัว แบ่ง 4 pool |
| BRAND_FACTS | Lock ป้องกัน hallucinate — ห้ามปั้นราคา/จังหวัดผิด |
| hub-state.json | State file ของ Blog pipeline (ควร migrate → Supabase) |
| Binary Guard | n8n node ที่ sanitize binary ก่อน upload WordPress |
| Publish Guard | n8n node ตรวจ 10 conditions ก่อน create post |
| Vision QA | GPT-4o Vision ตรวจรูปสถาปัตย์ ≥80 pts |
| wf_qc_line | n8n workflow QC Line เวอร์ชันเก่า (11 nodes) — **ปิดไว้เป็น backup** ตั้งแต่ session 19d, ตัวที่ active จริงคือ `wf_qc_line (2)` |
| wf_qc_line (2) | n8n workflow QC Line เวอร์ชันปัจจุบัน (16 nodes) — เพิ่ม Quick Reply ปุ่ม "✅ ตรง / ❌ ไม่ตรง" หลังผลตรวจทุกครั้ง + branch รับ postback บันทึก feedback ผ่าน `POST /api/qc/feedback` |
| human_feedback loop | กลไกเก็บว่า inspector ยืนยันว่าผลตรวจ AI ถูกหรือผิด — คอลัมน์ `human_feedback` (`correct`\|`incorrect`) + `human_feedback_at` ใน `qc_inspections` — จุดเริ่มต้นของ "self-improving loop" (ยังเก็บแค่ raw data ยังไม่มี dashboard สรุป) |
| content_frames | ตาราง Supabase เก็บ Facebook post ("Positioned Content") ที่ AI สร้างจาก Market Intel — คอลัมน์จริง: `frame_text, frame_type, target_segment, target_context, keyword, tone, channel, ...` (ไม่มี `area`/`timing_signal`/`source_type` — เคยพลาดส่ง field พวกนี้ทำให้ insert fail เงียบๆ มาตลอด แก้ session 19e). **ตั้งแต่ session 22 (Jul 8):** เพิ่ม `signals JSONB` (9 keys), `positioned_content`, `ai_summary`, `collector_version` — แถวใหม่ทั้งหมดมี `collector_version:"v2"` เขียนโดย Market Intelligence Collector v2 (ADR-005) ดู `CORE/ap-home-platform/docs/decisions.md` ADR-005 |
| signals (JSONB) | field ใหม่ใน `content_frames` (session 22) — 9 keys เสมอ: 8 มาจาก Claude Haiku ต่อโพสต์ (`demand/price/offer/finance/value/location/urgency/seller_motivation`) + `liquidity` ที่**บังคับด้วยโค้ดเสมอ ไม่ใช่ LLM-generated** จนกว่า Hub aggregation job จะสร้าง แต่ละ key มี `level/confidence/evidence/rubric_note/source_scope` |
| maxTokens (Market Intel) | token budget ต่อ Claude Haiku call ใน Parse node — ปัจจุบัน **3000** (เพิ่มจาก 1600 หลัง ISSUE-010, session 22) โพสต์ยาว/ละเอียดเสี่ยงชนค่านี้แล้ว JSON ถูกตัดกลางคำ — เช็คได้จาก `raw_model_text_debug` |
| RLS | Row Level Security ใน Supabase |
| Webhook v2.1 body wrap | n8n Webhook node typeVersion ≥2 จะ wrap POST body ไว้ใน `.body` key — ต้องอ่านด้วย `$input.first().json.body.field` หรือใช้ pattern `const wb = $input.first().json.body \|\| $input.first().json` |
| wb pattern | วิธีอ่าน Webhook payload ที่ใช้ได้ทั้ง v1 และ v2.1: `const wb = $input.first().json.body \|\| $input.first().json;` แล้ว `wb.fieldName` |
| hub_callback_url | URL ที่ Hub ส่งมาพร้อม n8n trigger — รูปแบบ `${HUB_PUBLIC_BASE_URL}/webhook/n8n?token=<HMAC>` — ใช้สำหรับ n8n callback กลับ Hub หลัง publish |
| `.git/index.lock` | ไฟล์ lock ค้างจาก git process ก่อนหน้าที่ crash/ค้าง — แก้ด้วย `Remove-Item ".git\index.lock" -Force` แล้ว retry (Known Bug #3 ใน CLAUDE.md root) |
| Full-repo header/convention audit | เทคนิค verify ว่า migration/revert ครบจริง: `grep -rn "x-hub-token\|x-hub-secret" app/api` (หรือ pattern ที่เกี่ยวข้อง) ทั้ง repo แทนที่จะเชื่อว่าไฟล์ที่จำได้ครบแล้ว |
| qc_standards | ตาราง Supabase เก็บรูปอ้างอิงมาตรฐาน QC — คอลัมน์: category, label_th, photo_url, description, active — รองรับหลายรูป/หมวด (แก้ constraint session 19b) |
| UTF-8 BOM | 3 byte นำหน้าไฟล์ (`\xEF\xBB\xBF`) บอก encoding — จำเป็นสำหรับ `.ps1` ที่มีอักขระไทย ไม่งั้น Windows PowerShell 5.1 อ่านผิด codepage แล้ว parse error (ดู decisions.md) |

## Facebook
| Term | ความหมาย |
|------|-----------|
| FB Token | Facebook Access Token — เก็บใน n8n Credentials |
| Page Token | Token เฉพาะ Page (ไม่ใช่ User Token) — ต้องใช้อันนี้ |
| Long-lived token | Token อายุ 60 วัน |
| Graph Explorer | developers.facebook.com/tools/explorer |
| FB App | ชื่อ "Finnhouses" ใน Facebook Developers |

## Content (AI Content Studio)
| Term | ความหมาย |
|------|-----------|
| Tone | เป็นกันเอง / มืออาชีพ / Educate / สนุกสนาน |
| Slot | Morning / Evening — เวลาโพสต์ |
| Visual Style | contemporary / nordic / luxury / minimal / loft / modern_tropical (lowercase!) |
| FB Post | โพสต์ Facebook 1:1 |
| FB Story | Story format |
| 4 pools | Budget (cat10) · Design (cat13) · Service (cat12) · Land (cat14) |

## System Flow Visualizer
| Term | ความหมาย |
|------|-----------|
| ap-home-system-flow.html | Interactive HTML flow diagram — แสดง step-by-step ระบบทำงานจริงของ AP-Home Platform OS |
| AIC_TAB_STEPS | Object 6 keys (keyword/blog/listing/history/queue/intel) — step arrays สำหรับ AI Content แต่ละ tab |
| AIC_TAB_PANELS | Object 6 keys — HTML controls panel จำลอง UI จริงของ /ai-content |
| setAicTab(tab) | Function ที่ reset flow + render panel ใหม่เมื่อ click AI Content tab |
| Orthogonal routing | SVG path แบบ H→V→H (ไม่มีเส้นทแยง) — standard ของ flow diagram |
| BLOG_AUTO_STEPS | Step array สำหรับ Blog Runner mode Auto (n8n Cron 09:05) |
| BLOG_MANUAL_STEPS | Step array สำหรับ Blog Runner mode Manual (user trigger) |
| SVC_POS | Object ตำแหน่ง % ของ service node บน canvas (px/py fields) |

## Supabase Tables
| Table | ใช้สำหรับ |
|-------|-----------|
| leads | Budget form submissions — fields: id, notes, intent, urgency, parsed_at |
| projects | Project status ทั้งหมด |
| qc_inspections | QC Line results |
| qc_defects | Defect details per inspection |
| sites | LINE OA sites |
| line_users | LINE user mapping |
| post_performance | FB post metrics — post_id, message, created_time, likes, comments, shares, reach |
| buyer_context_signals | Parsed buyer intelligence จาก notes — trigger_type, awareness_level, emotional_need, content_angle, urgency, lead_id, created_at |
| market_insights | Market Intel records — area, insight, category, confidence, source_type, notes |
| content_frames | Positioned content จาก Market Intel — area, target_segment, keyword, frame_text, timing_signal, source_type |

## n8n Workflows
> อัพเดท: Jun 29, 2026 — จาก live n8n export | ไฟล์อยู่ที่ `memory/n8n-workflows/`

| ไฟล์ | ทำอะไร | สถานะ |
|------|---------|-------|
| `Finnhouses WF1 — Article + Publish (9_queue_sync_fix).json` | Blog Runner — Topic Engine PRO 32 keywords, Publish Guard, WP post | ✅ Active (session 24, Jul 13 — slug fallback fix + Notify Hub Blocked + queue_item_id sync บน publish สำเร็จ) |
| `Finnhouses WF2 — Image + Patch (4_fixed).json` | Image gen → Vision QA → WP upload → Patch featured image → Notify Hub | ✅ Active (x-hub-token fixed Jun 29) |
| `wf_qc_line (1).json` | QC LINE 12-node — sig verify → download → upload Storage → Hub ingest → GPT-4o → LINE reply | ✅ Active (v8 binary ✅) |
| `CRM Note Parser — leads → buyer_context_signals.json` | Parse leads.notes → intent/urgency + buyer_context_signals | ✅ Active (22:00 daily) |
| `FB Post Performance Tracker (3).json` | ดึง FB posts → post_performance → Telegram digest | ✅ Active |
| `Finnhouses — Market Intelligence Collector v1 (1).json` | FB/Manual webhook → Claude parse → Supabase → content_frames → Telegram | ⏸ Superseded (session 22, Jul 8) — ดูแถวถัดไป |
| `Finnhouses — Market Intelligence Collector v2 (ADR-005).json` | FB/Manual webhook → Claude parse (9-signal schema) → native Supabase node → content_frames/market_insights/buyer_context_signals → Telegram | ✅ Active (live ตั้งแต่ Jul 8, session 22) — ID `lrLOjW4GPd5atYhz`, `maxTokens:3000` |
| `Finnhouses — Telegram → Market Intel.json` | Telegram trigger → Market Intel webhook | ✅ Active |
| `Finnhouses_LINE_Seller_Intake_v6.json` | LINE seller intake → Hub → Supabase → WP image | ✅ Active |
| `Queue Auto-run (FB + Blog) (2).json` | Schedule → /api/fb/queue/run-next + n8n /webhook/blog-run | ✅ Active |
| `Wake-up (09_02 daily.json` | 09:02 daily ping → WordPress + Hub /health + FB Backend /health | ✅ Active |
| `🔍 System Health Check (1).json` | 08:50 daily → Blog Queue status → Telegram | ✅ Active |
| `FB Market Intelligence — Sheet to Supabase (2).json` | Google Sheet → OpenAI parse → Supabase fb_listings | ⏸ Inactive |

## Hub v2 (TypeScript Clean Architecture)
| Term | ความหมาย |
|------|-----------|
| Hub v2 Shadow | Hub TypeScript build รัน parallel กับ v1 บน Railway — `HUB_MODE=v2` env var, ยังไม่ serve production traffic |
| Hub v1 Production | `server.cjs` — Express, currently serving all production traffic |
| Shadow Mode | v1 + v2 รันพร้อมกัน v2 ยิง smoke tests บน port/service แยก ก่อน cutover |
| TASK-601/602/603 | Hub v2 Cutover tasks — ทำหลัง 3-day monitoring ผ่าน |
| nixpacks.toml | Railway build config — `[phases.setup] nixPkgs = ["nodejs_22"]` บังคับ Node 22 |
| IAiProvider | TypeScript interface (port) — ทุก AI call ต้องผ่าน port นี้ ห้าม import sdk โดยตรง |
| IStateRepository | TypeScript interface — Hub v2 state access |
| Clean Architecture | Presentation → Application → Domain → Infrastructure (dependency rule: outer depends on inner เท่านั้น) |
| ADR | Architecture Decision Record — เก็บที่ `docs/ADR/` — บังคับเมื่อเปลี่ยน Architecture/Provider/DB/Auth/API |

## AI Team Governance
| Term | ความหมาย |
|------|-----------|
| AI_TEAM.md | Engineering Constitution ของ AP-Home Platform OS — v1.1.0 — อ่านก่อนทำงานทุกครั้ง |
| Architecture Governor | ChatGPT ในบทบาท Virtual CTO — review architecture + เขียน ADR |
| Lead Software Engineer | Claude — implement, refactor, test, deploy |
| Product Owner | Archi — final say ทุก business decision |
| Knowledge OS | ระบบความรู้ถาวร = memory/ + docs/ + session summaries + os_map.html — first-class component |
| Engineering North Star | "ทุก engineering decision ต้องทำให้ AP-Home ฉลาดขึ้น, maintain ง่ายขึ้น, หรือมีคุณค่ากับลูกค้ามากขึ้น" |
| ADR Template | `docs/ADR/0000-template.md` — Context/Decision/Alternatives/Consequences/References |
| HUB_URL cutover rule | ห้ามเปลี่ยน `HUB_URL` (Vercel env var) ไปชี้ Hub v2 จนกว่าจะยิง request จริงทดสอบทุก route ที่ n8n/Dashboard เรียกใช้แล้วผ่านหมด — env var ตัวเดียวกระทบทุก proxy route พร้อมกัน (บทเรียนจาก session 18 incident) |

## n8n Patterns
| Pattern | ความหมาย |
|---------|-----------|
| `this.helpers.httpRequest()` | n8n Code node HTTP method — แทน fetch (ซึ่งไม่มีใน sandbox) — body เป็น JS object, json:true auto-serialize |
| Native Telegram node | `n8n-nodes-base.telegram` + credential `gmqmxxSq3X1Y6Ykr` — ใช้แทน Code node HTTP call เสมอ |
| Build+Send pattern | แยก message building (Code node) กับ sending (Native node) ออกจากกัน |
| `alwaysOutputData: true` | ต้องอยู่ top-level ของ node object (ไม่ใช่ใน parameters.options) เพื่อให้ empty response ยัง output 1 item |
