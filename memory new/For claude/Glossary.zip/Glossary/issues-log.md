# Issues & Fixes Log — Finnhouses Platform
*อัพเดททุกครั้งที่พบปัญหาและแก้ไข*

---

## 2026-07-13 (session 24) — ISSUE-012: Blog Runner ค้างที่ "running" 11+ ชั่วโมง — Publish Guard บล็อกเงียบ ไม่ callback กลับ Hub (runId blog_0134d26d)

### ✅ แก้แล้ว — root cause คือ slug fallback สั้นเกินไป + ไม่มี node แจ้งเตือนเมื่อโดนบล็อก
**อาการ:** user ส่งภาพหน้าจอ Telegram bot `finnhousesAI` — Hub Health Alert ยิงซ้ำทุก 30 นาทีตั้งแต่ 17:08 ถึง 20:38 (Jul 13) บอก "Blog Runner ค้าง 458→698 นาที (runId: blog_0134d26d-81d9-4f86-bef7-82e18669d208)"
**ตรวจสอบขั้น 1 (Supabase `hub_state` query ตรง):** Hub ส่ง request ไป n8n สำเร็จ (`"Queue: dispatched to n8n"`) ตอน 09:00 เช้าวันนี้ แต่ไม่มี event `blog_callback_received` ตามมาเลย (ต่างจากทุกวันก่อนหน้าที่ callback กลับมาภายใน ~1 นาที)
**ตรวจสอบขั้น 2 (user เปิด n8n UI เช็ค execution ตรง):** WF1 execution เวลา 09:00:23 จริงๆ **"Succeeded" ทุก node เขียวหมด** (1m19s, ID#1138) — แต่ execution เดินไปทาง branch **"Blocked Log"** แทนที่จะเป็น "Create a post" → "Notify Hub Published" — Output ของ Blocked Log: `{"status":"blocked","message":"Post blocked by publish guard: missing_or_short_slug","slug":"post",...}`
**Root cause ที่แท้จริง:** node "Edit Fields" มี fallback `article_slug = ... || 'post'` เวลาโมเดลไม่คืนค่า slug มา — แต่ node "Publish Guard + Dedupe History" เช็คว่า slug ต้องยาว ≥6 ตัวอักษรถึงผ่าน คำว่า **"post" มีแค่ 4 ตัว ไม่มีทางผ่านได้เลย** เป็น fallback ที่ขัดแย้งกับกฎของตัวเอง (design bug) — พอโดนบล็อก ไม่มี node ไหนแจ้งเตือนหรือ callback กลับ Hub เลย ปล่อยให้ `content_queue` item + `state.blog` ค้าง "running" ตลอดไป (silent-failure pattern เดียวกับที่เจอกับ `content_frames` session 19e)
**วิธีแก้ (deploy แล้ว):**
1. แก้ `Edit Fields` node: slug fallback chain ใหม่ — ลอง slug จากโมเดล → ถ้าสั้นเกินลอง derive จาก title → ถ้ายังสั้นอีก fallback เป็น `post-<timestamp>` (รับประกันผ่าน guard ≥6 ตัวเสมอ)
2. เพิ่ม node ใหม่ **"Notify Hub Blocked"** ต่อจาก Blocked Log — POST กลับ `hub_callback_url` เดิมด้วย `status:"failed"` + `queue_item_id` → Hub `/webhook/n8n` จะ mark `content_queue` item เป็น "failed" อัตโนมัติ + ส่ง Telegram แจ้งทันที (ใช้ logic เดิมของ Hub ที่มีอยู่แล้ว ไม่ต้องเพิ่ม credential ใหม่)
**ไฟล์:** `memory/n8n-workflows/Finnhouses WF1 — Article + Publish (8_slug_guard_fix).json` — user import แล้ว (deactivate เวอร์ชัน (7) เดิม, ตัวใหม่ active)
**Unblock ของค้าง:** user กด Manual Reset ใน Dashboard → `state.blog.status` → "idle" สำเร็จ — แต่พบว่าปุ่มนี้แก้แค่ `state.blog` ไม่ได้ sync `content_queue` item ให้ตรงกัน (item วันที่ 07-13 ยังโชว์ "running" ค้าง) → Claude แก้ตรงผ่าน Supabase MCP `execute_sql` (update `content_queue[2].status` → "failed" by matching `id`)
**บั๊กที่พบเพิ่ม + แก้ตามคำขอ user ในเซสชันเดียวกัน:** node "Notify Hub Published" (กรณี publish สำเร็จ) **ก็ไม่ได้ส่ง `queue_item_id` เหมือนกัน** — สังเกตจาก `content_queue` items วันที่ 07-11, 07-12 ที่ publish สำเร็จจริงแล้ว (มี `blog_callback_received` status "published" ใน history) แต่ item ใน queue ยังค้าง `status:"running"` ไม่เคยขยับเป็น "published" เลย — ไม่กระทบ Queue Auto-run เพราะมันมองหาแค่ item ที่ `status==="pending"` เท่านั้น แต่ Dashboard โชว์ผิดความจริง
**✅ แก้แล้ว:** เพิ่ม `queue_item_id` เข้า body ของ "Notify Hub Published" ด้วย (แพทเทิร์นเดียวกับ "Notify Hub Blocked") → ไฟล์ `Finnhouses WF1 — Article + Publish (9_queue_sync_fix).json` — user import แล้ว
**Backfill ข้อมูลเก่า:** แก้ `content_queue` items 07-11 (`bctm5e4lqylmretlflh`) และ 07-12 (`e4x55v1w1amretlflh`) จาก `status:"running"` → `"published"` ตรงผ่าน Supabase MCP `execute_sql` ให้ตรงกับความจริงที่มีอยู่ใน history อยู่แล้ว
**หมายเหตุ:** พบ key `v2` แยกใน `hub_state` table ด้วย — `blog.status:"running"`, `runId:"run_da089n87"`, `startedAt: 2026-06-30` — ค้างมาตั้งแต่ Jun 30 (Hub v2 shadow ไม่ live จึงไม่กระทบ production แต่เป็น stale state ที่ไม่มีใครเคลียร์ ยังไม่แก้)
**บทเรียนสำคัญ:** ห้ามตั้ง fallback value ที่ตัวเองสอบตกกฎ validation ที่ตามมาทันที (เหมือนตั้ง default อายุ = -1 แล้วเช็ค age > 0) — ทุก branch ที่จบ workflow แบบ "ไม่ publish" (blocked/error/skip) ต้อง callback กลับ Hub เสมอเพื่อ unstick state — ห้ามให้ workflow จบเงียบๆ โดยไม่แจ้งอะไรกลับไปที่ไหนเลย

---

## 2026-07-08 (session 22) — ISSUE-010: Market Intel v2 — Claude Haiku response ตัดกลาง JSON บนโพสต์จริงที่ยาว/ละเอียด

**สรุปสั้น** (รายละเอียดเต็ม → `CORE/ap-home-platform/docs/issues-log.md` ISSUE-010): หลัง cutover Market Intel Collector v2 (ADR-005) โพสต์จริง (#ขายบ้าน พฤกษา 8 — รายละเอียดของแถม/ขนาด/โปรโมชันเยอะ) ทำให้ Claude Haiku ตอบเกิน `maxTokens:1600` → JSON ถูกตัดกลางคำ (ยืนยันจาก `raw_model_text_debug` field) → parse fail → fail-safe ทำงานถูกต้อง (ไม่มีข้อมูลผิดถูกบันทึก) แต่โพสต์นั้นหาย
**แก้:** เพิ่ม `maxTokens` 1600 → 3000 ในทั้ง 2 Parse node (FB + Manual) — verify ผ่านโพสต์จริง 3 รายการติดต่อกัน (2 รันใช้เวลา 25.9s/30.5s ยืนยันว่าเป็น generation ยาวจริง ไม่ใช่บังเอิญผ่าน)
**บทเรียน:** token limit จาก mocked test ไม่การันตีว่าพอสำหรับ organic traffic จริง — ต้องเผื่อ headroom กว้างกว่าที่ dry run บ่งชี้ (2x ไม่ใช่ 1.1x)

---

## 2026-07-02 (session 19e) — Market Intel: `content_frames` ไม่เคยบันทึกสำเร็จเลยตั้งแต่ live

### 🔴→✅ Positioned Content ดูเหมือนทำงาน (Telegram แจ้งเตือนทุกครั้ง) แต่ `content_frames` มี 0 แถวมาตลอด
**อาการ:** user ขอให้เช็คว่า Positioned Content ทำงานได้จริงไหม — query Supabase ตรงพบ `content_frames` count = 0 ทั้งที่ `market_insights` (27 แถว) และ `buyer_context_signals` (11 แถว) มีข้อมูลปกติ
**Root cause:** node "💾 Supabase: content_frames" ส่ง JSON keys `area`, `timing_signal`, `source_type` ที่ไม่ตรงกับคอลัมน์จริงของตาราง (`frame_text, frame_type, target_segment, target_context, keyword, tone, channel, ...`) — PostgREST reject insert ที่มี unknown column ด้วย 400 เสมอ แต่ code จับด้วย try/catch ที่แค่ `console.log` ไม่ throw ต่อ ไม่แจ้งเตือนที่ไหนเลย และ node คืน `saved: true` โดยไม่เช็คผลจริง
**ทำไมไม่มีใครสังเกต:** Telegram notification ที่ user เห็นทุกครั้งดึงข้อความมาจาก node "✨ Claude: Generate Content" (ขั้นตอนก่อนหน้า save) โดยตรง ไม่ได้เช็คว่า save สำเร็จไหม — เลยดูเหมือนระบบทำงานสมบูรณ์มาตลอด 1 เดือน+
**วิธีแก้:** แก้ node ให้ map field ให้ตรงคอลัมน์จริง (พับ area/timing_signal/source_type รวมเป็น string เดียวใน `target_context`) + เพิ่ม success/error status ต่อท้าย Telegram message กันไม่ให้เกิดซ้ำแบบเงียบๆ
**บทเรียนสำคัญ:** try/catch ที่มีแค่ `console.log(e.message)` โดยไม่ throw หรือแจ้งเตือนต่อ = silent failure ที่มองไม่เห็นเลยจนกว่าจะมาเช็ค DB ตรงๆ — ควร surface error กลับไปที่ user-facing notification เสมอ (Telegram/LINE) ไม่ใช่แค่ log ที่ไม่มีใครดู
**ผลกระทบที่กู้คืนไม่ได้:** Positioned Content ทั้งหมดที่สร้างมาก่อน session นี้ (ตั้งแต่ 29 พ.ค.) ไม่ได้เก็บอยู่ใน DB เลย มีแค่ในข้อความ Telegram เก่า
**Backfill ที่ทำแทน:** เขียน FB post ใหม่ 26 โพสต์จาก `market_insights` เดิม (ข้าม 1 แถวที่ confidence=1 "ข้อมูลไม่เพียงพอ") insert ย้อนหลังพร้อม `created_at` ตรงกับวันที่ insight เดิม — เป็นคอนเทนต์ที่เขียนใหม่ให้ตรง insight ไม่ใช่ข้อความต้นฉบับที่เคยส่งจริง (ดู decisions.md "Backfill content_frames")

---

## 2026-07-02 (session 19d) — QC Feedback Loop: n8n Code Sandbox Missing `URLSearchParams`

### 🔴→✅ Code node "Parse Feedback Postback" พัง `ReferenceError: URLSearchParams is not defined`
**อาการ:** เพิ่งเพิ่ม branch ใหม่ใน `wf_qc_line (2)` สำหรับรับปุ่ม feedback ("✅ ตรง / ❌ ไม่ตรง") — พอทดสอบกดปุ่มจริงใน LINE, execution error ใน 45ms ที่ node "Parse Feedback Postback" บรรทัด 6
**Root cause:** n8n รัน Code node ผ่าน task-runner แบบ sandboxed VM (`@n8n/task-runner`) ที่ไม่ expose Node.js/Browser global ทุกตัว — `URLSearchParams` ไม่มีอยู่ใน context นี้ ทั้งที่ปกติเป็น global ของทั้ง browser และ Node.js
**วิธีแก้:** parse query string เอง (`data.split('&').forEach(pair => { const [k,v] = pair.split('='); ... })`) แทนการใช้ `new URLSearchParams(data)`
**ป้องกัน:** Code node อื่นๆ ในโปรเจกต์นี้ทั้งหมดใช้ `require('https')` (Node built-in module) ไม่เคยมีปัญหา — บทเรียนคือ Node **built-in modules** (`https`, `crypto`) ใช้ได้ปกติใน n8n sandbox แต่ **web/global APIs** (`URLSearchParams`, `fetch` แบบ global, `Buffer` ต้องเช็คก่อน) ไม่ชัวร์ว่ามี ต้อง test จริงก่อนเชื่อ หรือเขียน parse เองด้วย string method พื้นฐานจะปลอดภัยกว่าเสมอ
**บริบทงาน:** เป็นส่วนหนึ่งของการเพิ่ม "feedback loop" ให้ QC Line — เก็บว่า inspector ยืนยันว่า AI ตรวจถูกหรือผิด ผ่านปุ่ม LINE Quick Reply → บันทึกลง `qc_inspections.human_feedback` (ดู decisions.md "เริ่มต้น self-improving loop ที่ QC Line ก่อน")

---

## 2026-07-02 (session 19b) — QC Standards: DB Constraint + PowerShell BOM + End-to-End PASS

### 🔴→✅ `qc_standards` table ล็อกไว้แค่ 1 รูปอ้างอิง/หมวด ทั้งที่โค้ดรองรับหลายรูป
**อาการ:** พยายาม insert รูปอ้างอิงเพิ่ม (concrete ref2/ref3 ฯลฯ) แล้วเจอ `ERROR: 23505: duplicate key value violates unique constraint "qc_standards_category_key"`
**Root cause:** ตารางมี `UNIQUE(category)` ตั้งแต่สร้าง — จำกัดไว้ 1 แถว/หมวด โดยไม่ได้ตั้งใจ (โค้ด `qcCallOpenAI()` loop ผ่านหลายรูปได้อยู่แล้ว)
**วิธีแก้:** `apply_migration` ผ่าน Supabase MCP — drop `qc_standards_category_key`, เพิ่ม `UNIQUE(category, photo_url)` แทน
**ผล:** ขยายจาก 4 หมวด (1 รูป/หมวด) เป็น 7 หมวด (14 รูปรวม) — เพิ่มหมวดใหม่ electrical/plumbing/finishing ที่ไม่เคยมีรูปอ้างอิงเลย
**แหล่งรูป:** `D:\Finnhouses brand\` (โฟลเดอร์งานจริง Finnhouses) — เจอเอกสาร QC checklist จริงของบริษัทเป็นของแถม (`02 QC List Revise02 2018.xlsx`, `inspect โครงสร้าง.pdf`) มีเกณฑ์ตัวเลขจริง (concrete ≥200 ksc, คาน L/360, ท่อน้ำ 100 psi) ที่ยังไม่ได้เอาไปใส่ใน QC_SYSTEM_PROMPT (งานค้างสำหรับ session ถัดไป)
**ยังไม่มีรูปอ้างอิง:** structure (มีแต่ PDF checklist ข้อความ), cleanliness (ไม่มีแหล่งข้อมูลเลย)

### 🔴→✅ PowerShell script ที่มี path ภาษาไทย parse error ทั้งไฟล์
**อาการ:** รันสคริปต์ `upload-qc-standards-v2.ps1` (สร้างด้วย Write tool) แล้วเจอ `Unexpected token 'à¸‡à¸²à¸™...'` — ตัวอักษรไทยกลายเป็น mojibake
**Root cause:** ไฟล์ที่ Write tool สร้างเป็น UTF-8 **ไม่มี BOM** — `powershell.exe` (Windows PowerShell 5.1) อ่านไฟล์ไม่มี BOM ด้วย system codepage แทน UTF-8 → อักขระไทยเพี้ยน → syntax parse พังตามมา (quote/brace ปิดผิดที่)
**วิธีแก้:** ใช้ bash เขียน byte `\xEF\xBB\xBF` (UTF-8 BOM) นำหน้าไฟล์ `.ps1` ก่อนส่งให้ user รัน
**ป้องกัน:** ทุกครั้งที่สร้าง `.ps1` ที่มี string literal ภาษาไทย (path, ข้อความ) → เติม BOM เสมอ ห้ามพึ่งแค่ UTF-8 เฉยๆ — ดู decisions.md
**บั๊กเล็กระหว่างทาง:** เผลอตั้ง `paint/ref2.jpg` ให้ชี้ path เดียวกับ `paint/ref1.jpg` (copy-paste ผิด) — verify เจอผ่าน `storage.objects` query (ขนาดไฟล์เท่ากันเป๊ะ = สัญญาณว่าเป็นไฟล์เดียวกัน) แก้ด้วยสคริปต์แยก `fix-paint-ref2.ps1`
**บทเรียน:** verify ผลอัปโหลดเสมอด้วย SQL query โดยตรง (`select name, metadata->>'size' from storage.objects`) แทนการเชื่อคำว่า "OK" จาก PowerShell output อย่างเดียว — เจอบั๊กที่ script บอกว่าสำเร็จ (ไม่ error) แต่เนื้อหาไฟล์ผิด

### ✅ QC LINE end-to-end test — PASS ครั้งแรกตั้งแต่สร้างระบบ
**บริบท:** เป็น pending item ที่เก่าที่สุดในลิสต์ (ค้างมาหลาย session) — user ทดสอบเองโดยส่งรูปจริง 4 เคสจาก LINE OA ผ่าน Telegram bot `finnhousesAI`
**ผล:** reply ภาษาไทยครบทุกเคส ภายในนาทีเดียวกับที่ส่ง (เข้าเกณฑ์ ≤15s), severity แยกถูก, suggested_action ทำได้จริง, confidence score แสดงผล (95%)
**หลักฐานว่ารูปอ้างอิงใหม่ถูกใช้งานจริง:** 2 เคสคอนกรีตก่อนเท AI พูดถึง "cover block" ตรงกับ description ที่เพิ่งเพิ่มเข้าไปในรอบนี้ (เคสหนึ่งมี → ผ่าน, อีกเคสไม่มี → ไม่ผ่าน severity high) — ไม่ใช่คำที่มีอยู่ใน QC_SYSTEM_PROMPT เดิมมาก่อน ต้องมาจากรูป/description อ้างอิงที่เพิ่งอัปโหลดเท่านั้น

---

## 2026-07-02 (session 19) — Dashboard 401: Vercel Env Var Mismatch + CDN Cache

### 🔴→✅ `GET /api/blog/state` คืน `{"error":"Hub returned 401"}` ทั้งที่ token ถูกต้อง
**อาการ:** Dashboard "Blog Content Runner" ค้างที่ empty state ("ยังไม่มี Content Queue") ทั้งที่ Hub v1 มี content_queue 7 รายการจริง — `/api/blog/state` (Next.js proxy) คืน 401 ทุกครั้ง
**Root cause #1:** `HUB_SECRET` ใน Vercel เป็นค่าผิด (placeholder ของ secret อื่นที่ไม่เกี่ยวข้อง เช่น `sk_live_a12...`) — เกิดจาก session ก่อนหน้าตั้งค่าไม่ตรง
**Root cause #2:** `HUB_URL` ก็ผิดเช่นกัน (คาดว่าค้างชี้ Hub v2)
**วิธีแก้ #1+#2:** ลบตัวแปรเก่าทั้งคู่แล้วสร้างใหม่ผ่าน "Add Environment Variable" (ไม่ใช้ปุ่ม Edit ในช่องเดิม — พบว่า edit-in-place ไม่ reliable), scope Production+Preview, redeploy
**Root cause #3 (ตัวหลอกนานสุด):** แก้ env var ถูกแล้ว + redeploy สำเร็จหลายรอบ (deployment state READY, alias ชี้ถูกต้อง) แต่ยังเห็น 401 เดิมซ้ำทุกครั้งไม่เปลี่ยน — เพิ่ม temp debug code (`blog/state/route.ts` commit `764abf4`) ให้ echo ค่า HUB_URL/HUB_SECRET metadata กลับมาตอน error แต่ debug field ก็ไม่โผล่เลย → สรุปว่า response ที่เห็นทั้งหมดเป็น **CDN/edge cache เก่าค้างอยู่** ไม่ใช่ output จริงจาก serverless function — ยืนยันโดยเรียกด้วย `?cachebust=<timestamp>` แล้วเห็นข้อมูลจริงทันที (content_queue 7 รายการ, ไม่มี error)
**วิธีตรวจพบที่ถูกต้อง:** ยิง request ตรงไปที่ Hub v1 ด้วย token เดียวกัน (PowerShell) → ได้ข้อมูลถูกต้องทันที → พิสูจน์ว่า token ใช้ได้จริง ปัญหาอยู่ฝั่ง Vercel เท่านั้น ไม่ใช่ Hub
**ป้องกัน:**
- เวลา env var เพิ่งแก้ + redeploy แล้วยังเห็น error เดิมซ้ำๆ ไม่เปลี่ยนแม้แต่ byte เดียว (เช่น status code เดิมเป๊ะทุกรอบ) ให้สงสัย **response caching** (CDN/edge) เป็นอันดับต้นๆ — ลอง cache-busting query param หรือเช็ค response headers (`age`, `x-vercel-cache`) ก่อนไล่แก้ env var ซ้ำไปเรื่อยๆ
- Vercel env var ที่ "Sensitive" ยังคง reveal ได้โดย owner ผ่านปุ่ม eye icon — ใช้ตรวจสอบค่าจริงได้เวลา debug แทนการเดา
- เวลา debug ยาก ให้เพิ่ม debug field ชั่วคราวใน error response (ไม่ expose secret เต็ม แค่ length/prefix/suffix) แทนการเดาไปเรื่อยๆ — แต่ต้อง revert ทิ้งหลังจบ (ดู pending)
**สถานะ:** ✅ แก้แล้ว + verify ผ่าน `web_fetch` cache-busted เห็น content_queue 7 รายการจริง — 🔴 ค้าง: revert temp debug commit `764abf4` ออกจาก `blog/state/route.ts`

---

## 2026-07-02 (session 19) — FB Queue Empty — Second Silent-Skip Risk

### 🔴→✅ Dashboard audit พบ `fb_queue` ว่างเปล่าเหมือนกับที่ `content_queue` เคยเป็น
**อาการ:** user ถามว่า Dashboard ส่วนไหนยังไม่สมบูรณ์ — audit ทุกหน้า/API เจอว่า `fb_queue` (คนละตัวกับ `content_queue` ของ blog) ว่าง 0 รายการ — n8n "Queue Auto-run" ยิง `/api/fb/queue/run-next` ทุกวันเหมือนกัน จะ skip เงียบๆ แบบเดียวกับบั๊ก blog queue เดิม เพียงแต่ยังไม่มีใครสังเกตเพราะไม่มี error โชว์
**พบว่า:** มี UI สำหรับ FB Queue อยู่แล้วในแท็บ **"AI Content" → FB Content Studio → Content Queue** (คนละหน้ากับ Marketing/Blog Runner) — ปุ่ม "✨ สร้าง Queue 7 วัน" เติม draft อัตโนมัติจาก `FB_QUEUE_TEMPLATES` (7 ข้อความสำเร็จรูปพอดี 7 วัน) ใน `components/AIContent.tsx`
**วิธีแก้:** ให้ user กดปุ่มในแท็บ AI Content เอง (ไม่ต้องใช้ PowerShell/Claude เขียน queue ตรง) → verify ผ่าน `GET /api/blog/state` เห็น `fb_queue` มีครบ 7 รายการ (Jul 3–9) ตรงกับ content_queue
**ป้องกันระยะยาว:** อัพเดท n8n workflow "Content Queue Weekly Builder" เป็น v2 (`Content Queue Weekly Builder (2).json`) เพิ่ม branch คู่ขนานเช็ค+เติม `fb_queue` พร้อมกับ `content_queue` ทุกสัปดาห์ — **ยังไม่ swap เข้า n8n จริง** (v1 import ไปแล้วแต่ยังไม่ได้แก้เป็น v2) ต้องลบ v1 แล้ว import v2 แทน

---

## 2026-07-02 (session 19) — Weekly Queue Automation (n8n workflow)

### 🟡 Content Queue มีแค่ 7 วัน — ต้องเติมใหม่ทุกสัปดาห์ไม่งั้น Auto-run เงียบอีก
**ปัญหา:** หลังแก้ Dashboard 401 แล้ว user ถามว่าสัปดาห์ถัดไป (หลัง Jul 9) ต้องทำอย่างไร เพราะ content_queue มีแค่ 7 รายการ ถ้าไม่เติมจะย้อนกลับไปเจอบั๊กเดิม (silent-skip 200)
**ทางเลือกที่พิจารณา:**
1. Claude scheduled task ใช้ browser automation (Claude in Chrome) กดปุ่ม "สร้าง Queue ใหม่" ให้ — ทำได้ แต่ต้องพึ่งแอป Cowork + browser extension เปิดอยู่ตอนนั้นพอดี ไม่ใช่ backend จริง
2. **n8n workflow ใหม่ (เลือกใช้)** — n8n รันอยู่บน Railway 24/7 อยู่แล้ว ไม่ต้องพึ่งอะไรจาก Claude/browser เลย
**สิ่งที่สร้าง:** `memory/n8n-workflows/Content Queue Weekly Builder (1).json`
- Schedule Trigger: ทุกวันพฤหัสฯ 20:00 (Asia/Bangkok) — เวลานี้เลือกเพราะปกติ item สุดท้าย (วันที่ 7) ของ queue ควรรันไปแล้วตอนเช้าวันเดียวกัน
- HTTP Request GET `/api/blog/state` (ผ่าน Vercel proxy, ไม่ต้องใช้ credential ใดๆ เพราะ proxy แนบ x-hub-token ให้เองฝั่ง server — เหมือน "Queue Auto-run" workflow เดิม)
- IF node เช็ค `content_queue.length === 0` ก่อนเสมอ — ถ้ายังมีรายการเหลือ (เช่น รันสัปดาห์แรกที่เพิ่งสร้าง queue ใหม่ๆ) จะ **ข้ามไม่สร้างทับ** ป้องกันการเขียนทับ queue ที่ยังไม่ได้ใช้
- Code node สุ่ม 1 keyword/category จาก pool 7 หมวด (คัดลอกมาจาก `KEYWORD_POOLS` ใน `components/Marketing.tsx` ให้ตรงกันเป๊ะ) + สุ่ม visual_hint + วันที่ต่อเนื่อง 7 วันเริ่มพรุ่งนี้
- HTTP Request POST `/api/blog/queue/build` (ผ่าน Vercel proxy เช่นกัน)
**ยังไม่ทำ:** ต้อง import ไฟล์นี้เข้า n8n เอง (Claude เข้า Railway/n8n ตรงไม่ได้จาก sandbox) แล้วเปิด Active — ยังไม่ verify ว่ารันจริงได้
**ข้อจำกัดที่รู้ตัว:** สุ่มจาก pool คงที่ 8 คำ/หมวด ไม่มีระบบกันคำซ้ำข้ามสัปดาห์ (เหมือนพฤติกรรมเดิมของปุ่ม "สร้าง Queue ใหม่" บน Dashboard) — ถ้าอยากกันซ้ำต้องเพิ่ม logic เช็ค history ใน Hub state
**Claude scheduled task สำรอง:** `ap-home-weekly-content-queue` ถูกปิดใช้งาน (enabled:false) ไว้เป็น fallback กรณี n8n ล่ม — ไม่ได้ลบทิ้ง

---

## 2026-07-02 (session 19) — Empty Queue Silent-Success + PowerShell Thai Encoding

### 🔴→✅ content_queue ว่างเปล่า — Queue Auto-run ขึ้นเขียวทุกวันทั้งที่ไม่ได้ทำอะไร
**อาการ:** n8n "Queue Auto-run" สำเร็จทุกเช้า (200 OK, ~2-3s) แต่ WF1 ไม่มี execution ใหม่เลยตั้งแต่ Jun 30 20:49 — บทความไม่ถูกสร้างต่อเนื่อง 3 วัน
**Root cause:** `server.cjs:1352` `/action/blog/queue/run-next` — เมื่อ `content_queue` ว่าง จะ `return res.json({ok:true, skipped:true, message:"Queue is empty"})` คือ HTTP 200 เสมอไม่ว่าจะมีงานจริงหรือไม่ n8n เห็นแค่ status code เลยขึ้น Succeeded แม้ skip เงียบๆ
**วิธีตรวจพบ:** `GET /api/state` (path ถูกต้องคือ `/api/state` ไม่ใช่ `/api/health/state` ตามที่ CLAUDE.md เขียนผิดมาตลอด — แก้เอกสารแล้ว) → เห็น `content_queue: {}` ชัดเจน
**วิธีแก้:** เติม queue ผ่าน `/action/blog/queue/build` ด้วย 7 items (สุ่ม 1 keyword/category ครบ 7 หมวด, Jul 3–9)
**ป้องกัน:** ห้ามเชื่อว่า "n8n ขึ้นเขียว = งานเสร็จ" สำหรับ endpoint ที่มี skip-logic แบบ silent-200 — ต้องเช็ค `content_queue.length` หรือ `blog.status`/`blog.finishedAt` คู่กันเสมอเวลา debug ว่าทำไม pipeline หยุดทำงาน
**สถานะ:** ✅ เติม queue แล้ว — 🔴 รอ verify ว่า Queue Auto-run วันที่ 3 ก.ค. 09:00 หยิบ item จริงและ WF1 execution ใหม่ปรากฏ

### 🔴→✅ PowerShell `Invoke-RestMethod -Body <string ภาษาไทย>` เพี้ยนเป็น `?????`
**อาการ:** ส่ง JSON body ที่มีคำภาษาไทยผ่าน `Invoke-RestMethod -Body $jsonString` → Hub เก็บค่าจริงเป็น `?????????` แทนข้อความไทย (verify ด้วย `GET /api/state` เห็นข้อมูลเพี้ยนจริงบน server ไม่ใช่แค่ console แสดงผลผิด)
**Root cause:** เมื่อ `-Body` เป็น string ธรรมดา PowerShell/.NET เลือก encoding เริ่มต้นที่ไม่ใช่ UTF-8 สำหรับ request body (fallback ไปเป็น encoding ที่ representable แค่ ASCII) → อักขระไทยทุกตัว map ไม่ได้ → กลายเป็น `?` (0x3F) ตั้งแต่ก่อนออกจาก client
**วิธีแก้:** แปลง JSON string เป็น byte array ด้วย `[System.Text.Encoding]::UTF8.GetBytes($jsonString)` แล้วส่ง byte array เป็น `-Body` แทน string + เพิ่ม `-ContentType "application/json; charset=utf-8"` อย่างชัดเจน
**ป้องกัน:** ทุกครั้งที่ `Invoke-RestMethod`/`Invoke-WebRequest` ส่ง body ที่มีภาษาไทย (หรือ non-ASCII ใดๆ) ต้อง `GetBytes()` เสมอ ห้ามส่ง string ตรงๆ แม้จะผ่าน `ConvertTo-Json` มาแล้วก็ตาม
**สถานะ:** ✅ แก้แล้ว — verify ผ่าน `GET /api/state` เห็นข้อความไทยถูกต้องครบ 7 รายการ

---

## 2026-07-01 (session 18) — FB Queue 404 + gitignore Bug

### 🔴→✅ Queue Auto-run "HTTP Request" (FB queue) — 404 Route not found
**อาการ:** n8n "Queue Auto-run (FB + Blog)" execution ที่ 09:00 ทุกวัน — node "HTTP Request" (FB queue) error `404 {"ok":false,"error":{"code":"NOT_FOUND","message":"Route not found"}}` หลังจากเคย success ทุกวันมาตลอด (Jun 24–30)
**Timeline จริง (สืบจาก git log + Vercel deployment history):**
- Jun 30, 19:46 — Archi แก้ `blog/queue/run-next/route.ts` เอง (commit `dd691fd`) เปลี่ยนจาก `/action/blog/queue/*` + `x-hub-token` → `/api/blog/queue/*` + `x-hub-secret` (Hub v2 convention) แต่ไม่ได้แก้ `fb/queue/*` ให้ตรงกัน
- Jun 30, ~20:xx — `HUB_URL` (Vercel env var) ถูกเปลี่ยนไปชี้ Hub v2 (`exciting-creativity-production-4b85...`) — cutover ทั้งระบบทั้งที่ Hub v2 ยังสร้าง route พวกนี้ไม่เสร็จ
- Jul 1, 09:00 — Queue Auto-run รันแล้ว fb queue 404 ทันที (path เก่าไม่มีบน v2), blog queue ไม่เคยถูกทดสอบเลยเพราะ workflow หยุดที่ node แรก
**Root cause ที่แท้จริง (ยืนยันด้วย Vercel runtime logs):** Hub v2 **ไม่มี route ทั้ง `/api/fb/queue/*` และ `/api/blog/queue/*` implement จริง** — การแก้ path/header ให้ตรง Hub v2 convention (ลองแล้วใน commit `e0692a3`, `1012ec3`) deploy สำเร็จแต่ยัง 404 เหมือนเดิม เพราะ route ปลายทางไม่มีอยู่จริงบน Hub v2 (ไม่ใช่แค่ path ผิด)
**วิธีแก้สุดท้าย:** revert ทั้ง 6 route (`fb/queue/{run-next,build,clear}` + `blog/queue/{run-next,build,clear}`) กลับไปใช้ Hub v1 convention (`/action/.../` + `x-hub-token`) และเปลี่ยน `HUB_URL` ใน Vercel กลับเป็น Hub v1 (`ap-home-platform-production...`) — verify แล้วทั้ง 2 node เขียวบน n8n (execution #720, 1.6s)
**Commits:** `e0692a3`, `1012ec3` (พยายามแก้เป็น v2 convention — ไม่พอ), `56dab04` (revert กลับ v1 — แก้จริง)
**ป้องกัน:**
- ห้ามเปลี่ยน `HUB_URL` (env var ที่กระทบทุก route) ไปชี้ Hub v2 จนกว่าจะเช็คแล้วว่า **ทุก route ที่ n8n/Dashboard เรียกใช้งานได้จริงบน v2** (ไม่ใช่แค่บาง route)
- เมื่อแก้โค้ด route ให้ตรง convention ใหม่ ต้อง**ทดสอบว่า backend endpoint มีอยู่จริงก่อน** (ยิง request จริงหรือเช็ค Hub v2 source code) — อย่าเชื่อว่า "path ถูกแล้วต้องผ่าน" เพราะ 404 อาจมาจาก route ไม่มีอยู่จริง ไม่ใช่แค่ path พิมพ์ผิด
- Migrate route ไป Hub v2 ต้องทำทั้งกลุ่ม endpoint พร้อมกัน (ดู decisions.md)

### 🔴→✅ `app/api/fb/queue/build/route.ts` ไม่เคยถูก commit เข้า git เลย — `.gitignore` bug
**อาการ:** `git add app/api/fb/queue/` commit ผ่าน แต่ `git status` ไม่เห็น `build/route.ts` เปลี่ยนแปลงเลย ทั้งที่แก้ไฟล์แล้วจริง — `git add` ตรงๆ ขึ้น warning "The following paths are ignored by one of your .gitignore files: app/api/fb/queue/build"
**Root cause:** `.gitignore` line 16 มี `build/` (ไม่มี `/` นำหน้า) — Git ตีความเป็น "ignore โฟลเดอร์ชื่อ build ทุกที่ในโปรเจกต์" ทั้งที่ตั้งใจ ignore แค่ Next.js build output ที่ root — เลยบัง `app/api/fb/queue/build/route.ts` มาตั้งแต่สร้างไฟล์ (ไฟล์นี้ไม่เคยขึ้น GitHub เลยจนถึงวันนี้)
**วิธีแก้:** เปลี่ยน `.gitignore` เป็น `/build/` (anchor root เท่านั้น) แล้ว `git add -f` ไฟล์ที่ตกหล่นครั้งแรก
**Commit:** `1012ec3` — `create mode 100644 app/api/fb/queue/build/route.ts` (ยืนยันว่าเพิ่งขึ้น git ครั้งแรก)
**ป้องกัน:** เวลาตั้งชื่อ route/folder ใน `app/api/` ห้ามใช้ชื่อที่ตรงกับ pattern ทั่วไปใน `.gitignore` (เช่น `build`, `dist`, `out`) — หรือถ้าจำเป็นต้อง anchor `.gitignore` pattern ด้วย `/` เสมอเมื่อหมายถึง root-only
**สถานะ:** ✅ แก้แล้ว — ยืนยันผ่าน n8n execution #720 (1.6s, ทั้ง 2 nodes เขียว)

### 🔴→✅ `docs/ADR/0000-template.md` + `docs/hub-v2/*` (6 ไฟล์) ไม่เคยขึ้น GitHub เลย
**อาการ:** ผู้ใช้ถาม "ไฟล์ใดในGithubที่ไม่อัพเดท" → audit ด้วย `git status -uall` พบ 7 ไฟล์ untracked (ไม่ใช่ gitignored — แค่ไม่เคย `git add`)
**ผลกระทบ:** `AI_TEAM.md` (ที่อยู่บน GitHub แล้ว) reference ไฟล์เหล่านี้ตรงๆ (ADR template, Hub v2 implementation tasks tracker) — ใครก็ตาม clone repo ใหม่จะหาไฟล์เหล่านี้ไม่เจอ
**วิธีแก้:** `git add docs/ADR/0000-template.md docs/hub-v2/` → commit → push
**Commit:** `e3b7007` — "docs: add missing ADR template and Hub v2 planning docs (referenced by AI_TEAM.md but never pushed)"
**หมายเหตุระหว่างแก้:** เจอ `.git/index.lock` ค้าง (Known Bug #3 ใน CLAUDE.md) → `Remove-Item ".git\index.lock" -Force` แก้ได้ปกติ
**ป้องกัน:** ก่อนเขียน doc ใหม่ที่จะถูก reference จากไฟล์อื่น (เช่น AI_TEAM.md) ให้ commit+push ทันทีในรอบเดียวกัน อย่าปล่อยให้ค้างเป็น local-only

### 🔴→✅ `app/api/blog/state/route.ts` ตกหล่นจาก Hub v1 revert — ยังส่ง `x-hub-secret` ทั้งที่ HUB_URL ชี้ v1 แล้ว
**อาการ:** พบระหว่าง full-repo audit (`grep x-hub-token|x-hub-secret` ทั้ง `app/api/`) — ทุก route ใช้ `x-hub-token` ตรงกัน ยกเว้นไฟล์นี้ไฟล์เดียวที่ยังใช้ `x-hub-secret`
**Root cause:** ไฟล์นี้ถูกแก้ไปพร้อมกับ `blog/queue/*` ในคอมมิตเดียวกัน (`a0aa978`, Jun 30 — "feat: queue feeds keywords to n8n WF1 via Hub v2") แต่ตอน revert กลับ Hub v1 (commit `56dab04`) มีแค่ 6 ไฟล์ queue routes ถูก revert — ไฟล์นี้ไม่ได้อยู่ในรายการเลยหลุดไป
**ผลกระทบ:** Dashboard "blog status" การ์ดน่าจะ fail เงียบๆ มาตั้งแต่ revert — โค้ด catch error แล้ว fallback เป็น `{blog:{status:"idle"}, error:...}` ซึ่งดูเหมือนค่าปกติ ไม่มี alarm ให้เห็น
**วิธีแก้:** เปลี่ยน header กลับเป็น `x-hub-token` ให้ตรงกับ route อื่นทั้งหมด
**Commit:** `56ab7f5` — "fix: blog/state route was missed in Hub v1 revert, still sending x-hub-secret"
**ป้องกัน:** เวลา revert/migrate migration ที่กระทบหลายไฟล์ ต้อง grep หา commit ต้นทางทั้งหมดก่อน (`git show --stat <commit>`) ไม่ใช่ revert แค่ไฟล์ที่คิดว่าเกี่ยวข้อง — audit แบบ grep ทั้ง repo หลังแก้เสร็จทุกครั้งเพื่อยืนยันความสม่ำเสมอ
**สถานะ:** ✅ แก้แล้ว + audit ยืนยันว่าไม่มีไฟล์อื่นหลุดอีก — **ยังไม่ verify runtime** (ต้องเปิด Dashboard เช็คว่า blog status card ไม่ค้างที่ "idle" หลัง redeploy)

---

## 2026-06-29 (session 16) — WF1 Callback + Webhook v2.1 Discovery

### 🔴 WF1 Notify Hub Published — ไม่ callback กลับ Hub เลย (ซ่อนอยู่มานาน)
**อาการ:** Hub state ค้างที่ "running" ตลอดแม้บทความ publish ขึ้น WordPress แล้ว — Queue auto-run หยุดทำงานเพราะไม่มี "pending" items (ทุกชิ้นค้างเป็น "running")
**Root cause ชั้น 1 (Surface):** `Notify Hub Published` ใน WF1 ไม่มี HMAC token ในการ call กลับ Hub → 401 ทุกครั้ง ทำให้ Hub ไม่รู้ว่า blog published
**Root cause ชั้น 2 (Deeper):** n8n Webhook node typeVersion 2.1 wrap POST body ไว้ใน `.body` key — ทำให้ `$input.first().json.hub_callback_url` และ `$input.first().json.runId` เป็น `undefined` เสมอ ทั้งที่ Hub ส่งมาครบ
**ผลกระทบที่ซ่อน:** keyword และ category ที่ Dashboard เลือกไม่ถูกใช้จริง — Blog ใช้ fallback ตลอด (category=13, keyword='' แล้ว Topic Engine gen ใหม่)
**Fix (v8):** `Build Schedule Context` ใช้ `const wb = $input.first().json.body || $input.first().json` แล้วอ่านทุก field ผ่าน `wb` — รองรับทั้ง Webhook v1 และ v2.1
**Journey debug:**
- v5: `$json.hub_callback_url` → `undefined` (pointed to WP response)
- v6: `$node['Build Schedule Context'].json.hub_callback_url` → `''` (Build Schedule Context ไม่ pass ผ่าน)
- v7: double fallback + debug dump → URL ผ่านแต่ `runId=''` → 401 "Invalid webhook token"
- v8: `wb` pattern ครอบทุก field → ✅ รอ verify
**ไฟล์:** `memory/n8n-workflows/Finnhouses WF1 — Article + Publish (8_wb_fix).json`
**ป้องกัน:** n8n Webhook v2.1 ต้องใช้ `wb pattern` — ห้ามอ่าน `$input.first().json.fieldName` โดยตรงสำหรับ POST body fields → ดู Glossary "wb pattern"
**สถานะ:** 🔴 Fix พร้อม (v8) — รอ user import + test

---

## 2026-06-28 (session 13) — QC Calibration + WF1

### ✅ QC false positive — คอนกรีตโครงสร้างถูก flag เป็น defect
**อาการ:** LINE OA QC reply ระบุ "ผิวขรุขระ" เป็น defect สำหรับรูปฐานราก/เสา — ทั้งที่เป็นลักษณะปกติของงานโครงสร้าง
**Root cause:** `QC_SYSTEM_PROMPT` ใน server.cjs บอกแค่ "concrete = ตรวจความเรียบผิว" โดยไม่แยกว่าเป็นงานโครงสร้าง vs งานพื้น vs pre-pour → AI ใช้เกณฑ์งานพื้น (ต้องเรียบ) กับงานฐานรากที่ texture ขรุขระเป็นปกติ
**วิธีแก้:** แก้ `QC_SYSTEM_PROMPT` ใน `server.cjs` (v1 Railway) — เพิ่มการแยก A/B/C concrete + Rule 8 benefit of doubt. Also แก้ `QC_PROMPT` ใน `QcUseCase.ts` (v2) สำหรับ future use
**Commit:** git push origin main → Railway auto-deploy (Jun 28, 2026)
**ป้องกัน:** QC prompt ต้องแยก structural vs finishing concrete เสมอ — ดู decisions.md "แยกคอนกรีตเป็น 3 ประเภท"
**สถานะ:** ✅ แก้แล้ว — รอ verify ด้วยการส่งรูปผ่าน LINE OA

### 🟡 WF1 CATEGORY_URL_MAP not defined — WF1 error ทุกวัน (เริ่ม Jun 21)
**อาการ:** "Finnhouses WF1 — Article + Publish" error ทุกวัน 9:00: `ReferenceError: CATEGORY_URL_MAP is not defined [line 114]`
**Root cause:** WF1 "Topic Engine PRO" node ใช้ `CATEGORY_URL_MAP` แต่ไม่ได้ define ไว้ใน jsCode — variable ถูกลบหายระหว่าง session เก่า
**Fix ที่มีอยู่:** `WF1_fixed_keyword_lock.json` (สร้าง session 10) — มี `CATEGORY_URL_MAP` define ครบ + keyword lock bug fix
**ขั้นตอน import:** n8n → Workflows → "Finnhouses WF1" → ... → Import from file → `D:\ARCHI\01_PROJECTS\memory\n8n-workflows\WF1_fixed_keyword_lock.json` → Save → Activate
**หมายเหตุ:** ไฟล์เคยอยู่ที่ `CORE/threme web/finnhouses-theme/` → ย้ายมา `memory/n8n-workflows/` แล้ว (session 13)
**สถานะ:** 🟡 รอ user import เข้า n8n

---

## 2026-06-26 (session 12) — QC LINE System

### ✅ LINE Download Image — 401 Unauthorized
**อาการ:** n8n node "Download Image from LINE" ตอบ 401 ทุกครั้ง
**Root cause:** LINE channel access token ที่ hardcode ใน workflow หมดอายุ (tokens expire)
**วิธีแก้:** LINE Developers Console → Messaging API → Channel access token → Issue → copy token ใหม่ → replace ใน workflow JSON (ทั้ง Download Image และ LINE Reply nodes)
**ป้องกัน:** เมื่อเห็น 401 บน api-data.line.me หรือ api.line.me → renew token ก่อนเสมอ
**สถานะ:** ✅ แก้แล้ว Jun 26

### ✅ Supabase Storage Upload — 415 Unsupported Media Type
**อาการ:** n8n node "Upload to Storage" ตอบ 415 เมื่อ PUT image ไปที่ Supabase Storage
**Root cause:** n8n HTTP Request node ส่ง binary data ด้วย `Content-Type: application/octet-stream` (default) แต่ Supabase Storage ต้องการ MIME type จริงของไฟล์ (`image/jpeg`)
**วิธีแก้:** เพิ่ม header `Content-Type: image/jpeg` ใน Upload node (hardcode เพราะ QC photos เป็น JPEG เสมอ)
**ป้องกัน:** Supabase Storage PUT ต้องมี Content-Type ถูกต้อง — อย่าพึ่ง default
**สถานะ:** ✅ แก้แล้ว Jun 26

### ✅ Hub /api/qc/ingest — 400 `line_message_id and photo_url required`
**อาการ:** POST ไปที่ Hub /api/qc/ingest ตอบ 400 แม้ workflow ส่ง keypairs ครบ
**Root cause (confirmed Jun 26):** Hub ใช้ `express.json()` middleware ซึ่ง parse เฉพาะ `Content-Type: application/json` เท่านั้น n8n HTTP Request v4 ที่ใช้ `specifyBody:"keypairs"` + `bodyContentType:"json"` ส่ง Content-Type ผิดหรือไม่ส่ง → Express ไม่ parse → `req.body = {}` → validation fail
**วิธีแก้:** เปลี่ยน node type จาก `n8n-nodes-base.httpRequest` เป็น `n8n-nodes-base.function` → ใช้ Node.js `https` module โดยตรง (ควบคุม Content-Type ได้ 100%)
**ใช้กับ:** POST Hub /api/qc/ingest, LINE Reply API, Log Latency (ทั้งหมดใน v5)
**ไฟล์:** `memory/qc-line-system/02-n8n/wf_qc_line_hardcoded.json` versionId:"5"
**ป้องกัน:** n8n HTTP Request keypairs ไม่น่าเชื่อถือสำหรับ JSON POST ที่ server ใช้ express.json() — ใช้ Function node + raw https เสมอ
**สถานะ:** ✅ แก้แล้ว (v5→v6 Code node)

### ✅ n8n Function node — `Cannot read properties of undefined (reading 'split')`
**อาการ:** n8n 2.21.4 POST nodes throw `TypeError: Cannot read properties of undefined (reading 'split')` at `Function.node.ts:215:84`
**Root cause:** Legacy `n8n-nodes-base.function` (typeVersion 1) ทำ `functionCode.split('await')` ที่ line 215 เพื่อ detect async usage — ถ้า `functionCode` = `undefined` หลัง JSON import quirk จะ throw ก่อน user code รัน (framework bug ใน 2.21.4)
**วิธีแก้:** เปลี่ยน 3 POST nodes เป็น `n8n-nodes-base.code` (typeVersion 1, parameter: `jsCode`) — Code node เป็น modern replacement ที่ handle async/await natively
**ไฟล์:** `memory/qc-line-system/02-n8n/wf_qc_line_hardcoded.json` versionId:"6"
**ป้องกัน:** n8n 2.21.4+ ให้ใช้ Code node แทน Function node สำหรับทุก async operation
**สถานะ:** ✅ แก้แล้ว Jun 26 — Hub POST confirmed working (inspection_id returned)

### 🔴→✅ Supabase Storage Upload — 0 bytes / OpenAI `invalid_image`
**อาการ:** Upload to Supabase Storage สำเร็จ (HTTP 200) แต่ไฟล์มี 0 bytes → Hub เรียก OpenAI ด้วย public URL → OpenAI ตอบ 400: `"Image downloaded contains no data"` → Hub 502 `ai_failed`
**Root cause:** n8n `binaryDataMode: filesystem` — เมื่อ binary data ผ่าน Function/Code node (Build Storage Key) ซึ่งทำ `binary: $input.first().binary` ใน return value → binary file reference ถูก copy แต่อาจ invalid หรือ garbage collected ก่อน HTTP Upload node อ่าน → PUT body = 0 bytes
**วิธีแก้ (v7):** ย้าย "Build Storage Key" logic ไปเป็น "Prepare Event Data" Code node ที่รันก่อน download (output เฉพาะ JSON ไม่มี binary) → Download → Upload ต่อกันโดยตรง ไม่มี node กลางสัมผัส binary → URL ของ Download ใช้ `{{$json.line_message_id}}` แทน `{{$json.message.id}}`
**ไฟล์:** `memory/qc-line-system/02-n8n/wf_qc_line_hardcoded.json` versionId:"7"
**กฎทอง:** อย่าให้ binary data ผ่าน Function/Code node ใน n8n filesystem mode — Download → Upload ต้องต่อกันตรงๆ เสมอ
**สถานะ:** ✅ Fix เขียนแล้ว (v7) — ยืนยันแล้วว่า structure ถูก แต่ยัง fail เพราะ Upload node ใช้ wrong binary params (→ ดู issue ถัดไป)

### 🔴→✅ Upload to Storage — Wrong binary param syntax for HTTP Request typeVersion 4
**อาการ:** v7 Upload node ไม่ส่ง body เลย แม้ connections ถูกต้องแล้ว — ยัง 0 bytes
**Root cause:** n8n HTTP Request **typeVersion 4** ใช้ syntax ต่างจาก v1/v2 สำหรับ binary upload:
- ❌ v1/v2 (ที่ v7 ใช้): `sendBinaryData: true, binaryPropertyName: "data"` — n8n v4 ไม่รู้จัก → strip ออก → PUT ไม่มี body
- ✅ v4 (ถูกต้อง): `sendBody: true, contentType: "binaryData", inputDataFieldName: "data"`
**วิธีแก้ (v8):** เปลี่ยน Upload node parameters เป็น `sendBody: true, contentType: "binaryData", inputDataFieldName: "data"`
**ไฟล์:** `memory/qc-line-system/02-n8n/wf_qc_line_hardcoded.json` versionId:"8"
**กฎทอง:** HTTP Request node typeVersion 4 binary upload = `sendBody+contentType:"binaryData"+inputDataFieldName` — ไม่ใช่ `sendBinaryData+binaryPropertyName`
**สถานะ:** ✅ Fix เขียนแล้ว (v8) — รอ import และทดสอบ

---

## 2026-06-12 (session 10)

### ✅ hub_state RLS — anon INSERT/UPDATE blocked (code 42501)
**อาการ:** Hub logs: `[hub] writeState Supabase error: HTTP 401 {"code":"42501","message":"new row violates row-level security policy for table \"hub_state\""}` ทุก restart/save
**Root cause:** `hub_state` table มี RLS enabled มีแค่ `service_role_all` policy — Hub ใช้ anon key (fallback จาก `process.env.SUPABASE_ANON_KEY` เพราะ Railway ไม่ได้ set `SUPABASE_SERVICE_KEY`) → anon role ไม่มี INSERT/UPDATE policy → 42501
**วิธีแก้:** เพิ่ม 3 policies ผ่าน Supabase MCP migration `hub_state_anon_rls_policy`:
- `anon_select` — SELECT TO anon USING (true)
- `anon_insert` — INSERT TO anon WITH CHECK (true)  
- `anon_update` — UPDATE TO anon USING (true) WITH CHECK (true)
**ป้องกัน:** Backend service (Hub, Railway) ควรใช้ `SUPABASE_SERVICE_KEY` (service_role) แทน anon key — เพิ่ม `SUPABASE_SERVICE_KEY` ใน Railway Hub env vars เป็น long-term fix (bypass RLS ทั้งหมด)
**สถานะ:** ✅ แก้แล้ว Jun 12 — policies applied, Hub จะ writeState ได้ทันทีโดยไม่ต้อง redeploy

### ✅ FB Publish 401 — Vercel route missing x-hub-token header
**อาการ:** กด "สร้าง FB Post" ใน AI Content (Listing tab) → ❌ ผิดพลาด — DevTools แสดง `401` บน `api/fb/publish`
**Root cause:** `/app/api/fb/publish/route.ts` เรียก FB Backend (easygoing-friendship) โดยตรง (bypass Hub) แต่ **ไม่มี `x-hub-token` header** — ทั้งที่ `server.js` ของ FB Backend มี auth middleware (จาก S-10 / commit `1a43fd2`) ที่ require header นี้ทุก request (skip เฉพาะ `/health`)
**วิธีแก้:** เพิ่ม `"x-hub-token": process.env.HUB_SECRET ?? ""` ใน headers ของ fetch call ใน route.ts
**Commit:** `b129bf1` — `fix: add x-hub-token header to fb publish route`
**ป้องกัน:** ทุกครั้งที่ Vercel route เรียก Railway service (Hub หรือ FB Backend) โดยตรง ต้องมี `x-hub-token: process.env.HUB_SECRET` เสมอ — ตรวจ "13 Vercel→Hub proxy routes" + route ที่ bypass Hub ทั้งหมด

---

## 2026-06-08 (session 8)

### ✅ n8n Market Intelligence Collector — `access to env vars denied`
**อาการ:** Code nodes ใน Market Intelligence Collector v1 throw `access to env vars denied` แม้ set `N8N_BLOCK_ENV_ACCESS_IN_NODE=false` บน Primary service แล้ว
**Root cause:** `EXECUTIONS_MODE=queue` → n8n route Code node execution ไปยัง Worker service (Railway container แยก) — Worker ไม่ inherit env flag จาก Primary. แม้ set `OFFLOAD_MANUAL_EXECUTIONS_TO_WORKERS=false` / `N8N_RUNNERS_ENABLED=false` / `N8N_RUNNERS_ENV_ALLOWLIST` ก็ไม่ช่วย เพราะ webhook executions ยังไป Worker เสมอ
**วิธีแก้:** Hardcode `SUPABASE_SERVICE_KEY` โดยตรงใน 3 Code nodes แทน `$env.SUPABASE_SERVICE_KEY`
**ไฟล์:** `memory/n8n-workflows/Finnhouses — Market Intelligence Collector v1 (hardcoded).json`
**ป้องกัน:** n8n queue mode = `$env` ใช้ไม่ได้ใน Code nodes เสมอ (ไม่ว่าจะ set env flag ยังไง) — ต้องใช้ hardcode หรือ HTTP Request node + Credentials
**สถานะ:** ✅ แก้แล้ว Jun 8

### ✅ Telegram — `Bad Request: chat not found` แม้ chatId ถูกต้อง
**อาการ:** Telegram node ใน Market Intelligence Collector throw `400 Bad Request: chat not found` ทั้งที่ chatId `8589960853` ถูกต้อง
**Root cause:** Telegram bot ไม่สามารถส่งข้อความหา user ได้ถ้า user ยังไม่เคย /start bot นั้น — @finnhouses_intel_bot ยังไม่เคยถูก start
**วิธีแก้:** เปิด Telegram → search @finnhouses_intel_bot → กด Start → bot สามารถส่งข้อความได้
**ป้องกัน:** bot ใหม่ทุกตัว user ต้อง /start ก่อนเสมอ ก่อนที่ workflow จะ Telegram ได้
**สถานะ:** ✅ แก้แล้ว Jun 8

---

## 2026-06-07 (session 7)

### ✅ n8n Code node — `fetch is not defined`
**อาการ:** Code node ใน wf_crm_note_parser (node "Send Telegram Summary") throw `fetch is not defined [line 7]`
**Root cause:** n8n 2.21.4 task runner sandbox ไม่ expose `fetch` global — ใช้ browser-like API ไม่ได้
**วิธีแก้:** แทน `fetch()` ทุก call ด้วย `this.helpers.httpRequest({method, url, headers, body: object, json: true})` — body คือ plain JS object ไม่ต้อง `JSON.stringify`, `json: true` จัดการ serialize + parse response ให้อัตโนมัติ
**ใช้ใน:** Parse with Claude Haiku + Save to Supabase
**ป้องกัน:** Code node ใน n8n ห้ามใช้ `fetch`, `axios`, `XMLHttpRequest` — ใช้ `this.helpers.httpRequest()` เสมอ
**สถานะ:** ✅ แก้แล้ว Jun 7

### ✅ n8n Telegram — HTTP 401 เมื่อใช้ token ตรง
**อาการ:** Code node เรียก Telegram API (`api.telegram.org/bot.../sendMessage`) ด้วย token จาก `.env.local` → 401 Unauthorized
**Root cause:** Bot token ที่เก็บใน `.env.local` คืนค่า 401 เมื่อใช้ใน `this.helpers.httpRequest()` โดยตรง — แต่ token เดียวกันทำงานได้ผ่าน n8n credential `gmqmxxSq3X1Y6Ykr`
**วิธีแก้:** แยก node "Send Telegram Summary" ออกเป็น 2 nodes:
1. "Build Telegram Message" (Code node) — สร้าง `{chat_id, message}` ออกมา ไม่ทำ HTTP
2. "Send Telegram" (native `n8n-nodes-base.telegram`) — ใช้ credential `gmqmxxSq3X1Y6Ykr` ("Telegram account")
**ป้องกัน:** Telegram ใน n8n ใช้ native Telegram node + credential เสมอ ไม่ต้องทำ HTTP call เอง
**สถานะ:** ✅ แก้แล้ว Jun 7

### ✅ n8n Workflow — Connection broken หลัง rename node
**อาการ:** Workflow มี 7 nodes ครบ แต่ Telegram ไม่รับ message — ดูเหมือน Save to Supabase ไม่ส่งต่อ
**Root cause:** Rename node ใน `connections` dict ต้องอัพเดท 2 ที่: (1) key ของ connections object (ชื่อ source node) (2) `node` field ใน target ของทุก node ที่ชี้มาหา — แต่ script แก้แค่ (1) ทำให้ `connections['Save to Supabase'][main][0][0].node` ยังเป็น `"Send Telegram Summary"` (ชื่อเก่า ที่ไม่มีอยู่แล้ว)
**วิธีแก้:** Fix `wf['connections']['Save to Supabase'] = {"main": [[{"node": "Build Telegram Message", "type": "main", "index": 0}]]}`
**ป้องกัน:** เมื่อ rename node ใน JSON ต้อง grep หาชื่อเก่าทุก occurrence ใน connections dict ทั้งไฟล์
**สถานะ:** ✅ แก้แล้ว Jun 7

---

## 2026-06-07 (session 6)

### 🔴 WF2 — Notify Hub nodes ล้มเหลวหลัง Phase A Security deploy
**อาการ:** WF2 Jun 7, 09:00 — Error ที่ "Notify Hub Image Done": `Authorization failed - please check your credentials`
**Root cause:** Phase A Security (commit `ca5d467`) เพิ่ม `x-hub-token` auth ให้ Hub (server.cjs) แต่ WF2 ทั้ง 3 nodes ที่ call Hub ไม่มี header นี้ → 401
**3 nodes ที่ต้องแก้:** Notify Hub Image Done / Notify Hub Image Failed / Notify Hub Binary Failed (ทั้งหมด call `/webhook/image-done`)
**วิธีแก้:** n8n WF2 → แต่ละ node → Headers → เพิ่ม `x-hub-token: <HUB_SECRET>` (hardcode เพราะ n8n 2.21.4 block $env)
**HUB_SECRET:** Railway → ap-home-platform Hub service → Variables
**ป้องกัน:** ทุกครั้งที่เพิ่ม auth ให้ Hub ต้องตรวจ n8n workflows ทุกตัวว่า call Hub endpoint ไหนบ้าง แล้วอัพเดท header พร้อมกัน
**สถานะ:** ✅ แก้แล้ว Jun 7

---

## 2026-06-06 (session 5)

### ✅ SVG diagonal slash — Flow lines ตัดข้ามหน้าจอ
**อาการ:** เส้น animate ระหว่าง node ลาก diagonal ผ่ากลาง canvas แทนที่จะโค้งหรือพับฉาก
**Root cause:** `drawLine()` คำนวณ Bezier control points เป็น fraction ของ dx/dy → control points ยังอยู่บนเส้นตรงระหว่าง node → path ดูเหมือน diagonal เกือบตรง
**วิธีแก้:** เปลี่ยนเป็น orthogonal H→V→H routing:
- midX = (a.x + b.x) / 2
- Path: `M a.x,a.y H midX-R Q midX,a.y midX,a.y+R V b.y-R Q midX,b.y midX+R,b.y H b.x`
- Corner radius R = min(10, adx*0.45, ady*0.45)
- Special case: adx<3 → straight V, ady<3 → straight H
**ป้องกัน:** ใช้ orthogonal routing เสมอสำหรับ flow diagram SVG — ห้ามใช้ Bezier ที่ control point เป็น fraction ตรงๆ

### ✅ fb_back node ไม่มี flow step
**อาการ:** Service node `FB Backend` แสดงบน canvas แต่ไม่มี step ใดที่ highlight node นี้เลย
**Root cause:** step array ของ AI Content ไม่มี `{from:'hub', to:'fb_back'}` หรือ `{from:'fb_back', to:'facebook'}`
**วิธีแก้:** เพิ่ม 2 steps ที่ท้าย keyword flow: step ⑬ `hub→fb_back` (POST easygoing-friendship) + step ⑭ `fb_back→facebook`

## 2026-06-06 (session 4)

### ✅ S-10 FB Backend Auth — Fixed
**อาการ:** ใครรู้ Railway URL ของ easygoing-friendship → POST `/api/fb/publish` โดยตรงได้ → โพสต์ FB Page ได้โดยไม่ต้องผ่าน Dashboard
**Root cause:** `server.js` ไม่มี auth middleware ใดๆ + Hub ไม่ส่ง `x-hub-token` ไปหา FB Backend
**วิธีแก้:**
1. `server.js` — เพิ่ม `timingSafeEq()` + auth middleware (skip /health เท่านั้น)
2. `server.cjs` — เพิ่ม `"x-hub-token": HUB_SECRET` header ใน 2 จุดที่ call FB Backend (`/action/fb/publish` + `/action/fb/queue/run-next`)
3. Railway `easygoing-friendship` — เพิ่ม env var `HUB_SECRET` (ค่าเดียวกับ Hub + Vercel)
**Commit:** `1a43fd2`
**ป้องกัน:** ทุกครั้งที่เพิ่ม service ใหม่ใน Railway ต้องตั้ง `HUB_SECRET` และเพิ่ม auth middleware เสมอ

---

## 2026-06-05

### 🔴 Topic Engine PRO override keyword จาก Blog Runner UI
**อาการ:** เลือก keyword จาก Category/Keyword Pool ใน Blog Runner → บทความที่ออกมาไม่ตรงกับ keyword ที่เลือก
**Root cause:** `Topic Engine PRO` node ใน WF1 คำนวณ keyword จาก internal rotation (วันที่ + slot) และ **override** ค่า `ctx.keyword` ที่ส่งมาจาก Hub ทุกครั้ง — ไม่มี manual override path
**วิธีแก้:** เพิ่ม logic ตรวจ `ctx.keyword` ก่อน:
- ถ้า `ctx.keyword` มีค่า (manual run) → ใช้ keyword + category นั้นตรงๆ (`is_manual_run: true`)
- ถ้าว่าง (schedule run) → rotate ตามวันเดิม
- เพิ่ม `categoryIdToPillar` mapping ครอบคลุม WP category 33/34/35/36
- เพิ่ม editorial metadata สำหรับ pillar: `reno`, `zone`, `seller`
**ไฟล์:** `memory/n8n-workflows/Finnhouses_WF1_Article_Publish.json` — node "Topic Engine PRO"
**Import:** import ไปยัง n8n workflow "Finnhouses WF1 — Article + Publish" (ID: ดูใน n8n) แล้ว

### 🔴 Build Schedule Context ไม่ pass keyword จาก webhook
**อาการ:** Blog Runner เลือก keyword จาก Category/Keyword Pool → Topic Engine PRO ยังคง auto-rotate ตามวัน ไม่ใช้ keyword ที่เลือก (แม้หลัง fix Topic Engine PRO แล้ว)
**Root cause:** "Build Schedule Context" node สร้าง json ใหม่ทั้งหมดโดยไม่ spread/pass `keyword`, `category`, `runId`, `visual_hint` จาก webhook → ทำให้ค่าเหล่านี้หายไปก่อนถึง Topic Engine PRO
**วิธีแก้:** เพิ่ม 4 บรรทัดใน return ของ Build Schedule Context:
```js
keyword:     $input.first().json.keyword     || '',
category:    $input.first().json.category    || 13,
runId:       $input.first().json.runId       || '',
visual_hint: $input.first().json.visual_hint || 'contemporary',
```
**สถานะ:** ❌ ยังไม่ได้แก้ — ต้องแก้ตรงใน n8n node (session หน้า)
**ไฟล์:** n8n → workflow "Finnhouses WF1 — Article + Publish" → node "Build Schedule Context"

### 🟡 Workflow ใน memory ไม่ตรงกับที่ใช้จริงใน n8n
**อาการ:** Claude suggest แก้ "Finnhouses FULL PRO MASTER FLOW V3.2 FIXED.json" แต่ workflow นั้นไม่ได้ใช้แล้ว
**Root cause:** memory ไม่ได้ record ว่า V3.2 ถูก split เป็น WF1 + WF2 แล้ว
**วิธีแก้:** เช็ค workflow JSON จริงก่อน suggest เสมอ — อย่า assume จากชื่อไฟล์
**กฎ:** ก่อน suggest แก้ n8n workflow ใดๆ ต้อง python3 list nodes ก่อนทุกครั้ง

---

## 2026-06-03

### 🔴 FB Token หมดอายุก่อนกำหนด
**อาการ:** Post to Facebook ล้มเหลว ❌ ผิดพลาด  
**Root cause:** Token ที่ set ใน Railway เป็น Short-lived token (~1 วัน) ไม่ใช่ Long-lived  
**วิธีแก้:**
1. Graph API Explorer → Generate Access Token (Page token)
2. CMD: `curl "https://graph.facebook.com/oauth/access_token?grant_type=fb_exchange_token&client_id=APP_ID&client_secret=APP_SECRET&fb_exchange_token=SHORT_TOKEN"` → ได้ Long-lived token (~60 วัน)
3. ใส่ใน Railway easygoing-friendship → `FB_PAGE_ACCESS_TOKEN` → Redeploy
**ป้องกัน:** ทุกครั้งที่ renew ต้อง exchange เป็น Long-lived ก่อนเสมอ  
**ไฟล์:** `get-fb-page-token.bat` ใน `Documents\Claude\Projects\AP home OS\`

---

### 🟡 URL Encoded ใน FB Post (จาก Listing tab)
**อาการ:** Post content มี `%e0%b8%84%e0%b8%a5%e0%b8%ad-2/` แทน URL ภาษาไทย  
**Root cause:** `selected.link` มี Thai slug ที่ URL-encoded → Claude paste ตรงๆ โดยไม่ decode  
**วิธีแก้:** เพิ่ม `decodeURIComponent()` ก่อนส่ง prompt  
**ไฟล์:** `components/AIContent.tsx` บรรทัด ~1070  
**Commit:** `887aeac`

---

### 🟡 Ahrefs Health Score 22% — 66 broken URLs
**อาการ:** Internal URLs having errors 439 รายการ  
**Root cause:** Nav links ชี้ไปหน้าที่ไม่มี (`/build-house`, `/contact`, `/privacy-policy` ฯลฯ) + Blog links ที่ AI generate แต่ไม่มี page จริง  
**วิธีแก้:**
1. เพิ่ม redirect rules ใน `.htaccess` (63 URLs)
2. Publish Privacy Policy page (slug: `privacy-policy`)
3. อัพโหลด 5 รูป placeholder ที่หาย
**ไฟล์:** `htaccess` ใน `Documents\Claude\Projects\AP home OS\`

---

### 🟡 .htaccess อัพโหลดผิด folder
**อาการ:** อัพโหลด `htaccess` ไปที่ `public_html/` root แทนที่จะเป็น `public_html/finnhouses.com/`  
**Root cause:** cPanel แสดง structure ซ้อนกัน สับสน root vs site folder  
**วิธีแก้:** ต้องเข้า folder `finnhouses.com/` ก่อนค่อยอัพ  
**ป้องกัน:** WordPress ของ finnhouses.com อยู่ใน `public_html/finnhouses.com/` เสมอ

---

## Template สำหรับเพิ่ม Issue ใหม่

```
### 🔴/🟡/🟢 ชื่อปัญหา
**อาการ:** [สิ่งที่เห็น]
**Root cause:** [สาเหตุจริง]
**วิธีแก้:** [ขั้นตอน]
**ป้องกัน:** [ทำอะไรเพื่อไม่ให้เกิดซ้ำ]
**ไฟล์/Commit:** [reference]
```

🔴 = Critical (ระบบพัง) | 🟡 = Warning (บางส่วนพัง) | 🟢 = Minor (cosmetic)
