// routes/qc.js — QC endpoints for Hub
// Mount in your Hub app:  app.use('/api/qc', require('./routes/qc'));

const express = require('express');
const repo    = require('../services/qcRepo');
const { callOpenAIVision } = require('../services/qcAi');

const router = express.Router();

// Simple shared-secret auth (n8n & Dashboard use the same Hub, so gate with header)
function internalAuth(req, res, next) {
  const key = req.headers['x-hub-key'];
  if (!key || key !== process.env.HUB_INTERNAL_KEY) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}

// Cost ceiling (฿ per day). Default 300 THB.
const DAILY_BUDGET_THB = Number(process.env.QC_DAILY_BUDGET_THB || 300);
// Rough cost per 1K tokens (GPT-4o, input + output blended) in THB
const THB_PER_1K_IN  = Number(process.env.QC_THB_PER_1K_IN  || 0.18);
const THB_PER_1K_OUT = Number(process.env.QC_THB_PER_1K_OUT || 0.54);

function estimateCostThb(tokensIn, tokensOut) {
  return (tokensIn / 1000) * THB_PER_1K_IN + (tokensOut / 1000) * THB_PER_1K_OUT;
}

// -----------------------------------------------------------
// POST /api/qc/ingest
// Body: { line_message_id, line_user_id, photo_url, caption, timestamp }
// -----------------------------------------------------------
router.post('/ingest', internalAuth, async (req, res) => {
  const started = Date.now();
  const { line_message_id, line_user_id, photo_url, caption } = req.body || {};

  if (!line_message_id || !photo_url) {
    return res.status(400).json({ error: 'line_message_id and photo_url required' });
  }

  // Idempotency — if already processed, return existing
  const existing = await repo.findExistingInspection(line_message_id);
  if (existing) {
    return res.json({ inspection_id: existing.id, duplicate: true, ...existing });
  }

  // Budget guard
  const usage = await repo.getDailyUsage();
  if (Number(usage.est_cost_thb || 0) >= DAILY_BUDGET_THB) {
    return res.status(429).json({ error: 'daily_budget_exceeded', usage });
  }

  // Resolve site + user
  await repo.upsertLineUser({ lineUserId: line_user_id });
  const site = await repo.resolveSiteId({ caption, lineUserId: line_user_id });

  // Pre-create inspection as 'processing' (guarantees idempotency even on AI error)
  const inspection = await repo.createInspection({
    line_message_id,
    line_user_id,
    site_id:   site?.id || null,
    photo_url,
    caption:   caption || null,
    status:    'processing'
  });

  // Call AI
  let ai;
  try {
    ai = await callOpenAIVision({
      photoUrl: photo_url,
      caption,
      stage:    site?.stage,
      siteCode: site?.code
    });
  } catch (err) {
    await repo.updateInspection(inspection.id, {
      status: 'failed',
      error_message: String(err.message || err).slice(0, 500),
      latency_ms: Date.now() - started
    });
    return res.status(502).json({
      error: 'ai_failed',
      inspection_id: inspection.id,
      detail: String(err.message || err)
    });
  }

  // Persist AI result
  await repo.updateInspection(inspection.id, {
    ai_summary: ai.ai_summary,
    pass:       ai.pass,
    severity:   ai.severity,
    confidence: ai.confidence,
    defects_json: ai.defects,
    ai_model:   ai._model,
    ai_raw:     ai._raw,
    status:     'done',
    latency_ms: Date.now() - started
  });

  await repo.insertDefects(inspection.id, ai.defects);

  // Budget accounting
  const costThb = estimateCostThb(ai._tokens_in, ai._tokens_out);
  await repo.bumpDailyUsage({
    tokensIn:  ai._tokens_in,
    tokensOut: ai._tokens_out,
    costThb
  });

  return res.json({
    inspection_id: inspection.id,
    site_code:     site?.code || null,
    pass:          ai.pass,
    severity:      ai.severity,
    confidence:    ai.confidence,
    ai_summary:    ai.ai_summary,
    defects:       ai.defects,
    dashboard_url: `${process.env.DASHBOARD_URL || ''}/qc/${inspection.id}`
  });
});

// -----------------------------------------------------------
// GET /api/qc/list?site_id=&from=&to=&limit=
// For Dashboard
// -----------------------------------------------------------
router.get('/list', internalAuth, async (req, res) => {
  const { site_id, from, to, limit } = req.query;
  const rows = await repo.listInspections({
    siteId: site_id,
    from,
    to,
    limit: limit ? Math.min(Number(limit), 500) : 50
  });
  res.json({ items: rows });
});

// -----------------------------------------------------------
// POST /api/qc/log-latency
// -----------------------------------------------------------
router.post('/log-latency', internalAuth, async (req, res) => {
  const { line_message_id, total_ms } = req.body || {};
  if (!line_message_id) return res.status(400).json({ error: 'missing' });
  const existing = await repo.findExistingInspection(line_message_id);
  if (!existing) return res.status(404).json({ error: 'not_found' });
  await repo.updateInspection(existing.id, { latency_ms: total_ms });
  res.json({ ok: true });
});

// Health
router.get('/health', (_req, res) => res.json({ ok: true, service: 'qc' }));

module.exports = router;
