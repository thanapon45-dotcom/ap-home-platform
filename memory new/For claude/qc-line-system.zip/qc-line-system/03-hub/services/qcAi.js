// services/qcAi.js — AI vision call for QC inspection
// Uses OpenAI GPT-4o by default. Swap to Claude vision by implementing callClaude().

const SYSTEM_PROMPT = `คุณคือ QC Inspector ตรวจคุณภาพงานช่างก่อสร้างและรีโนเวทในประเทศไทย สำหรับบริษัทรับสร้างบ้าน Finnhouses

วัตถุประสงค์: ตรวจคุณภาพงานช่าง (workmanship quality) ของงานที่ทำอยู่หรือทำเสร็จแล้ว
ไม่ใช่: ประเมินความปลอดภัยส่วนตัวของคนงาน (ห้ามรายงาน PPE หรือ safety equipment ของคนงาน)

หมวดงานที่ตรวจ:
- concrete     งานคอนกรีต: ความเรียบผิว, ฟองอากาศ, honeycomb, รอยแตกร้าว, การ cure
- plaster      งานก่อฉาบ: ความเรียบ, มุมฉาก, ระดับ, รอยร้าวเส้นผม, การยึดเกาะ
- level        งานเส้น/Line Level: ความได้ระดับ, ความฉาก, alignment ผนัง/พื้น/เพดาน
- electrical   งานระบบไฟฟ้า: การเดินสาย, กล่อง, ช่องเดินสาย, socket/switch box ฝัง
- plumbing     งานระบบน้ำ: ท่อ, ข้อต่อ, การฝัง, slope ระบายน้ำ, จุดรั่วซึม
- paint        งานสี: ความสม่ำเสมอ, ไม่มีรอยแปรง/ลูกกลิ้ง, ความสะอาดขอบ, ตกหล่น
- finishing    งานFinishing: ประตู/หน้าต่าง, กระเบื้อง, ฝ้า, ความเรียบร้อยงานสุดท้าย
- structure    โครงสร้าง: เสา, คาน, ผนัง, ความแข็งแรง, การเสริมเหล็ก (ถ้าเห็น)
- cleanliness  ความสะอาดหน้างาน: วัสดุเศษ, ความเป็นระเบียบ
- other        งานอื่นที่ไม่ตรงหมวดข้างต้น

ระดับ severity: none | low | medium | high | critical

กติกา:
1. ตอบเป็น JSON เท่านั้น ห้ามมีข้อความอื่นนอก JSON
2. โฟกัสที่คุณภาพงานช่าง ไม่ใช่ความปลอดภัยส่วนตัวคนงาน
3. ถ้ารูปไม่ใช่งานก่อสร้าง/รีโนเวท ให้ pass=true severity=none defects=[] ai_summary="รูปไม่ใช่หน้างาน"
4. defects เรียงจากสำคัญสุดลงมา สูงสุด 5 รายการ
5. description ให้ specific: เช่น "รอยร้าวลายแตกที่มุมขวาบนฝ้า ยาว ~20 ซม." ไม่ใช่ "มีรอยร้าว"
6. suggested_action ต้องทำได้จริง: เช่น "ฉาบ skim coat ปาดเรียบ ทาสีทับ"
7. ถ้า defect severity เป็น high หรือ critical อย่างน้อย 1 รายการ → pass=false

Schema ที่ต้องตอบ:
{
  "pass": boolean,
  "severity": "none|low|medium|high|critical",
  "confidence": 0.0-1.0,
  "ai_summary": "1-2 ประโยคภาษาไทย สรุปคุณภาพงาน",
  "defects": [
    {
      "category": "plaster",
      "description": "...",
      "severity": "...",
      "location_hint": "...",
      "suggested_action": "..."
    }
  ]
}`;

function buildUserMessage({ caption, stage, siteCode }) {
  const parts = [];
  if (siteCode) parts.push(`Site: ${siteCode}`);
  if (stage)    parts.push(`Stage: ${stage}`);
  if (caption)  parts.push(`Caption: ${caption}`);
  parts.push('โปรดตรวจรูปนี้และตอบ JSON ตาม schema');
  return parts.join('\n');
}

async function callOpenAIVision({ photoUrl, caption, stage, siteCode }) {
  const started = Date.now();

  const body = {
    model: process.env.OPENAI_MODEL || 'gpt-4o',
    temperature: 0,
    max_tokens: 800,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      {
        role: 'user',
        content: [
          { type: 'text', text: buildUserMessage({ caption, stage, siteCode }) },
          { type: 'image_url', image_url: { url: photoUrl, detail: 'high' } }
        ]
      }
    ]
  };

  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`OpenAI ${res.status}: ${err}`);
  }

  const data = await res.json();
  const raw  = data.choices?.[0]?.message?.content || '{}';

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    throw new Error(`AI returned non-JSON: ${raw.slice(0, 200)}`);
  }

  // Normalize
  parsed.pass       = !!parsed.pass;
  parsed.severity   = parsed.severity   || 'none';
  parsed.confidence = typeof parsed.confidence === 'number' ? parsed.confidence : 0.7;
  parsed.ai_summary = parsed.ai_summary || '';
  parsed.defects    = Array.isArray(parsed.defects) ? parsed.defects.slice(0, 5) : [];

  return {
    ...parsed,
    _raw: data,
    _latency_ms: Date.now() - started,
    _model: body.model,
    _tokens_in:  data.usage?.prompt_tokens || 0,
    _tokens_out: data.usage?.completion_tokens || 0
  };
}

module.exports = { callOpenAIVision };
