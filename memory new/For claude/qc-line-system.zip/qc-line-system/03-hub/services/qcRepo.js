// services/qcRepo.js — All DB access for QC domain (Supabase)

const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { persistSession: false } }
);

// Parse site code from caption. Matches patterns like BKK-045, NON-018.
function extractSiteCode(caption = '') {
  const m = caption.match(/\b[A-Z]{2,4}-\d{2,4}\b/);
  return m ? m[0] : null;
}

async function resolveSiteId({ caption, lineUserId }) {
  const code = extractSiteCode(caption || '');
  if (code) {
    const { data } = await supabase.from('sites').select('id,code,stage').eq('code', code).maybeSingle();
    if (data) return data;
  }
  if (lineUserId) {
    const { data } = await supabase
      .from('line_users')
      .select('default_site_id, sites(id,code,stage)')
      .eq('line_id', lineUserId)
      .maybeSingle();
    if (data?.sites) return data.sites;
  }
  return null;
}

async function upsertLineUser({ lineUserId, displayName }) {
  if (!lineUserId) return;
  await supabase.from('line_users').upsert(
    {
      line_id: lineUserId,
      display_name: displayName || null,
      last_seen_at: new Date().toISOString()
    },
    { onConflict: 'line_id' }
  );
}

async function findExistingInspection(lineMessageId) {
  const { data } = await supabase
    .from('qc_inspections')
    .select('id,pass,severity,ai_summary,confidence,site_id')
    .eq('line_message_id', lineMessageId)
    .maybeSingle();
  return data;
}

async function createInspection(payload) {
  const { data, error } = await supabase
    .from('qc_inspections')
    .insert(payload)
    .select()
    .single();
  if (error) throw error;
  return data;
}

async function updateInspection(id, patch) {
  const { error } = await supabase.from('qc_inspections').update(patch).eq('id', id);
  if (error) throw error;
}

async function insertDefects(inspectionId, defects = []) {
  if (!defects.length) return;
  const rows = defects.map(d => ({
    inspection_id:    inspectionId,
    category:         d.category || 'other',
    description:      d.description || '',
    severity:         d.severity || 'low',
    location_hint:    d.location_hint || null,
    suggested_action: d.suggested_action || null
  }));
  const { error } = await supabase.from('qc_defects').insert(rows);
  if (error) throw error;
}

async function getDailyUsage() {
  const { data } = await supabase
    .from('qc_daily_usage')
    .select('*')
    .eq('day', new Date().toISOString().slice(0, 10))
    .maybeSingle();
  return data || { inspections: 0, est_cost_thb: 0 };
}

async function bumpDailyUsage({ tokensIn, tokensOut, costThb }) {
  const day = new Date().toISOString().slice(0, 10);
  // Upsert row then increment
  await supabase.rpc('qc_bump_daily', {
    p_day: day,
    p_tokens_in: tokensIn,
    p_tokens_out: tokensOut,
    p_cost: costThb
  }).catch(async () => {
    // Fallback if RPC not created: do non-atomic upsert
    const cur = await getDailyUsage();
    await supabase.from('qc_daily_usage').upsert({
      day,
      inspections: (cur.inspections || 0) + 1,
      ai_tokens_in: (cur.ai_tokens_in || 0) + tokensIn,
      ai_tokens_out: (cur.ai_tokens_out || 0) + tokensOut,
      est_cost_thb: Number(cur.est_cost_thb || 0) + costThb
    }, { onConflict: 'day' });
  });
}

async function listInspections({ siteId, from, to, limit = 50 }) {
  let q = supabase.from('qc_inspections_view').select('*').order('created_at', { ascending: false }).limit(limit);
  if (siteId) q = q.eq('site_id', siteId);
  if (from)   q = q.gte('created_at', from);
  if (to)     q = q.lte('created_at', to);
  const { data, error } = await q;
  if (error) throw error;
  return data;
}

module.exports = {
  resolveSiteId,
  upsertLineUser,
  findExistingInspection,
  createInspection,
  updateInspection,
  insertDefects,
  getDailyUsage,
  bumpDailyUsage,
  listInspections
};
