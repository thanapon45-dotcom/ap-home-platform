// server.example.js — minimal Hub bootstrap ที่โชว์วิธี mount QC routes
// ถ้า Archi Hub มี server เดิมอยู่แล้ว ให้ copy แค่บรรทัด app.use('/api/qc', qcRouter) ไปวางใน Hub จริง

const express = require('express');
const app = express();

app.use(express.json({ limit: '2mb' }));

// Mount QC module
app.use('/api/qc', require('./routes/qc'));

app.get('/health', (_req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`[hub] listening on :${PORT}`);
});
