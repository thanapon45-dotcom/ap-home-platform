# ระบบ QC อัตโนมัติผ่าน LINE — Blueprint v1

**Use case:** ช่างหน้างาน / PM / ลูกค้า ส่งรูปงานก่อสร้าง–รีโนเวท เข้า LINE OA → AI ตรวจ defect ตาม checklist Archi → ตอบกลับผู้ส่งคนเดิมภายใน ~15 วินาที + บันทึกเข้า Hub เพื่อดูย้อนหลังใน Dashboard

---

## 1. คำแนะนำเชิงสถาปัตยกรรม (สำคัญสุด)

**ใช้ n8n + Backend Hub (ของเดิม) ไม่ใช่ Make.com**

เหตุผล:
- Archi มี n8n (:5678) + Backend Hub (:4000) อยู่แล้ว — กฎสถาปัตยกรรมคือ *Hub เป็นผู้จัดการ state ศูนย์กลาง* และ *ลด moving parts*
- Make.com จะทำให้เกิด architecture drift — state กระจาย 2 ที่ (Make queues + Hub) debug ยาก และมีค่าใช้จ่าย Operations ทุก scenario run
- n8n self-hosted = cost 0, log/exec ตรวจย้อนหลังง่าย, reuse credential LINE/OpenAI เดิมได้
- ถ้าในอนาคตอยาก prototype เร็ว ค่อยใช้ Make เป็น entry point แต่ยัง POST เข้า Hub เหมือนเดิม (hybrid)

> ข้อยกเว้น: ถ้า Archi ต้องการให้ non-dev คน build เอง (ไม่แตะ n8n ของ dev) และยอมให้ QC flow แยก silo → Make ก็พอได้ แต่ห้ามเก็บ state ใน Make แค่ transport เฉยๆ

---

## 2. Node Map

```
┌──────────────┐   webhook    ┌──────────┐   HTTP    ┌─────────────────┐
│  LINE OA     │─────────────▶│   n8n    │──────────▶│  Backend Hub    │
│ (ช่าง/PM ส่ง) │              │ :5678    │           │  :4000          │
└──────▲───────┘              │          │           │  - ingest QC    │
       │                      │          │◀──────────│  - call AI      │
       │  reply               │          │  result   │  - persist      │
       │                      │          │           │  (Supabase/PG)  │
       └──────────────────────┤          │           └────────┬────────┘
                              └──────────┘                    │
                                                              │ reads
                                                     ┌────────▼────────┐
                                                     │  Dashboard :5173│
                                                     │  (read-only)    │
                                                     └─────────────────┘
```

**กฎ (per archi-automation-architect):**
- Dashboard คุยกับ Hub เท่านั้น ห้ามเรียก LINE/AI ตรง
- Hub เป็น single source of truth ของ `qc_inspections`
- n8n เป็น orchestrator I/O — ไม่เก็บ state (แค่ temp vars)
- ไม่กระทบ blog→WordPress flow เดิม (แยก webhook path, แยก credential ได้)

---

## 3. Database Schema (Hub / Supabase หรือ Postgres)

```sql
-- ไซต์งาน (ผูกกับ LINE user หรือกรอก caption)
create table sites (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,              -- เช่น BKK-045
  name text not null,
  type text check (type in ('build','renovate','flip')),
  owner text,
  stage text,                              -- foundation/structure/mep/finishing/handover
  created_at timestamptz default now()
);

-- LINE user → role mapping
create table line_users (
  line_id text primary key,
  display_name text,
  role text check (role in ('worker','pm','client','inspector','owner')),
  default_site_id uuid references sites(id),
  created_at timestamptz default now()
);

-- ผล QC แต่ละรูป
create table qc_inspections (
  id uuid primary key default gen_random_uuid(),
  line_message_id text unique not null,    -- idempotency key
  line_user_id text references line_users(line_id),
  site_id uuid references sites(id),
  photo_url text not null,                  -- R2/S3/Supabase storage
  caption text,
  ai_summary text,
  pass boolean,
  severity text check (severity in ('none','low','medium','high','critical')),
  confidence numeric(3,2),                  -- 0.00-1.00
  defects_json jsonb,                       -- structured defect list
  latency_ms int,
  created_at timestamptz default now()
);

-- defect รายรายการ (สำหรับ query / dashboard)
create table qc_defects (
  id uuid primary key default gen_random_uuid(),
  inspection_id uuid references qc_inspections(id) on delete cascade,
  category text,                            -- plaster/electric/plumbing/ceiling/floor/paint/safety
  description text,
  severity text,
  location_hint text,                       -- "มุมขวาบน", "พื้นใกล้ประตู"
  suggested_action text
);

create index on qc_inspections(site_id, created_at desc);
create index on qc_defects(category, severity);
```

**Idempotency:** ใช้ `line_message_id` เป็น unique key — LINE retry webhook ซ้ำ ไม่สร้าง record ซ้ำ

---

## 4. n8n Scenario — `wf_qc_line`

### Nodes (เรียงตามลำดับ)

| # | Node | Type | หน้าที่ |
|---|---|---|---|
| 1 | `Webhook` | Webhook | path `/qc-line`, POST, ตอบ 200 ทันที (LINE timeout 1s) |
| 2 | `Verify Signature` | Function | ตรวจ `x-line-signature` ด้วย channel secret |
| 3 | `Split Events` | Split In Batches | LINE ส่ง events[] หลาย event/request |
| 4 | `Filter Image` | IF | เอาเฉพาะ `message.type === 'image'` |
| 5 | `Get Image Binary` | HTTP Request | `GET https://api-data.line.me/v2/bot/message/{messageId}/content` + Bearer token |
| 6 | `Upload to Storage` | HTTP Request / S3 | PUT ไป R2/Supabase Storage → ได้ public URL |
| 7 | `POST Hub Ingest` | HTTP Request | `POST {HUB}/api/qc/ingest` body: `{line_message_id, line_user_id, photo_url, caption}` |
| 8 | `Wait Hub Result` | (Hub ตอบ sync) | รับ `{pass, severity, ai_summary, defects, dashboard_url}` |
| 9 | `Format Thai Reply` | Function | สร้าง text/flex message จาก Hub response |
| 10 | `LINE Reply` | HTTP Request | `POST https://api.line.me/v2/bot/message/reply` + `replyToken` |
| 11 | `Log Execution` | HTTP Request | `POST {HUB}/api/qc/log-latency` (สำหรับ monitoring) |

### Error branch
- ถ้า step 7–8 > 10s → ส่ง reply "🔍 กำลังตรวจ กรุณารอสักครู่..." ก่อน แล้ว push message ทีหลัง (ต้อง track user_id เพราะ reply_token หมดอายุ 1 นาที)
- ถ้า AI fail → reply "ระบบตรวจไม่สำเร็จ ทีมจะติดต่อกลับ" + สร้าง ticket ใน Hub

---

## 5. Backend Hub — Endpoints ใหม่

### `POST /api/qc/ingest`
**Request:**
```json
{
  "line_message_id": "14353798921116",
  "line_user_id": "U4af49806...",
  "photo_url": "https://r2.archi.co/qc/abc.jpg",
  "caption": "BKK-045 ห้องน้ำชั้น2",
  "timestamp": 1714800000
}
```

**Hub logic:**
1. Upsert `line_users` (display name จาก LINE profile API ถ้ายังไม่มี)
2. Parse caption → หา site_code → lookup site_id (fallback default_site_id)
3. เรียก AI (OpenAI GPT-4o / Claude Sonnet with vision) ด้วย photo_url + prompt ข้อ 6
4. Parse JSON result
5. Insert `qc_inspections` + `qc_defects`
6. Return structured response:

```json
{
  "inspection_id": "…",
  "pass": false,
  "severity": "medium",
  "ai_summary": "พบรอยร้าวเล็กบริเวณมุมฝ้า 2 จุด ฉาบไม่เรียบ",
  "defects": [
    {"category":"ceiling","description":"รอยร้าวลาย","severity":"low","location_hint":"มุมขวาบน","suggested_action":"ฉาบซ่อม + ปาดเรียบ"},
    {"category":"plaster","description":"ผิวไม่เรียบ","severity":"medium","location_hint":"ผนังใต้หน้าต่าง","suggested_action":"ขัดใหม่ก่อนทาสี"}
  ],
  "dashboard_url": "https://dash.archi.co/qc/…"
}
```

### `GET /api/qc/list?site_id=…&from=…&to=…`
สำหรับ Dashboard อ่านประวัติ QC (read-only)

### `POST /api/qc/log-latency`
เก็บ latency ต่อ inspection เพื่อ monitor p95

---

## 6. AI Prompt (ภาษาไทย, JSON-strict)

**System:**
```
คุณคือ QC Inspector งานก่อสร้างและรีโนเวทในไทย ให้วิเคราะห์รูปหน้างาน
หมวดตรวจ: structure, plaster, electric, plumbing, ceiling, floor, paint, safety, cleanliness
severity: none | low | medium | high | critical
ต้องตอบเป็น JSON ตาม schema เท่านั้น ห้ามมี text นอก JSON
ถ้ารูปไม่ใช่งานก่อสร้าง ให้ pass=false severity=none defects=[] ai_summary="รูปไม่ใช่หน้างาน"
```

**User (ต่อภาพ):**
```
Caption จากผู้ส่ง: {caption}
Site stage: {stage}
โปรดตรวจและตอบ JSON:
{
  "pass": bool,
  "severity": "...",
  "confidence": 0.0-1.0,
  "ai_summary": "1-2 ประโยค",
  "defects": [
    {"category":"...","description":"...","severity":"...","location_hint":"...","suggested_action":"..."}
  ]
}
```

**Model:** GPT-4o หรือ Claude Sonnet (vision) — ใช้ structured output / JSON mode

**ค่าประมาณ:** ~฿0.30–฿0.60 ต่อรูป (ที่ GPT-4o ราคา input)

---

## 7. LINE Reply Template (ภาษาไทย, Flex + fallback text)

### Text fallback (สั้น, โทรศัพท์อ่านง่าย)

**กรณี pass:**
```
✅ QC ผ่าน ({site_code})
สรุป: {ai_summary}
ความมั่นใจ: {confidence}%
ดูประวัติ: {dashboard_url}
```

**กรณีไม่ผ่าน:**
```
⚠️ พบจุดต้องแก้ไข ({severity})
{ai_summary}

จุดแก้:
1. {defect[0].description} — {defect[0].suggested_action}
2. {defect[1].description} — {defect[1].suggested_action}
3. {defect[2].description} — {defect[2].suggested_action}

รายละเอียด: {dashboard_url}
```

### Flex Message (แนะนำ — สวยกว่า ดูในมือถือคลีน)
- Header: ✅/⚠️ + site_code + severity tag สี
- Body: รูปย่อ + ai_summary + defect list
- Footer: ปุ่ม "ดูบน Dashboard" + "แจ้งทีม PM"

*(Spec Flex JSON เต็มอยู่ใน `flex_qc.json` ในโฟลเดอร์ n8n workflow — เพิ่มทีหลังตอน build)*

---

## 8. Acceptance Criteria

| # | เกณฑ์ | วัดอย่างไร |
|---|---|---|
| A1 | ส่งรูปเข้า LINE OA → ได้ reply ภายใน 15 วินาที (p95) | `qc_inspections.latency_ms` |
| A2 | AI result persist ใน Hub ภายใน 20 วินาที | timestamp check |
| A3 | Dashboard แสดง inspection ภายใน 30 วินาที | manual smoke test |
| A4 | ส่งรูปเดิมซ้ำ ไม่สร้าง record ซ้ำ | unique `line_message_id` |
| A5 | รูปไม่ใช่หน้างาน → AI ตอบ "ไม่ใช่หน้างาน" ไม่ hallucinate defect | eval 20 รูป off-topic |
| A6 | LINE signature invalid → 401 + log | security test |
| A7 | AI timeout → user ได้ข้อความ "กำลังตรวจ" แทนเงียบ | kill AI แล้วเทส |
| A8 | Dashboard ไม่เรียก LINE/AI ตรง (ตรวจ network tab) | code review |

---

## 9. Debug Checklist (เก็บไว้เวลาพัง)

1. **LINE ไม่ยิง webhook?** → LINE Developer Console > Messaging API > Webhook URL verify + Use webhook = ON
2. **n8n รับไม่ถึง?** → ดู n8n Executions, กรอง workflow `wf_qc_line` — ถ้าไม่มี execution แปลว่า webhook URL ผิด หรือ firewall
3. **Signature fail?** → ตรวจว่าใช้ channel secret ถูก channel (OA มีหลาย channel)
4. **ดึงรูปไม่ได้?** → ใช้ `Messaging API channel access token` ไม่ใช่ LIFF token, endpoint ต้องเป็น `api-data.line.me`
5. **Hub ตอบช้า?** → ดู `/api/qc/ingest` latency breakdown: AI call ปกติคือตัวกินเวลา → ถ้า >8s พิจารณา stream partial หรือ push ทีหลัง
6. **AI JSON parse fail?** → log raw response ใน `qc_inspections.defects_json._raw` — เปิด JSON mode / structured output
7. **Reply token expired?** → reply token มีอายุ 1 นาที ถ้า AI ช้าเกิน ต้องสลับเป็น `push` message (ใช้ user_id)
8. **รูปอัป storage ไม่ขึ้น?** → ตรวจ CORS + signed URL expiry
9. **Dashboard ไม่เห็น inspection?** → Dashboard อ่านจาก `/api/qc/list` เท่านั้น (ไม่ใช่ query DB ตรง) — ตรวจ CORS + auth header
10. **Duplicate ที่ไม่ควร duplicate?** → ตรวจ unique constraint `line_message_id`

---

## 10. Rollout Plan (2–3 สัปดาห์)

**Week 1 — Foundation**
- [ ] สร้าง LINE OA channel (ถ้ายังไม่มี) + เปิด Messaging API
- [ ] DB migration 4 ตาราง + seed sites 5 ไซต์แรก
- [ ] Hub endpoint `/api/qc/ingest` + AI call + persist (ยังไม่มี LINE)
- [ ] Unit test ด้วย curl + รูปทดสอบ 10 รูป

**Week 2 — Integration**
- [ ] n8n workflow `wf_qc_line` ครบ 11 nodes
- [ ] Verify signature + image download + reply text
- [ ] เทสกับทีมภายใน 3 คน, 50 รูปหน้างานจริง
- [ ] ปรับ prompt จนได้ precision ≥80% (eval set 50 รูป labelled)

**Week 3 — Polish + Dashboard**
- [ ] Flex message แทน text
- [ ] Dashboard หน้า QC log + filter ตาม site/contractor
- [ ] Push message fallback เมื่อ AI ช้า
- [ ] Rollout ให้ PM + ช่าง 2 ไซต์ pilot

**Go/No-Go:** เปิดให้ทุกไซต์ก็ต่อเมื่อ A1–A8 ผ่านหมด + precision ≥80%

---

## 11. ข้อควรระวัง

- **Privacy:** รูปหน้างานอาจมีใบหน้าช่าง → เก็บใน bucket private, signed URL, อย่า publish
- **Cost ceiling:** ตั้ง daily cap AI calls (เช่น 500/วัน) ที่ Hub กัน runaway
- **ภาษา:** ช่างบางคน caption เป็นเหนือ/อีสาน/คำเฉพาะ — prompt ต้องเปิด understanding dialect
- **Model drift:** ทุก 2 สัปดาห์ sample 20 inspections มา spot check accuracy
- **อย่าให้ Dashboard ออเดอร์ LINE/AI โดยตรง** — ละเมิดกฎ Hub-centric ใน archi-automation-architect

---

**Next action:** ยืนยัน recommendation ข้อ 1 (n8n + Hub) ก่อน แล้วผมช่วย draft SQL migration + n8n JSON export + Hub endpoint stub ต่อให้ได้
