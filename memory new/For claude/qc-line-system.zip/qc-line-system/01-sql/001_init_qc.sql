-- ============================================================
-- Archi QC LINE System — Initial schema
-- Target: Supabase / Postgres 14+
-- Run in order. Safe to re-run (idempotent where possible).
-- ============================================================

create extension if not exists "pgcrypto";

-- ---------------- sites ----------------
create table if not exists sites (
  id          uuid primary key default gen_random_uuid(),
  code        text unique not null,
  name        text not null,
  type        text check (type in ('build','renovate','flip')),
  owner       text,
  stage       text check (stage in ('foundation','structure','mep','finishing','handover','done')),
  address     text,
  active      boolean default true,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);

create index if not exists idx_sites_code on sites(code);
create index if not exists idx_sites_active on sites(active) where active = true;

-- ---------------- line_users ----------------
create table if not exists line_users (
  line_id          text primary key,
  display_name     text,
  role             text check (role in ('worker','pm','client','inspector','owner')) default 'worker',
  default_site_id  uuid references sites(id) on delete set null,
  phone            text,
  created_at       timestamptz default now(),
  last_seen_at     timestamptz default now()
);

-- ---------------- qc_inspections ----------------
create table if not exists qc_inspections (
  id                uuid primary key default gen_random_uuid(),
  line_message_id   text unique not null,
  line_user_id      text references line_users(line_id) on delete set null,
  site_id           uuid references sites(id) on delete set null,
  photo_url         text not null,
  caption           text,
  ai_summary        text,
  pass              boolean,
  severity          text check (severity in ('none','low','medium','high','critical')),
  confidence        numeric(3,2) check (confidence between 0 and 1),
  defects_json      jsonb default '[]'::jsonb,
  latency_ms        int,
  ai_model          text,
  ai_raw            jsonb,
  status            text check (status in ('queued','processing','done','failed')) default 'queued',
  error_message     text,
  created_at        timestamptz default now()
);

create index if not exists idx_qc_site_created on qc_inspections(site_id, created_at desc);
create index if not exists idx_qc_user_created on qc_inspections(line_user_id, created_at desc);
create index if not exists idx_qc_status       on qc_inspections(status);
create index if not exists idx_qc_severity     on qc_inspections(severity) where severity in ('high','critical');

-- ---------------- qc_defects (normalized for dashboard queries) ----------------
create table if not exists qc_defects (
  id                uuid primary key default gen_random_uuid(),
  inspection_id     uuid not null references qc_inspections(id) on delete cascade,
  category          text check (category in (
                      'structure','plaster','electric','plumbing',
                      'ceiling','floor','paint','safety','cleanliness','other'
                    )),
  description       text not null,
  severity          text check (severity in ('none','low','medium','high','critical')),
  location_hint     text,
  suggested_action  text,
  created_at        timestamptz default now()
);

create index if not exists idx_defects_inspection on qc_defects(inspection_id);
create index if not exists idx_defects_cat_sev    on qc_defects(category, severity);

-- ---------------- daily budget guardrail ----------------
create table if not exists qc_daily_usage (
  day              date primary key default current_date,
  inspections      int default 0,
  ai_tokens_in     int default 0,
  ai_tokens_out    int default 0,
  est_cost_thb     numeric(10,2) default 0
);

-- ---------------- seed example sites (optional — edit before running) ----------------
insert into sites (code, name, type, stage, owner) values
  ('BKK-045', 'บ้านคุณวิชัย ลาดพร้าว 71', 'build',    'structure',  'Archi Build'),
  ('BKK-062', 'รีโนเวทคอนโด The Line', 'renovate', 'finishing',  'Archi Reno'),
  ('NON-018', 'บ้านแฝดนนทบุรี',         'flip',     'finishing',  'Archi Flip')
on conflict (code) do nothing;

-- ---------------- convenience view for dashboard ----------------
create or replace view qc_inspections_view as
select
  i.id,
  i.created_at,
  s.code         as site_code,
  s.name         as site_name,
  s.stage        as site_stage,
  u.display_name as reporter_name,
  u.role         as reporter_role,
  i.photo_url,
  i.caption,
  i.pass,
  i.severity,
  i.confidence,
  i.ai_summary,
  i.latency_ms,
  i.status,
  (select count(*) from qc_defects d where d.inspection_id = i.id) as defect_count
from qc_inspections i
left join sites s      on s.id = i.site_id
left join line_users u on u.line_id = i.line_user_id;

-- ============================================================
-- DONE. Verify with:
--   select count(*) from sites;
--   select count(*) from qc_inspections;
-- ============================================================
