# Memory — Archi (Finnhouses)

## Me
Archi (archida.15@gmail.com) — เจ้าของธุรกิจอสังหาริมทรัพย์ในไทย แบรนด์ Finnhouses  
โบรกเกอร์, renovation-for-resale (Fix & Flip), ที่ปรึกษา/ตรวจสอบงานก่อสร้าง, marketing content
*(รับสร้างบ้านใหม่ — Discontinued ตาม ADR-010, ดู Business Units ด้านล่าง)*

## Platform URLs (จริง)
| Service | URL |
|---------|-----|
| Dashboard (Next.js 15) | ap-home-platform.vercel.app |
| Hub (Express) | ap-home-platform-production.up.railway.app |
| n8n | primary-production-8158a.up.railway.app |
| FB Backend | easygoing-friendship-production-e663.up.railway.app |
| Website | finnhouses.com (WordPress) |

## Stack
Next.js 15 · Vercel · Railway · Supabase · n8n · Telegram

## Modules (ถูกต้อง May 2, 2026)
| Module | Route | หน้าที่ |
|--------|-------|---------|
| OS Dashboard | /dashboard | Live overview — 2 engine cards + Revenue Pipeline |
| CRM | /crm | Lead Kanban 5-stage |
| AI Content | /ai-content | FB content engine — สร้าง post + **FB Queue 7 วัน** |
| Blog Runner | /marketing | n8n pipeline → finnhouses.com WordPress + **Blog Queue 7 วัน** |
| Land Analyzer | /land-analyzer | วิเคราะห์ที่ดิน AI vision |
| Budget Tool | /budget | คำนวณงบ + Lead capture → Telegram |
| QC Line | LINE OA | ช่างส่งรูป → AI Vision → Reply Thai ≤15s |

## การแยก FB Engine vs Blog Runner (สำคัญ)
- **FB Engine** (`/ai-content`) — สร้าง FB post, Content Queue → โพสต์ Facebook Page เท่านั้น
- **Blog Runner** (`/marketing`) — n8n pipeline → publish บทความ WordPress เท่านั้น
- ทั้งสองใช้ Keyword Pool เดียวกันได้ แต่ปลายทางต่างกัน
- **ห้ามปนกัน** — FB Composer / FB state ต้องไม่อยู่ใน Marketing.tsx

## Facebook & Contact Info
- **FB App:** Finnhouses · Token เก็บใน Railway easygoing-friendship env var `FB_PAGE_TOKEN`
- **Permissions:** pages_show_list, business_management, pages_read_engagement, pages_manage_posts
- Token ใส่ใน Railway Variables ของ FB Backend service แล้ว (Apr 27, 2026)
- ⚠️ Token หมดอายุทุก ~60 วัน → generate ใหม่จาก Graph API Explorer → เลือก Page Token → ใส่ Railway easygoing-friendship
- **CTA ที่ใช้:** "ลองดูผลงานที่ finnhouses.com" / "ทักมาปรึกษาเลย 0627946152"
- ❌ ห้ามใช้: "ลิงก์ใน Bio", "ปรึกษาฟรี"

## Architecture (Server-side Proxy Pattern)
ปัญหา CORS: browser ไม่สามารถเรียก Railway โดยตรงได้  
**วิธีแก้:** browser → Vercel API route (server-side) → Railway service → external API

| Vercel Route | ปลายทาง |
|-------------|---------|
| /api/fb/publish | FB Backend /api/fb/publish |
| /api/fb/queue/build | Hub /action/fb/queue/build |
| /api/fb/queue/run-next | Hub /action/fb/queue/run-next |
| /api/fb/queue/clear | Hub /action/fb/queue/clear |
| /api/blog/run | Hub /action/blog/run |
| /api/blog/state | Hub /api/state |
| /api/blog/reset | Hub /action/blog/reset |
| /api/chat | Hub /api/chat |
| /api/image | Hub /api/image |
| /api/blog/queue/build | Hub /action/blog/queue/build |
| /api/blog/queue/run-next | Hub /action/blog/queue/run-next |
| /api/blog/queue/clear | Hub /action/blog/queue/clear |
| /api/market-intel | n8n webhook/market-intel/manual (โดยตรง ไม่ผ่าน Hub) |

## ✅ สถานะ — Deployed (May 2, 2026)

### Deployed — Wave 1 (Apr 28, push-hub-fix.bat + push-ui-fix.bat):
- ✅ `components/AIContent.tsx` — FB Queue tab (📅 Content Queue), CTA ใหม่ finnhouses.com
- ✅ `components/Marketing.tsx` — ลบ FB ทั้งหมดออก, Connection labels = Railway
- ✅ `components/DashboardOS.tsx` — PORT 3001/5678 → Host·Railway, Blog actionLink → /marketing
- ✅ `services/backend-hub/server.cjs` — FB Queue + Blog Queue endpoints
- ✅ `app/api/fb/queue/` — 3 Vercel proxy routes
- ✅ `app/api/blog/queue/` — 3 Vercel proxy routes

### Deployed — Wave 2 (Apr 29, push-fix-fb-engine.bat):
- ✅ `app/api/image/route.ts` — **Image Engine v6**: 2-step prompt gen, 5 style-specific camera/light/shadow/accents, OpenAI any-error → Gemini fallback, buildPromptConcept (~120 words)
- ✅ `components/AIContent.tsx` — `generateImageConcept()` เรียก Claude ก่อน (max 75 tokens), แล้วส่ง concept ไป image API
- ✅ commit `a57fbf9` — pushed แล้ว, Railway Hub redeployed

### Deployed — Wave 4 (May 2, 2026):
- ✅ `components/CRM.tsx` — **Supabase migration complete**: ลบ localStorage ทั้งหมด, fetch/insert/update/delete ผ่าน Supabase, UUID id, `normBudget()` handle "2.5M" + numeric, `lead_date` field ตรง schema
- ✅ `app/budget/page.tsx` — insert full lead fields: stage/source/business_unit/score/style/notes/lead_date + budget เป็น "X.XM" format
- ✅ `components/DashboardOS.tsx` — `useLeadCounts` นับ 5 stages จาก Supabase (new/contacted/proposal/won), pipeline ไม่มี hardcode เหลือ, Traffic แสดง "—" + "no source" badge, bar scale dynamic
- ✅ `app/layout.tsx` + `@vercel/analytics` — Vercel Analytics enabled, `<Analytics />` component ใน layout
- ✅ commit `77fad77` + `16be08e` — pushed + READY บน Vercel

### Deployed — Wave 5 (May 3, 2026):
- ✅ `components/DashboardOS.tsx` — **fix stage mismatch**: `useLeadCounts` แก้จาก `contacted/proposal/won` → `followup/qualified/closed` ให้ตรง CRM stages จริง — Appts/Proposals/Closed แสดงข้อมูลถูกต้องแล้ว
- ✅ `components/Marketing.tsx` — `const HUB` แก้จาก `""` → Railway URL จริง (display เท่านั้น, fetch ใช้ relative path อยู่แล้ว)
- ✅ commit `f72549b` — pushed + Vercel deploying

### CRM Stages (ถูกต้อง May 3, 2026):
| Stage key | Label | Dashboard map |
|-----------|-------|---------------|
| `new` | New Lead | Leads |
| `followup` | Follow Up | Appts |
| `qualified` | Qualified | Proposals |
| `closed` | Closed ✅ | Closed |

### Data Flow (May 3, 2026):
- Budget Tool → submit → Supabase `leads` table (stage="new") + Telegram alert
- CRM Kanban → drag stage → Supabase update realtime
- Dashboard → `useLeadCounts` poll Supabase ทุก 30s → นับ new/followup/qualified/closed แยก
- Vercel Analytics → collect page views ทุก visit (Traffic card: wire ได้หลังมีข้อมูล ~7 วัน)

### Deployed — Wave 3 (May 1, 2026):
- ✅ `app/api/fetch-blog/route.ts` — ดึง `og:image` / `twitter:image` (4 regex patterns) + WP REST API fallback (`/wp-json/wp/v2/posts?slug=...&_embed=1`)
- ✅ `components/AIContent.tsx` — BlogConvertTab: `blogImageUrl` state, image preview (1.91:1), ปุ่ม **Post to Facebook** ส่งรูป + text พร้อมกัน
- ✅ commit `bdf103e` + `50f8cc6` — pushed แล้ว

### Image Engine Architecture (v6 — mirrors n8n):
1. Client → `/api/chat`: Claude generates 2-sentence image concept (75 tokens)
2. Client → `/api/image` with `{concept, style, model:"openai"}`: `buildPromptConcept()` builds ~120-word prompt
3. Server → OpenAI (gpt-image-1 → dall-e-3 fallback) → if ANY error → Gemini fallback
- แต่ละ style มี ARCH + CAM + ACCENT dict แยก (Contemporary, Nordic, Luxury, Minimal, Loft, Tropical Modern)

### Blog → FB Post Feature (May 1):
- วาง URL บทความ finnhouses.com → ดึง text + featured image (og:image)
- แสดง image preview ใน UI → กด "Post to Facebook" → โพสต์รูป + caption พร้อมกันบน FB Page
- FB Backend ใช้ `/photos` endpoint เมื่อมี imageUrl (https://), `/feed` เมื่อไม่มีรูป

### n8n Schedule (อัพเดท May 4, 2026):
- **Wake-up** workflow — Cron `02 9 * * *` = **09:02 ทุกวัน** (ping finnhouses.com + ap-home-platform + FB Backend timeout 30s)
- **Queue Auto-run (FB + Blog)** — Schedule Trigger **09:05 ทุกวัน**
  - Node 1: HTTP POST `ap-home-platform.vercel.app/api/fb/queue/run-next`
  - Node 2: HTTP POST `primary-production-8158a.up.railway.app/webhook/blog-run` ← ยิง n8n โดยตรง (bypass Hub)
- Railway Hub env var `N8N_BLOG_WEBHOOK_URL` = `https://primary-production-8158a.up.railway.app/webhook/blog-run` ← แก้แล้ว May 4
- `TELEGRAM_BOT_TOKEN` อัพเดทแล้ว May 4

### File Structure (May 1, 2026):
- `D:\ARCHI\01_PROJECTS\memory\` — **single source of truth** สำหรับ reference docs ทั้งหมด
  - PPTXs ทุกเวอร์ชัน (v3–v5, Blog_Automation, All_Modules, Review)
  - n8n-workflows/ (4 JSON files)
  - qc-line-system/ + blueprint
  - HANDOFF/SUMMARY docs
  - flowchart v1 + v2 HTML
- `C:\Users\...\Documents\Claude\Projects\AP home OS` — Cowork working dir เท่านั้น (ไม่เก็บไฟล์จริง)

### Deployed — Wave 6 (May 4, 2026) — 3T Marketing Framework:
- ✅ `components/AIContent.tsx` — **3T Framework เพิ่มแล้ว**:
  - `BRAND_FACTS` — เพิ่ม 3T philosophy (Transfer/Trust/Take Care)
  - `KEYWORDS` — เพิ่ม 12 keywords ใหม่แบ่งตาม 3T angle
  - `TONES` — เพิ่ม **"🏠 3T Story"** tone พร้อม instruction
  - `generate()` — `is3T` flag rewires system prompt + prompt structure สำหรับ 3T storytelling
- ✅ Brand Messaging Guide: `memory/Finnhouses_Brand_Messaging_3T.md`
  - Website copy: Headline, Subheadline, About Us (สั้น+ยาว), Services, Trust Signals
  - Facebook Bio: Short (155 chars) + Long Description
  - Hashtag sets แยกตาม 3T angle
  - Tone of voice Do's/Don'ts

### 3T Framework (Finnhouses Brand Strategy — May 4, 2026):
- **ตัดสินใจใช้แบรนด์ Finnhouses เดิม** (ไม่สร้าง Nova Houses) — brand equity มีอยู่แล้ว
- ปรัชญา 3T มาจาก NOVA_HOUSES_Roadmap_2026.pptx → นำมา apply กับ Finnhouses แทน
- **Transfer** = ส่งมอบชัดเจน, Checklist, Weekly Update, BOQ โปร่งใส
- **Trust** = Portfolio จริง, ทีมมืออาชีพ, ราคาไม่มีบวกซ้อน
- **Take Care** = ลูกค้าคือเพื่อน, ดูแลต่อเนื่องหลังส่งมอบ
- Brand Philosophy: "ถ้าลูกค้าคือเพื่อน เราจะสร้างบ้านที่ตอบชีวิตของแต่ละคน"

### WordPress Theme (finnhouses.com):
- **Custom dark luxury theme** — ไม่ใช่ default WordPress theme
- CSS Variables: `--dark`, `--dark-2`, `--dark-3`, `--dark-4`, `--gold`, `--gold-light`, `--gold-pale`, `--gold-border`, `--text`, `--text-muted`
- Font: **Cormorant Garamond** (serif หรูหรา) + **Prompt** (sans-serif Thai) + letter-spacing uppercase labels
- CSS Classes: `.btn`, `.btn--gold`, `.btn--outline`, `.eyebrow`, `.section-pad`, `.container`, `.container--wide`, `.grid-2/3/4`, `.reveal`, `.reveal-delay-1/2/3`, `.divider`, `.section-header`, `.stat-item`, `.review-card`, `.prop-card`
- Theme folder: `D:\ARCHI\01_PROJECTS\CORE\threme web\finnhouses-theme\finnhouses-theme\`
  - `style.css`, `functions.php`, `header.php`, `footer.php`, `front-page.php`, `single.php` (at zffobszw), `single-property.php`, `archive-property.php`, `template-parts/property-card.php`, `assets/js/main.js`
- Phone stored in WP option `finn_phone` (default `062-794-6152`)
- Custom Post Type: `property` + taxonomies: `property_status`, `property_type`, `property_location`
- Helper functions: `finn_price()`, `finn_meta()`, `finn_type()`, `finn_status()`, `finn_location()`

### Deployed — Wave 7 (May 4, 2026) — WordPress front-page.php 3T Rebrand:
- ✅ `front-page.php` — **สร้างใหม่ทั้งหมด** ด้วย 3T Framework ครบ 8 sections:
  1. **Hero** — "สร้างบ้านที่ตอบชีวิตคุณ" + 3T badges (Transfer/Trust/Take Care) + CTA
  2. **Stats Bar** — โครงการ 50+, BOQ โปร่งใส 100%, 4+ ปีประสบการณ์, ดูแล 24/7
  3. **3T Pillars** — 3 cards แต่ละ pillar พร้อม bullet points (dark-2 bg, hover animation)
  4. **Services** — 4 grid: รับสร้างบ้าน / วาง BOQ / ควบคุมงาน QC / ดูแลหลังส่งมอบ
  5. **Process Timeline** — 6 steps: ปรึกษา → ออกแบบ → โครงสร้าง → งานระบบ → QC → ส่งมอบ
  6. **Trust Signals** — 2-col: รูป + checklist 5 ข้อ + brand philosophy quote + CTA
  7. **Portfolio** — ดึง post_type=property ล่าสุด 3 หลัก (fallback placeholder cards)
  8. **Testimonials** — 3 reviews จากลูกค้าสร้างบ้าน (3T-flavored)
  9. **Blog** — ดึงบทความล่าสุด 3 posts (conditional, ไม่แสดงถ้าไม่มี posts)
  10. **CTA Banner** — "ทักมาคุยก่อน" + CTAs ตรง Brand Messaging Guide
- ใช้ CSS variables และ classes จาก style.css ทั้งหมด ไม่เพิ่ม stylesheet ใหม่

### Reference Docs:
- PPTX v4: `D:\ARCHI\01_PROJECTS\memory\Finnhouses_Platform_v4_Apr28.pptx`
- PPTX v5: `D:\ARCHI\01_PROJECTS\memory\Finnhouses_Platform_v5_Apr29.pptx`
- PPTX v6: `D:\ARCHI\01_PROJECTS\memory\Finnhouses_Platform_v6_May2.pptx`
- PPTX v7: `D:\ARCHI\01_PROJECTS\memory\Finnhouses_Platform_v7_May22.pptx`
- PPTX v8: `D:\ARCHI\01_PROJECTS\memory\platform-docs\Finnhouses_Platform_v8_May24.pptx`
- Diagram v2: `D:\ARCHI\01_PROJECTS\memory\finnhouses-platform-flowchart-v2.html`
- Mind Map v3: `D:\ARCHI\01_PROJECTS\memory\platform-docs\finnhouses-mindmap-v3.html`
- **Brand Messaging 3T: `D:\ARCHI\01_PROJECTS\memory\Finnhouses_Brand_Messaging_3T.md`**
- **Nova Houses Roadmap (repurposed): `D:\ARCHI\01_PROJECTS\memory\NOVA_HOUSES_Roadmap_2026.pptx`**
- **Handoff May 24: `memory/HANDOFF_2026-05-24.md`**

## Preferences
- ใช้ภาษาไทยในการสนทนา
- ต้องการคำอธิบาย step-by-step ที่ชัดเจน

### Deployed — Wave 9 (May 21–23, 2026) — Seller Property → Website Pipeline:
- ✅ n8n LINE Seller workflow v4 → Supabase `properties` (status=pending_review) + `line_images` JSONB
- ✅ WP functions.php — `finnhouses/v1/property-intake` REST endpoint + `set_post_thumbnail()` + `finn_gallery` meta
- ✅ Hub: `/action/property/upload-image`, `/action/property/publish`, `/api/properties/pending`, `/action/property/append-line-image`
- ✅ Vercel: `/api/property/upload-image`, `/api/property/publish`, `/api/property/pending`
- ✅ `PropertyReview.tsx` — 4-slot image upload (COVER + 3 gallery), LINE photos auto-fill from Supabase
- ✅ `DashboardOS.tsx` — tab: "📊 Overview" | "🏠 ทรัพย์รอ Review"
- ✅ Upload functions.php ขึ้น WordPress via cPanel — Done May 22
- ✅ Supabase migration — `line_images JSONB DEFAULT '[]'` column added
- ✅ n8n v4 workflow imported — fixes binary chain bug (ลบ Code node กลาง)
- ✅ push-wave9-final.bat — pushed May 23

### Deployed — Wave 10 (May 24, 2026) — WordPress Theme Polish:
- ✅ `single.php` — **Sidebar float layout fix**: เปลี่ยนจาก flex เป็น float-only CSS
  - `.blog-layout aside` → `float:right; width:300px; margin-left:40px;`
  - `.blog-layout article` → `overflow:hidden; min-width:0; width:auto;` (BFC prevents overlap)
  - เหตุผล: `display:flex !important` จาก WP plugins override float บน flex items
- ✅ `single.php` — **Related Posts fallback query**: `orderby=rand` → `date DESC` + fallback WP_Query
  - Primary: category match, orderby date DESC, 3 posts
  - Fallback: ถ้า 0 results → ดึงบทความล่าสุดทั้งหมด (ไม่ filter category)
  - ทุกหน้าการันตีแสดง Related Posts เสมอ
- ✅ `assets/js/main.js` — **Section 9 Image Protection**: contextmenu + dragstart prevention
  - `document.querySelectorAll('img')` → prevent contextmenu + dragstart
  - `MutationObserver` ครอบ dynamic images ที่โหลดทีหลัง
- ✅ `single-property.php` — **Magazine Gallery Layout** (4 variants):
  - 1 image: full-width
  - 2 images: 2-column equal
  - 3 images: 1 large left (3fr) + 2 stacked right (2fr)
  - 4+ images: 1 large left (3fr) + 3 stacked right (2fr), `grid-template-rows:1fr 1fr 1fr`
  - ใช้ `position:absolute;inset:0` inside `.gallery-main` (height:520px, position:relative)
- ✅ อัพโหลดทั้ง 3 ไฟล์ขึ้น cPanel แล้ว
- ℹ️ Property "บ้านรีโนเวทแล้ว" ลบออกจาก WP + Supabase แล้ว
  - เหตุผล: `finn_gallery` มีแค่ 2 IDs → แสดง 3-image layout แทน 4
  - **ต้องทำใหม่**: LINE → n8n → PropertyReview → กรอก COVER + 3 gallery ครบ → Approve

### WordPress Theme Architecture (finnhouses-theme):
- **Theme folder**: `D:\ARCHI\01_PROJECTS\CORE\threme web\finnhouses-theme\finnhouses-theme\`
- **Key files**: `single.php`, `single-property.php`, `front-page.php`, `functions.php`, `style.css`, `assets/js/main.js`
- **Upload method**: cPanel File Manager → `public_html/wp-content/themes/finnhouses-theme/`
- **CSS Layout**: Float-based (ห้ามใช้ flex บน `.blog-layout`) — WP plugin CSS conflict
- **Gallery meta**: `finn_gallery` = array ของ WP attachment IDs → กำหนด layout variant
- **OPcache**: PHP server-side cache — ถ้า PHP ไม่อัพเดทหลังอัพโหลด → รอ 5 นาที หรือ purge cache

### Railway Environment Variables — สถานะจริง (May 29, 2026):

| Service | Variable | ค่า | หมายเหตุ |
|---------|----------|-----|---------|
| Primary (n8n) | `SUPABASE_SERVICE_KEY` | ✅ set แล้ว | copy จาก Hub service |
| Primary (n8n) | `N8N_BLOCK_ENV_ACCESS_IN_NODE` | `false` | ✅ set แล้ว แต่ยังไม่ work — Code node ยังเข้า $env ไม่ได้ |
| Primary (n8n) | `TELEGRAM_CHAT_ID` | ✅ set แล้ว | แต่ n8n node ต้องใช้ hardcode แทน $env |

⚠️ **ข้อจำกัด n8n v2.21.4**: `$env` ใน Code node และ HTTP Request node ถูก block เสมอ แม้ set `N8N_BLOCK_ENV_ACCESS_IN_NODE=false` แล้ว — ต้อง hardcode key ใน Code node โดยตรง

### Deployed — Wave 13 (May 31, 2026) — Phase 1 Stabilize:
- ✅ `components/DashboardOS.tsx` — Market Intel tab endpoint แก้จาก Railway โดยตรง → `/api/market-intel` (Vercel proxy)
- ✅ `app/api/market-intel/route.ts` — forward `timing_signal` + `lat` + `lng` ครบ
- ✅ `components/MarketIntel.tsx` — GPS input เปลี่ยนจากปุ่ม geolocation → manual lat/lng text fields
- ✅ `services/backend-hub/server.cjs` — `withRetry(fn, 2, 4000)` helper + retry FB publish + FB queue run-next + Telegram error alerts 4 จุด
- ✅ n8n Queue Auto-run + WF1 + WF2 — Retry On Fail: 2, Wait: 5000ms set แล้ว
- ✅ Telegram → Market Intel webhook fixed (force re-register via toggle)
- ✅ commits: fix-dashboard-intel, GPS manual input, error logging, retry mechanism

### Platform Data Flow Diagrams (May 31, 2026):
- `memory/platform-docs/finnhouses-platform-dataflow-v1.html` — Layer-based (INPUT/PLATFORM/DATA/OUTPUT)
- `memory/platform-docs/finnhouses-platform-dataflow-v2.html` — Swimlane 5 lanes
- `memory/platform-docs/finnhouses-platform-dataflow-v3.html` — Hub-and-Spoke ✅ (ถูกต้องที่สุด)

### Strategic Roadmap (May 31, 2026):
- **Phase 1** ✅ DONE — Stabilize Core Engine
- **Phase 2** 🟡 NEXT — Build Proprietary Data Advantage (buyer objections, price sensitivity, emotional triggers, district sentiment)
- **Phase 3** 🟢 FUTURE — Intelligence Loop (self-improving, feedback → optimization)

### Deployed — Wave 12 (May 30, 2026) — Market Intel UI:
- ✅ `app/api/market-intel/route.ts` — Vercel proxy → n8n webhook/market-intel/manual
- ✅ `components/AIContent.tsx` — tab 🧠 Market Intel (6th tab) + AREAS constant
- ✅ Dashboard `/dashboard` — Market Intel tab แสดงผลถูกต้อง
- ✅ Supabase area_memory — 4 seed records confirmed
- ✅ `wf_telegram_market_intel.json` — Published แล้ว

### Telegram → Market Intel — สถานะและปัญหา (May 30, 2026):
- **Bot ที่ใช้:** @AIfinnhousesbot (credential n8n: "Telegram account") — bot เดิม ไม่ใช่ bot ใหม่
- **@finnhouses_intel_bot** — ใช้สำหรับ Market Intelligence Collector notifications (Jun 8, 2026)
- **Root cause เดิม:** `WEBHOOK_URL` ใน Railway Primary ตั้งผิดเป็น `https://primary-production-8158a.up.railway.app/webhook/blog-run` → ทำให้ n8n register webhook ผิด path เป็น `blog-run/webhook/finnhouses-telegram-intel-01/webhook` → 404
- **แก้แล้ว:** เปลี่ยน `WEBHOOK_URL` เป็น `https://primary-production-8158a.up.railway.app/` → Redeploy
- **สถานะปัจจุบัน:** webhook URL ถูกต้องแล้ว แต่ยังได้ **403 Forbidden** — สงสัยต้อง Inactive→Active workflow เพื่อ force re-register
- **ยังไม่ได้ทำ:** toggle Inactive→Active ใน n8n workflow Telegram → Market Intel

### Railway n8n Architecture (May 30, 2026):
- **Primary** (n8n main) + **Worker** (n8n worker) + **Postgres** + **Redis** — ทั้งหมด Online
- EXECUTIONS_MODE=queue, N8N_RUNNERS_ENABLED=false, N8N_TRUST_PROXY=true, N8N_PROXY_HOPS=1
- Primary WEBHOOK_URL: `https://primary-production-8158a.up.railway.app/` (แก้แล้ว May 30)
- Worker WEBHOOK_URL: `https://${{Primary.RAILWAY_PUBLIC_DOMAIN}}` (ถูกต้อง)
- ⚠️ ห้ามตั้ง WEBHOOK_URL ให้มี path suffix เช่น /webhook/blog-run — จะทำให้ Telegram Trigger register ผิด

### n8n Market Intelligence Collector — config จริง (Jun 8, 2026) ✅ WORKING:
- Claude URL ใช้: `https://ap-home-platform.vercel.app/api/chat` (ไม่ใช่ Hub)
- Supabase key: hardcode ใน Code nodes ทั้ง 3 (market_insights / buyer_context / content_frames)
- Supabase URL: `https://omvpagvqyfmkkhzuuzda.supabase.co`
- Telegram Chat ID: hardcode `8589960853` ใน Telegram nodes
- Telegram Bot: @finnhouses_intel_bot (credential "Telegram Intel Bot" id: ImDBxePys7cyMDCW)
- Claude Parse model: `claude-haiku-4-5-20251001`
- Claude Generate model: `claude-sonnet-4-6`
- Workflow file: `memory/n8n-workflows/Finnhouses — Market Intelligence Collector v1 (hardcoded).json`
- Webhooks: `market-intel/fb` (FB posts) + `market-intel/manual` (manual input)
- สถานะ: ✅ Published + Tested — flow สมบูรณ์ (parse → 3x Supabase → Claude generate → Telegram)
- ⚠️ `$env` ใน Code node = blocked เสมอใน queue mode — hardcode เท่านั้น

### QC Line — สถานะจริง (May 29, 2026):
- ❌ **ยังไม่ได้สร้าง** — memory เก่าบอกว่า active แต่ไม่จริง

### LINE OA — สถานะจริง (May 29, 2026):
- ✅ LINE OA **ใช้งานอยู่แล้ว** กับ LINE Seller Intake v6 (seller ส่งรูปทรัพย์ → Supabase)
- ⚠️ LINE OA รับ webhook ได้แค่ **1 URL** — ปัจจุบัน LINE Seller Intake ครอบครองอยู่
- ❌ **ยังไม่สามารถต่อ Market Intel เข้า LINE OA ได้โดยตรง** ต้องทำ routing ใน LINE Seller workflow ก่อน
- แนวทาง: เพิ่ม IF node ใน LINE Seller Intake — ถ้าข้อความขึ้นต้นด้วย `intel:` → ส่งต่อ market-intel/manual, ถ้าไม่ → seller flow เดิม

### Deployed — Wave 16 (Jun 7, 2026) — n8n Analytics + CRM Intelligence:

**FB Post Performance Tracker (n8n):**
- ✅ `memory/n8n-workflows/wf_fb_post_performance_tracker.json` — Published ✅
- ดึง FB posts ล่าสุด 25 posts → เปรียบเทียบกับ Supabase `post_performance` → ส่ง Telegram digest รายวัน
- Root cause fix: `alwaysOutputData: true` ต้องอยู่ top-level ของ node (ไม่ใช่ `parameters.options`)
- Telegram: native node `n8n-nodes-base.telegram` + credential `gmqmxxSq3X1Y6Ykr`

**CRM Note Parser — Phase 2 (n8n):**
- ✅ `memory/n8n-workflows/wf_crm_note_parser.json` — Published ✅ (Cron 22:00 ทุกวัน)
- 7 nodes: Schedule → Config → Get Unparsed Leads → Parse with Claude Haiku → Save to Supabase → Build Telegram Message → Send Telegram
- Parse: `trigger_type`, `awareness_level`, `emotional_need`, `content_angle`, `urgency` ← Claude Haiku
- Save: PATCH `leads.intent` + `leads.urgency` + INSERT `buyer_context_signals`
- **n8n Code node rule (confirmed):** ห้าม `fetch()` → ใช้ `this.helpers.httpRequest({body: jsObject, json: true})` เสมอ
- **Telegram rule (confirmed):** ใช้ native Telegram node + credential เสมอ ไม่ทำ HTTP ใน Code node

**Supabase Tables เพิ่ม (Jun 7, 2026):**
- `post_performance` — FB post metrics: post_id, message, created_time, likes, comments, shares, reach
- `buyer_context_signals` — Parsed buyer intelligence: trigger_type, awareness_level, emotional_need, content_angle, urgency, lead_id

### ap-home-system-flow.html (Jun 6, 2026):
- **ไฟล์:** `memory/platform-docs/ap-home-system-flow.html`
- Interactive flow visualizer — แสดงการทำงานของระบบ AP-Home Platform OS แบบ step-by-step
- 3-column layout: App Nav | Feature Settings Panel | SVG Flow Canvas
- Features: Dashboard / CRM / AI Content / Blog Runner / Market Intel / Tools
- **Blog Runner**: dual mode Auto (Cron 09:05) / Manual (user trigger) — step flow แยก
- **AI Content**: 6 tabs — ✨ Keyword, 📝 Blog, 🏠 Listing, 🕓 History, 📋 Queue, 🧠 Intel — แต่ละ tab มี step sequence แยก + panel controls จำลอง UI จริง
- SVG path routing: orthogonal H→V→H (ไม่มีเส้นทแยง) + animated packet travel
- Step bar ล่าง: progress + title + description + play/pause/next controls

### Reference Docs (platform-docs/) — อัพเดทล่าสุด May 29, 2026:
| ไฟล์ | เนื้อหา |
|------|---------|
| `finnhouses-user-manual-v1.html` | **คู่มือการใช้งาน** — ทุก Module + Market Intel + Maintenance + Troubleshoot |
| `finnhouses-platform-flowchart-v3.html` | System Architecture 5 Layers + Data Flows + Status Table |
| `finnhouses-mindmap-v4.html` | Mind Map ทุก branch รวม Intelligence Framework |
| `Finnhouses_Platform_v10_May29.pptx` | Platform Deck 11 slides ล่าสุด |
| `intelligence_schema_migration.sql` | SQL สร้าง 5 Intelligence Tables |

→ รายละเอียดเพิ่มเติม: memory/  
→ Credentials & Token Registry: `memory/tokens.md` — FB token หมดอายุ **~Aug 2, 2026** (renew แล้ว Jun 3)
→ Issues & Fixes Log: `memory/issues-log.md` — บันทึกทุกปัญหาและวิธีแก้ (อัพเดทด้วยทุกครั้ง)
→ Handoff ล่าสุด: `memory/HANDOFF.md`

### Lead Generation Sprint (Jun 1, 2026):
**ปัญหาที่พบ:** FB Page reach เฉลี่ย 1.8 คน/วัน, organic keywords = 0, ไม่มี lead
**Root cause:** โพสต์ผิด channel + content ไม่ใช่ SEO format

**สิ่งที่ทำแล้ว Jun 1:**
- ✅ Content Plan 17 วัน (FB Personal) — `memory/content-plan-june2026.md`
- ✅ FB Post Day 1-10 — Scheduled แล้ว (Personal profile TP Timberland)
- ✅ Blog bridges + CTA 19 ตอน — `memory/blog-bridges-cta.md` (เพิ่มต่อท้ายก่อน publish blog)
- ✅ SEO Articles 5 บทความ — Scheduled ใน WordPress (BOQ / ขั้นตอน / เลือกผู้รับเหมา / ปทุมธานี / 3ล้าน)
- ✅ บทความแรก Live: finnhouses.com/สร้างบ้าน3ล้านได้แค่ไหน/

**ยังต้องทำ:**
- ❌ แก้ 66 broken links ใน Ahrefs (Health Score 13/100)
- ❌ ติดตั้ง Yoast/RankMath ใน WordPress
- ✅ FB Token renew — Done Jun 2, หมดอายุ Jun 26, 2026

**Key insight:** Personal profile (TP Timberland) reach 35x มากกว่า Finnhouses Page — โพสต์จาก personal เสมอ

### Deployed — Wave 14 (Jun 2, 2026) — Phase 1 Complete + Phase 2 Start:

**Bug Fixes:**
- ✅ **WF2 รูปไม่ขึ้น** — root cause: OpenAI Vision API (gpt-4o-mini) rate limit → WF2 crash ที่ "Analyze Roof Vision"
  - Fix: `onError: continueRegularOutput` บน node + Parse Vision QA fallback `{roof_ok:true, style_ok:true, needs_regeneration:false}`
  - WF2 JSON import ใหม่เข้า n8n แล้ว
- ✅ **Telegram "ไม่ส่ง"** — Hub ส่งปกติ ปัญหาคือ message อยู่ใน @AIfinnhousesbot แต่ไม่ได้เปิด

**Security:**
- ✅ **FB Token renew** — easygoing-friendship `FB_PAGE_ACCESS_TOKEN` updated หมด Jun 26
- ✅ **Delete API key** — `archi-onboarding-api-key` deleted จาก console.anthropic.com

**Phase 2 — Buyer Intelligence:**
- ✅ Market Intelligence Memory Form v1 กรอก (2-5 ลูกค้า จากประสบการณ์หลังการขายบ้านจัดสรร)
- ✅ Supabase `buyer_profiles` (build_handsoff) — updated: occupation, family, behavior_tags, conversion_triggers, ghost signal
- ✅ Supabase `area_memory` — 4 records ใหม่: รังสิต, ลำลูกกา, risk signals, after-sales insight
- ✅ Supabase `buyer_context_signals` — 5 records: forced_urgency, career_upgrade, family_proximity, ghost_signal, content_insight
- ✅ `components/AIContent.tsx` — BRAND_FACTS เพิ่ม Buyer Intelligence section:
  - Decision maker = ภรรยา
  - Conversion triggers 4 อัน (forced urgency แรงสุด)
  - Ghost signal: ไม่รับสาย+ไม่ตอบ Line
  - Content ที่ได้ผล/ไม่ได้ผล
  - Trust words: Checklist, QC
- ✅ commit `push-phase2-intelligence.bat` — pushed

### WF2 Architecture (Jun 2, 2026) — สำคัญ:
- **Analyze Roof Vision** node ต้อง `onError: continueRegularOutput` เสมอ (กัน rate limit crash)
- **Parse Vision QA** fallback = `{roof_ok:true, style_ok:true}` (ไม่ใช่ false)
- ถ้าเปลี่ยนกลับ → รูปไม่ขึ้นเมื่อ Vision rate limit

### Deployed — Wave 15 (Jun 5, 2026) — Phase A Security + WF1 Fix:

**Phase A Security (push-phase-a-security.bat):**
- ✅ `next.config.ts` — `allowedOrigins: ["*"]` → `["ap-home-platform.vercel.app", "finnhouses.com"]`
- ✅ 13 Vercel→Hub proxy routes — เพิ่ม `x-hub-token: process.env.HUB_SECRET` ทุก route
- ✅ `app/api/market-intel/route.ts` — hardcoded URL → `process.env.N8N_MARKET_INTEL_WEBHOOK`
- ✅ `components/MarketIntel.tsx` — `/api/market-intel/submit` → `/api/market-intel`
- ✅ Supabase RLS — all 13 tables enabled (applied via MCP, migration: phase_a_rls_fix)
- ✅ 3 stale n8n workflows archived → `memory/archive/n8n/`
- ✅ Vercel env vars: `HUB_SECRET` + `N8N_MARKET_INTEL_WEBHOOK` set แล้ว
- ⏳ Hub deploy (server.cjs updated locally แต่ยังไม่ push Railway)

**n8n WF1 — Blog Runner keyword fix (partial):**
- ✅ Topic Engine PRO — เพิ่ม manual override + category mapping 33/34/35/36
- ❌ Build Schedule Context — ยังต้องแก้ (pass webhook keyword/category ผ่านมา)
  - แก้ตรงใน n8n node: เพิ่ม `keyword/category/runId/visual_hint` จาก `$input.first().json`

### n8n WF1 Architecture (Jun 5, 2026) — สำคัญ:
- WF1 = "Finnhouses WF1 — Article + Publish" (ไม่ใช่ V3.2 FIXED — เลิกใช้แล้ว)
- WF2 = "Finnhouses WF2 — Image + Patch"
- Node flow: Webhook → **Build Schedule Context** → Topic Engine PRO → ...
- **Build Schedule Context ต้อง pass** `keyword`, `category`, `runId`, `visual_hint` จาก webhook เสมอ
- ถ้าไม่ pass → Topic Engine PRO เห็น ctx.keyword = "" → isManual = false → auto-rotation

### บริษัทและ Brand (Jun 5, 2026):
- **บริษัท:** บจก.อาชิดา (Achida Co., Ltd.)
- **Platform:** AP-Home Platform OS
- **Marketing Brand:** Finnhouses (ใช้ที่ website + content เท่านั้น)
- **Vision:** AI-native Human-Centered Real Estate Intelligence Operating System

### Business Units — บจก.อาชิดา (Jun 6, 2026; Unit 1 status corrected 2026-08-08 per ADR-010)

⚠️ **Unit 1 (รับสร้างบ้าน) = DISCONTINUED (ADR-010)** — ยืนยันแล้วโดย Archi (2026-08-08). แถวนี้เก็บไว้เป็น historical record เท่านั้น ห้ามใช้เป็น active business unit ใน content, marketing copy, หรือ platform module ใดๆ อีกต่อไป

| # | หน่วยธุรกิจ | สถานะ | พื้นที่ | กลุ่มลูกค้า |
|---|------------|-------|---------|-------------|
| 1 | รับสร้างบ้าน | ❌ Discontinued (ADR-010) | BKK, นนทบุรี, ปทุมธานี, สมุทรปราการ, นครปฐม | *(historical — เจ้าของที่ดิน, ครอบครัวรายได้สูง, งบ 5M+)* |
| 2 | โบรกเกอร์ฝากขายบ้าน/ที่ดิน | ✅ Active | ปทุมธานี, นนทบุรี | เจ้าของทรัพย์, นักลงทุน |
| 3 | Fix & Flip (รีโนเวทเพื่อขาย) | ✅ Active | ปทุมธานี, นนทบุรี | บริษัทเป็นเจ้าของ inventory เอง |
| 4 | ที่ปรึกษา/ตรวจสอบงานก่อสร้าง | ✅ Active | - | เจ้าของบ้าน, นักลงทุน, ผู้ซื้อใหม่ |

**Active business units คือ 2, 3, 4 เท่านั้น.** Unit 3 (Fix & Flip) = 60% รายได้, Unit 4 (ที่ปรึกษา) = 30%, Unit 2 (โบรกเกอร์) = 10%.

**AP-Home Platform OS — Intelligence Modules:**
- Market Intelligence · Property Intelligence · Construction Intelligence
- Buyer Intelligence · Seller Intelligence · Renovation Intelligence · AI Automation Workflow

**Fix & Flip กลยุทธ์:** ซื้อทรัพย์ที่มีส่วนลดจากราคาตลาด + ศักยภาพเพิ่มมูลค่า + Demand สูง → ใช้ Platform วิเคราะห์ราคา/Demand/กำไร/ความเสี่ยง

**ที่ปรึกษาบริการหลัก:** ตรวจบ้านก่อนโอน, ตรวจงานระหว่างสร้าง, ตรวจรับงานผู้รับเหมา, วิเคราะห์ BOQ, ตรวจคุณภาพวัสดุ
