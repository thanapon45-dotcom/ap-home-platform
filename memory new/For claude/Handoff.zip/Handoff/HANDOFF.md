# HANDOFF — Finnhouses Platform
*อ่านไฟล์นี้ก่อนเริ่ม session ทุกครั้ง — overwrite ทุก session ใหม่*
*Last updated: Jul 13, 2026 (session 24) — รายละเอียดเต็มอยู่ที่ `CORE/ap-home-platform/docs/HANDOFF.md` (canonical ตั้งแต่ Jul 4) ไฟล์นี้เก็บแค่สรุปสั้น*

---

## ⚠️ ล่าสุด (Jul 13, session 24) — Blog Runner ค้าง 11 ชม. → แก้ Publish Guard slug bug + เพิ่ม auto-notify เมื่อบล็อก

**อาการ:** Telegram Health Alert ยิงซ้ำทุก 30 นาทีตั้งแต่ 17:08 น. บอก Blog Runner ค้าง (runId `blog_0134d26d`) — ไล่เช็คจาก Supabase `hub_state` + user เปิด n8n ดู execution เจอว่า WF1 รันสำเร็จจริง (09:00) แต่ไปทาง branch "Blocked Log" เพราะ slug fallback `'post'` (4 ตัวอักษร) สอบตกกฎ Publish Guard ที่ต้องการ ≥6 ตัวอักษรเสมอ — และไม่มี node ไหนแจ้งเตือนกลับ Hub เมื่อโดนบล็อก เลยค้างเงียบ

**แก้แล้ว:** WF1 v8 (`Finnhouses WF1 — Article + Publish (8_slug_guard_fix).json`) — (1) slug fallback ใหม่ที่ผ่าน guard เสมอ (2) เพิ่ม node "Notify Hub Blocked" callback กลับ Hub อัตโนมัติเมื่อโดนบล็อก → import + active แล้วโดย user

**Unblock:** user กด Manual Reset ใน Dashboard (แก้ `state.blog`) + Claude แก้ `content_queue` item ตรงผ่าน Supabase MCP (แก้ `status: running → failed` ให้ตรงความจริง เพราะปุ่ม reset ไม่ sync 2 ที่นี้ให้กัน)

**แก้เพิ่มในเซสชันเดียวกัน (user ขอ):** node "Notify Hub Published" ก็ไม่ส่ง `queue_item_id` เหมือนกัน (ทำให้ item ที่ publish สำเร็จค้างโชว์ "running" ใน Dashboard) → เพิ่ม `queue_item_id` เข้า body ด้วย → ไฟล์ `(9_queue_sync_fix).json` — user import แล้ว + backfill ข้อมูลเก่า 07-11/07-12 เป็น "published" ผ่าน Supabase ตรง

รายละเอียดเต็ม: `docs/issues-log.md` ISSUE-012

---

## ⚠️ ล่าสุด (Jul 8, session 22) — Market Intel Collector v2 (ADR-005) live

Workflow ใหม่ `Finnhouses — Market Intelligence Collector v2 (ADR-005)` (ID `lrLOjW4GPd5atYhz`) เข้าแทนที่ `v1(2)` (ID `F3i4dQMubgbm21d6`, unpublished เก็บไว้ rollback) — webhook path เดิม (`market-intel/fb`, `market-intel/manual`), เพิ่ม 9-signal JSONB schema ต่อโพสต์, เขียนผ่าน native Supabase node แทน Code node เดิม

**Dry run (Stage 1):** เจอ+แก้ 3 บั๊ก — Code node `getCredentials()`/`$env` ใช้ไม่ได้ (n8n bug #29603) → ปรับเป็น native Supabase node; `market_insights.category` CHECK constraint violation → whitelist; `market_insights.confidence` type violation (float vs smallint) → clamp

**Production cutover (Stage 2):** unpublish v1(2) → publish v2 → 15/15 smoke test PASS

**Same-day incident:** โพสต์จริงยาว/ละเอียดเกิน → Claude Haiku ตอบเกิน `maxTokens:1600` → JSON ตัดกลางคำ → fail-safe ทำงานถูกต้อง (ไม่มีข้อมูลผิดบันทึก) แต่โพสต์หาย → แก้เป็น `maxTokens:3000` → verify ผ่านโพสต์จริง 3 รายการติดต่อกัน

รายละเอียดเต็ม: `docs/decisions.md` ADR-005, `docs/issues-log.md` ISSUE-010, `docs/ADR/2026-07-08-market-intel-v2-*.md` (3 ไฟล์: dry run report, cutover report, phase5 proposal)

---

## 🔴 เริ่ม Session ใหม่ — อ่านนี้ก่อน

### สถานะระบบ ณ Jul 2, 2026
- ✅ **content_queue เติมแล้ว 7 รายการ** (Jul 3–9, 1 keyword/category ครบ 7 หมวด) — รอ Queue Auto-run หยิบไปรันวันละ 1 เริ่มพรุ่งนี้เช้า 9:00
- ✅ **Dashboard blog status card แก้เสร็จ + verify แล้ว** — `GET /api/blog/state` คืนข้อมูลจริงจาก Hub v1 (content_queue 7 รายการ, blog/fb status ครบ) — root cause คือ `HUB_SECRET`/`HUB_URL` ใน Vercel เพี้ยนจาก copy-paste เก่า + CDN cache ค้าง response 401 เดิม (ดู issues-log session 19 "Vercel HUB_SECRET Mismatch + CDN Cache")
- 🔴 **ยังไม่ verify ว่า WF1 ยิงจริงหลัง revert Hub v1** (ดู pending #2 ด้านล่าง) — Queue Auto-run "Succeeded" ไม่ได้แปลว่า WF1 ทำงาน ถ้า queue ว่างมันจะ skip เงียบๆ แล้วตอบ 200 เหมือนสำเร็จ (ดู issues-log session 19)
- ✅ **QC LINE ทดสอบจริงผ่านแล้ว** — ขยายรูปอ้างอิงเป็น 14 รูป/7 หมวด + ทดสอบส่งรูปจริง 4 เคสจาก LINE OA ได้ reply ถูกต้อง ≤15s (ดู session 19b ด้านล่าง)
- ✅ **QC feedback loop เพิ่มแล้ว + ทดสอบผ่าน** — ปุ่ม "✅ ตรง / ❌ ไม่ตรง" ต่อท้ายผลตรวจทุกครั้งใน LINE, บันทึกลง `qc_inspections.human_feedback` — workflow `wf_qc_line (2)` active แล้ว (ตัวเก่าปิดเป็น backup) (ดู session 19d ด้านล่าง)
- ✅ **แก้บั๊ก content_frames ไม่เคยบันทึกเลย** — Market Intel "Positioned Content" สร้างข้อความจริงมาตลอด (ส่ง Telegram ทุกครั้งดูเหมือนทำงาน) แต่ column mismatch ทำให้ insert ลง Supabase ล้มเหลวเงียบๆ 100% ตั้งแต่ workflow live (29 พ.ค.) — แก้แล้ว + verify มีแถวจริงในตารางครั้งแรก (ดู session 19e ด้านล่าง)
- 🟡 **Health Check บอก "Blog Queue ว่าง"** วันนี้ (2 ก.ค.) ทั้งที่เพิ่งเติม 7 รายการ (3-9 ก.ค.) — ยังไม่ verify ว่าเป็นปัญหาจริงหรือแค่ timing ของ health check (เช็คก่อนที่ item แรกจะถึงวันที่ 3 ก.ค.)

### สถานะระบบ ณ Jul 1, 2026
| Service | Status | URL |
|---------|--------|-----|
| Hub v1 | ✅ Live (HUB_URL ชี้ v1 อีกครั้ง หลัง revert) | ap-home-platform-production.up.railway.app |
| Hub v2 Shadow | 🟡 Online แต่**ไม่มี** `/api/fb/queue/*`, `/api/blog/queue/*` implement จริง — ห้าม cutover HUB_URL มาที่นี่จนกว่าจะ verify ครบ | exciting-creativity-production-4b85.up.railway.app |
| n8n | ✅ Live — Queue Auto-run verify ผ่านแล้ว (execution #720) | primary-production-8158a.up.railway.app |
| QC Line | ✅ Active | **`wf_qc_line (2)`** — 16 nodes, เพิ่มปุ่ม feedback "✅ ตรง / ❌ ไม่ตรง" (session 19d) — ตัวเก่า `wf_qc_line` (12 nodes) ปิดไว้เป็น backup |
| Dashboard | 🟡 Live แต่ blog status card เพิ่งแก้ auth header — ยังไม่ verify runtime | ap-home-platform.vercel.app |

### Pending ที่ต้องทำต่อ (เรียงตามความสำคัญ)
1. ✅ ~~Verify Dashboard blog status card~~ → **เสร็จแล้ว Jul 2** — verify ผ่าน `web_fetch` ตรง (cache-busted) เห็น content_queue 7 รายการจริง มี debug commit ชั่วคราว `764abf4` ที่ต้อง revert ทิ้ง (ดู pending ใหม่ #1 ด้านล่าง)
2. 🔴 **Revert temp debug code ใน `blog/state/route.ts`** (commit `764abf4`) — เพิ่ม debug field ชั่วคราวเพื่อ diagnose HUB_SECRET mismatch ต้อง revert ก่อนถือว่าเสร็จสมบูรณ์
3. ✅ ~~Import + activate n8n workflow "Content Queue Weekly Builder"~~ — import แล้ว, ทดสอบ Execute workflow ผ่าน (ไป branch "Skip" ถูกต้องเพราะ queue ยังไม่ว่าง) — **แต่มีเวอร์ชันใหม่กว่า (v2) ที่ยังไม่ได้ swap เข้าไป** ดู pending ใหม่ข้อ 4
4. ✅ ~~Swap n8n workflow เป็นเวอร์ชัน 3~~ → **เสร็จแล้ว Jul 2 (session 19c)** — user ลบ v2 แล้ว import `Content Queue Weekly Builder (3).json` สำเร็จ, Execute workflow ทดสอบผ่านทั้ง 2 branch (Blog Queue Empty? → false → Skip, FB Queue Empty? → false → Skip) — Blog branch ยัง auto-refill เหมือนเดิม, FB branch เปลี่ยนเป็นส่ง Telegram แจ้งเตือนอย่างเดียวเมื่อ fb_queue ว่าง (ไม่ auto-build/auto-post แล้ว ตาม requirement ที่ user ยืนยันว่า FB ต้องเป็น manual เสมอ) — **ยังไม่ verify ว่า branch "Notify FB Queue Empty" ทำงานจริงตอน queue ว่างจริง** (วันนี้ทดสอบตอนที่ queue ยังไม่ว่าง เห็นแค่ Skip path)
3. 🔴 **Verify WF1 + WF2 ยังทำงานปกติหลัง Hub v1 revert** → ยังไม่ได้รันเต็ม article ตั้งแต่ revert (`56dab04`) — trigger 1 รอบเต็ม แล้วดู Notify Hub Published เขียว
4. ✅ ~~QC LINE end-to-end test~~ → **เสร็จแล้ว Jul 2** — user ส่งรูปจริงจาก LINE OA 4 เคส (level, plaster, concrete x2) ได้ reply ภาษาไทยครบ ภายในนาทีเดียวกับที่ส่ง (เข้าเกณฑ์ ≤15s) — AI อ้างอิง "cover block" ถูกต้องในเคสคอนกรีตทั้ง 2 เคส (ผ่าน/ไม่ผ่าน) ยืนยันว่ารูปอ้างอิงชุดใหม่ที่เพิ่งอัปโหลด (ดู session 19 ท้ายไฟล์) ถูกใช้งานจริงในการตัดสิน ไม่ใช่แค่นอนในฐานข้อมูล
5. 🔴 **Verify FB token** → Railway easygoing-friendship → ตรวจ FB_PAGE_ACCESS_TOKEN (tokens.md line 97 บอก "หมด Jun 26" ขัดแย้งกับ Aug 2)
6. 🟡 **Enable RLS** → 6 tables: sites, line_users, qc_inspections, qc_defects, qc_standards, qc_daily_usage
7. 🟡 **Security SQL fixes** → REVOKE anon จาก append_line_image_atomic + DROP hub_state anon_update policy
8. 🟡 **Hub v2 fb/blog queue routes** → ต้องสร้างจริงบน Hub v2 backend ก่อนจะลอง migrate อีกครั้ง (ดู issues-log session 18)
9. 🟡 **TASK-503 Monitor 3 Days** → watch Railway logs สำหรับ Hub v2
10. ⚪ **FB Token renew** → หมดอายุ **Aug 2, 2026** (~32 วัน)
11. ⚪ **Market Intel Form** → กรอก section 1.3, 7.1, 8

### Hub v2 Tasks ที่เหลือ (จาก 38 total — 30 done)
- P2 pending: TASK-303 CacheManager (XS), TASK-304 HistoryManager (XS), TASK-313 Property Use Cases (M)
- fb/blog queue routes — ยังไม่ implement เลย (ค้นพบ session 18 — เดิมคิดว่าแค่ path ผิด แต่จริงๆ ไม่มี route)
- Cutover: TASK-601/602/603 (หลัง 3-day monitoring + queue routes เสร็จ)

---

## ✅ Done (Jul 2, 2026) — session 19e — Market Intel: content_frames Silent Failure Fixed

### บริบท
User ถามให้เช็คว่า Market Intelligence tab ส่วน "Positioned Content" ทำงานได้จริงไหม — ตรวจสอบตรงกับ Supabase พบว่า `content_frames` (ตารางเก็บ Facebook post ที่ AI สร้างให้) มี **0 แถวมาตลอด** ตั้งแต่ workflow live (29 พ.ค.) ทั้งที่ `market_insights` มี 27 แถว, `buyer_context_signals` มี 11 แถว — แสดงว่าทุกขั้นตอนก่อนหน้าทำงานปกติ มีแค่ขั้นตอนสุดท้ายที่พัง

### Root cause
Node "💾 Supabase: content_frames" ใน workflow "Finnhouses — Market Intelligence Collector v1" ส่ง field `area`, `timing_signal`, `source_type` ที่**ไม่มีอยู่จริง**ในตาราง `content_frames` (คอลัมน์จริง: `frame_text, frame_type, target_segment, target_context, keyword, tone, channel, ...`) — Supabase/PostgREST reject insert ที่มี unknown column ทุกครั้ง (400 error) แต่โค้ดจับด้วย try/catch ที่แค่ `console.log` เฉยๆ ไม่เคย surface error ไปไหน และ node คืนค่า "saved: true" เสมอไม่ว่าจะสำเร็จหรือไม่ — ทำให้ Telegram แจ้งเตือน "Positioned Content" ดูเหมือนทำงานปกติทุกครั้ง (ข้อความจริงมาจาก Claude ก่อนขั้นตอน save ที่พัง) ทั้งที่ไม่มีอะไรถูกบันทึกเลย

### สิ่งที่ทำ
- ✅ สร้าง `Finnhouses — Market Intelligence Collector v1 (2).json` — แก้ node ให้ map field ให้ตรงคอลัมน์จริง (`area`+`timing_signal`+`source_type` → รวมเป็น string เดียวใน `target_context`)
- ✅ เพิ่ม improvement: Telegram แจ้งเตือนตอนนี้จะบอกด้วยว่า "✅ บันทึกลง content_frames แล้ว" หรือ "⚠️ บันทึกไม่สำเร็จ: [error]" ต่อท้ายทุกข้อความ — กันไม่ให้ silent failure แบบนี้เกิดซ้ำโดยไม่รู้ตัว
- ✅ Deploy ด้วยวิธีเดียวกับ QC (import ใหม่ทั้งอัน → ปิดตัวเก่า → เปิดตัวใหม่) — user ทดสอบ, execution สำเร็จ (21.255s)
- ✅ **Verify ตรงกับ Supabase** — `content_frames` มีแถวแรกในประวัติศาสตร์แล้ว (id=1), คอลัมน์ครบถูกต้อง (`target_context: "ธัญบุรี | source:observation"`, เนื้อหาโพสต์ภาษาไทยจริงจาก Claude)

### ผลกระทบ (ตอนแรก — ก่อนตัดสินใจ backfill)
เนื้อหา Positioned Content ทั้งหมดที่เคยสร้างมาก่อนหน้านี้ (ตั้งแต่ 29 พ.ค.) สูญหายไปแล้ว — มีแค่ในข้อความ Telegram เก่าเท่านั้น กู้คืน**ตัวจริง**ไม่ได้ (ไม่มี raw log อื่นเก็บไว้, ไม่มีสิทธิ์เข้า n8n execution history หรือ Telegram history โดยตรง)

### Backfill: สร้างคอนเทนต์ใหม่แทนของเดิมที่หายไป
User เลือกวิธี "สร้างใหม่จาก insight เดิม (เร็ว)" แทนการพยายามกู้ข้อความจริงจาก Telegram/n8n (ต้องเข้าไปดูทีละ execution เอง)
- ✅ Query `market_insights` ทั้งหมด 27 แถว (id 1-25, 27, 28) ที่ไม่มี `content_frames` คู่กันเลย
- ✅ เขียน Facebook post ใหม่ 26 โพสต์ (ข้ามแถว id=10 confidence=1 "ข้อมูลไม่เพียงพอ" — ไม่มีเนื้อหาจริงให้เขียนถึง) ตามสไตล์/กฎเดียวกับ system prompt ของ workflow (ภาษาพูดธรรมชาติ ≤180 คำ, ตอบ fear/need ของกลุ่มเป้าหมาย, CTA 2 แบบสลับกัน)
- ✅ Insert ผ่าน Supabase MCP `execute_sql` โดยตั้ง `created_at` ให้ตรงกับวันที่ของ `market_insights` เดิม (ไม่ใช่วันนี้) เพื่อให้ timeline ใน Dashboard ถูกต้อง — verify `content_frames` มี 27 แถวรวม (26 backfill + 1 จาก test จริงวันนี้), ช่วงวันที่ 29 พ.ค. – 2 ก.ค.
- ⚠️ **ข้อควรรู้**: นี่คือคอนเทนต์ที่เขียนใหม่ให้ตรงกับ insight เดิม **ไม่ใช่ข้อความต้นฉบับที่ AI เคยสร้างจริงในตอนนั้น** (ของจริงหายไปแล้ว) — ถ้าต้องการข้อความต้นฉบับ ต้องไปเปิดดู Telegram chat ย้อนหลังเอง (bot "Telegram Intel Bot" คุยกับ chat_id 8589960853) ซึ่ง Claude ไม่มีสิทธิ์เข้าถึงโดยตรง

### ไฟล์ที่แก้
- `memory/n8n-workflows/Finnhouses — Market Intelligence Collector v1 (2).json` — เก็บไว้อ้างอิง

---

## ✅ Done (Jul 2, 2026) — session 19d — QC Feedback Loop (ปุ่ม "✅ ตรง / ❌ ไม่ตรง")

### บริบท
User ถามว่าจะพัฒนาแพลตฟอร์มไปสู่วิสัยทัศน์ "AI-native Human-Centered Real Estate Intelligence Operating System" ยังไง — พบว่าระบบไม่มีจุดไหนเก็บ feedback ว่า AI ตัดสินถูกหรือผิดเลย (generate อย่างเดียว ไม่เคยเรียนรู้) เลือก QC Line เป็นจุดเริ่มต้น เพราะเพิ่งทดสอบผ่านจริงวันเดียวกัน (session 19b) และ "ถูก/ผิด" ตัดสินได้ตรงไปตรงมากว่า content — ดู decisions.md

### สิ่งที่ทำ
- ✅ Supabase: เพิ่มคอลัมน์ `human_feedback` (`correct`\|`incorrect`) + `human_feedback_at` ใน `qc_inspections` (migration `add_qc_human_feedback_columns`)
- ✅ `server.cjs`: เพิ่ม `POST /api/qc/feedback` — รับ `{line_message_id, feedback}`, หา inspection ที่ตรงกัน, เขียนค่า feedback — deploy ผ่าน git push → Railway auto-deploy (verify ผ่าน `/health` uptime reset)
- ✅ n8n `wf_qc_line (2)`: แก้ node "LINE Reply API" ให้แนบ Quick Reply 2 ปุ่ม (postback) ต่อท้ายทุกข้อความผลตรวจ + เพิ่ม branch ใหม่ 4 nodes (Is Feedback Postback? → Parse Feedback Postback → POST Hub /api/qc/feedback → Reply Feedback Thanks) รับปุ่มที่กด แล้วตอบขอบคุณกลับ
- ✅ Deploy วิธีง่าย: import `wf_qc_line (2).json` เป็น workflow ใหม่ทั้งอัน แล้ว **ปิด workflow เก่า + เปิดตัวใหม่** (สลับ active) แทนการตัดต่อ node ใน workflow เดิม — ตัวเก่าเก็บไว้เป็น backup ปิดอยู่ ไม่ลบ
- 🔴→✅ เจอบั๊กระหว่างทดสอบจริง: `URLSearchParams is not defined` ใน node "Parse Feedback Postback" — n8n Code node sandbox ไม่มี global นี้ — แก้เป็น parse string เองด้วย `.split('&')`/`.split('=')` (ดู issues-log.md, CLAUDE.md Known Bugs #7)
- ✅ **User ทดสอบจริงผ่านแล้ว** — ส่งรูป, เห็นปุ่มทั้งสอง, กดปุ่ม, ได้ reply "ขอบคุณครับ" กลับมา

### ยังไม่ทำ (ตั้งใจ — scope แค่เก็บข้อมูลดิบก่อน)
- ไม่มี dashboard/query สรุป % ความแม่นยำสะสมของ AI จาก `human_feedback` — ต้องมาทำทีหลังเมื่อมีข้อมูลสะสมพอ
- ไม่ auto-retrain หรือปรับ prompt อัตโนมัติจาก feedback — เป็นงาน manual ในอนาคต (ดูรูปแบบเดียวกับที่ทำกับ qc_standards session 19b — คนต้องอ่านแล้วตัดสินใจเอง)
- Market Intel feedback loop (candidate ที่ 2) — ยังไม่ได้เริ่ม

### ไฟล์ที่แก้
- `services/backend-hub/server.cjs` — endpoint ใหม่ (commit `b24f132`)
- `memory/n8n-workflows/wf_qc_line (2).json` — เก็บไว้อ้างอิง (โค้ดใน node ตรงกับที่ deploy จริงใน n8n หลังแก้บั๊ก URLSearchParams)

---

## ✅ Done (Jul 2, 2026) — session 19b — QC Standards Reference Photos + End-to-End Test PASS

### ขยายรูปอ้างอิง QC จาก 4 หมวด (1 รูป/หมวด) เป็น 7 หมวด (14 รูปรวม)
- ✅ เจอเอกสาร QC จริงของ Finnhouses ใน `D:\Finnhouses brand\Check list\` — `02 QC List Revise02 2018.xlsx` (เช็คลิสต์จริง 4 แบรนด์บ้าน มีเกณฑ์ตัวเลข เช่น คอนกรีต ≥200 ksc, คาน L/360, ท่อน้ำ 100 psi) และ `inspect โครงสร้าง.pdf` (checklist โครงสร้างก่อนเทคอนกรีต)
- ✅ คัดรูปจริงจากไซต์ Finnhouses 10 รูป เพิ่มหมวด electrical, plumbing, finishing ที่ไม่เคยมีรูปอ้างอิงเลย + เพิ่มรูปให้ concrete/plaster/level/paint ที่เดิมมีแค่ 1 รูป
- 🔴 **พบ + แก้ DB constraint** — ตาราง `qc_standards` เดิมมี `UNIQUE(category)` จำกัดไว้แค่ 1 รูป/หมวด ขัดกับ design ที่โค้ดรองรับหลายรูป — แก้เป็น `UNIQUE(category, photo_url)` ผ่าน Supabase MCP `apply_migration`
- ✅ insert 10 แถวใหม่ผ่าน Supabase MCP `execute_sql` — verify ด้วย `storage.objects` query ว่าไฟล์จริงตรงกับที่ตั้งใจ (เจอบั๊กเล็กน้อยระหว่างทาง: `paint/ref2.jpg` ชี้ path ซ้ำกับ `ref1.jpg` โดยไม่ตั้งใจ — แก้ด้วยสคริปต์ `fix-paint-ref2.ps1` แยก)
- ⚠️ **บั๊ก PowerShell + Thai path**: สคริปต์ `.ps1` ที่มีอักษรไทยใน string literal (path) ต้องมี **UTF-8 BOM** ที่ต้นไฟล์ ไม่งั้น Windows PowerShell 5.1 (`powershell.exe`) จะอ่านผิด encoding แล้ว parse error ทั้งไฟล์ (เขียนไฟล์ด้วย Write tool ได้ UTF-8 ไม่มี BOM โดย default — ต้อง prepend `\xEF\xBB\xBF` เอง)
- ยังไม่มีรูปอ้างอิงเลย: **structure** (โครงสร้าง — มีแต่ PDF checklist ข้อความ, ไม่มีรูป), **cleanliness** (ความสะอาดหน้างาน — ไม่มีแหล่งข้อมูลเลย ต้องถ่ายใหม่)
- ไฟล์: `_scripts/upload-qc-standards-v2.ps1`, `_scripts/fix-paint-ref2.ps1`

### QC LINE end-to-end test — PASS (ครั้งแรกที่ทดสอบจริงตั้งแต่สร้างระบบ)
- ✅ user ส่งรูปจริง 4 เคสจาก LINE OA ผ่าน Telegram bot `finnhousesAI` — ได้ reply ภาษาไทยครบทุกเคส ภายในนาทีเดียวกับที่ส่ง (เข้าเกณฑ์ ≤15s)
- ✅ **ยืนยันรูปอ้างอิงใหม่ถูกใช้งานจริง** — 2 เคสคอนกรีตก่อนเท AI พูดถึง "cover block" ตรงกับ description ที่เพิ่งใส่ในรอบนี้ (เคสหนึ่ง "มี cover block รองรับ" ผ่าน, อีกเคส "ไม่มี cover block รองรับ" ไม่ผ่าน severity high)
- ✅ output ครบ schema: severity แยกถูก (สายไฟพาดเหล็ก=low, ไม่มี cover block=high), suggested_action ทำได้จริง, confidence score (95%)
- **สถานะ**: ปิดงาน pending "QC LINE end-to-end test" แล้ว

---

## ✅ Done (Jul 2, 2026) — session 19 — Queue Empty Root Cause + PowerShell UTF-8 Bug

### content_queue ว่างเปล่า → Queue Auto-run "Succeeded" หลอกทุกวัน
- ✅ **Root cause พบ** — `GET /api/state` (ไม่ใช่ `/api/health/state` ตามที่ CLAUDE.md เขียนผิด — แก้แล้ว) แสดง `content_queue: {}` ว่างเปล่ามาตั้งแต่ Jun 30 — บทความล่าสุดที่เสร็จสมบูรณ์คือ Jun 29 08:20
- ✅ **สาเหตุที่ n8n ขึ้นเขียวทุกวัน** — `server.cjs:1352` `/action/blog/queue/run-next` คืน `{ok:true, skipped:true, message:"Queue is empty"}` (HTTP 200) เมื่อ queue ว่าง — n8n เห็นแค่ 200 เลยขึ้น Succeeded ทั้งที่ไม่ได้ trigger อะไรจริง
- ✅ **เติม queue แล้ว 7 รายการ** (Jul 3–9) — สุ่ม 1 keyword จากทุก category pool (10/12/13/33/34/35/36) ผ่าน `/action/blog/queue/build`

### PowerShell `Invoke-RestMethod` ส่งภาษาไทยเพี้ยนเป็น `?????`
- ✅ **พบบั๊ก** — `Invoke-RestMethod -Body $jsonString` (string ธรรมดา) เข้ารหัส body ผิด (ไม่ใช่ UTF-8) → ตัวอักษรไทยกลายเป็น `?` ทุกตัวตั้งแต่ตอนส่ง (verify แล้วว่าเพี้ยนจริงในข้อมูลที่ server เก็บ ไม่ใช่แค่ console แสดงผล)
- ✅ **Fix** — บังคับ `[System.Text.Encoding]::UTF8.GetBytes($jsonString)` แล้วส่งเป็น byte array แทน string + เพิ่ม `-ContentType "application/json; charset=utf-8"` — verify แล้วภาษาไทยถูกต้อง
- **กฎใหม่:** ทุกครั้งที่ `Invoke-RestMethod -Body` มีภาษาไทย ต้อง `GetBytes()` เสมอ ห้ามส่ง string ตรงๆ

**Pending ต่อ (Jul 3, 09:00):** ตรวจว่า Queue Auto-run หยิบ item แรก (แบบบ้าน, category 13) ไปสร้าง run จริง และ WF1 execution ใหม่ปรากฏใน n8n (ล่าสุดค้างที่ Jun 30 20:49 มา 3 วันแล้ว)

### Dashboard `/api/blog/state` 401 → Vercel env var mismatch + CDN cache
- ✅ **Root cause #1** — `HUB_SECRET` ใน Vercel มีค่าผิด (placeholder เก่า `sk_live_a12...` ไม่เกี่ยวกับ Hub เลย) — แก้โดยลบ+สร้างใหม่ผ่าน "Add Environment Variable" (ไม่ใช่แก้ในช่อง Edit เดิม เพราะพบว่า field เก่า mask ค่าและ edit-in-place ไม่ทำงานเสมอ)
- ✅ **Root cause #2** — `HUB_URL` ก็ผิดเช่นกัน (คาดว่าค้างเป็น Hub v2 URL) — ลบ+สร้างใหม่เป็น `https://ap-home-platform-production.up.railway.app`
- ✅ **Root cause #3 (ตัวที่ทำให้งงนานสุด)** — แม้แก้ env var + redeploy หลายรอบแล้ว ยังเห็น 401 เดิมซ้ำๆ ทุกครั้ง → เพิ่ม temp debug field ใน `blog/state/route.ts` (commit `764abf4`) เพื่อ echo HUB_URL/HUB_SECRET metadata กลับมา → พบว่า response ที่เห็นเป็น **CDN cache เก่าค้างอยู่** ไม่ใช่ response จริงจาก serverless function รอบล่าสุด — พอเรียกด้วย query param กัน cache (`?cachebust=...`) เห็นข้อมูลจริงทันที (content_queue 7 รายการครบ)
- **บทเรียน:** เวลา debug 401/error ที่ค้างซ้ำๆ ไม่ยอมหายหลัง fix+redeploy — ให้สงสัย CDN/edge cache ก่อน อย่าเสียเวลาลองแก้ env var ซ้ำไปเรื่อยๆ ลอง cache-busting query param เป็นขั้นแรกๆ ของการ diagnose
- 🔴 **ค้างอยู่:** ต้อง revert commit `764abf4` (ลบ temp debug code ออกจาก `blog/state/route.ts`) — ยังไม่ทำในเซสชันนี้

---

## ✅ Done (Jul 1, 2026) — session 18 — Hub v1/v2 Revert + Git Hygiene Audit

### FB Queue 404 → traced to premature Hub v2 cutover
- ✅ Root cause: `blog/queue/*` แก้เป็น Hub v2 convention (Jun 30) แต่ `fb/queue/*` ตกหล่น + `HUB_URL` ถูกสลับไป v2 ทั้งระบบก่อน v2 จะมี route พวกนี้จริง
- ✅ Revert ทั้ง 6 queue route files + `HUB_URL` กลับ Hub v1 — verified ผ่าน n8n execution #720 (ทั้ง 2 nodes เขียว, 1.6s)
- ✅ พบ + แก้ `.gitignore` bug: `build/` (ไม่ anchor) บัง `app/api/fb/queue/build/route.ts` มาตั้งแต่สร้าง — เปลี่ยนเป็น `/build/`
- รายละเอียดเต็ม: `issues-log.md` session 18, `decisions.md` "Hub v2 Migration + Git Hygiene"

### GitHub sync audit (ตอบคำถาม "ไฟล์ใดไม่อัพเดท")
- ✅ พบ `docs/ADR/0000-template.md` + 6 ไฟล์ `docs/hub-v2/*` — untracked มาตลอด ทั้งที่ `AI_TEAM.md` reference ตรงๆ → push แล้ว (commit `e3b7007`)
- ✅ Full-repo grep audit (`x-hub-token` vs `x-hub-secret` ทั้ง `app/api/`) → พบ `blog/state/route.ts` ตกหล่นจาก revert รอบแรก ยังส่ง `x-hub-secret` → แก้แล้ว (commit `56ab7f5`)
- ✅ ยืนยัน: ไม่มีไฟล์อื่นใน repo ใช้ header/path convention ผิดแล้ว (audit ครบทุก route ที่เรียก `HUB_URL`)
- 🔴 **ยังไม่ verify runtime** — โค้ดสม่ำเสมอแล้ว แต่ยังไม่ได้ trigger จริงทุก module (ดู pending list ด้านบน)

---

## ✅ Done (Jun 29, 2026) — session 17 — Context Loader

### สร้าง Context Loader
- ✅ **`memory/context_loader.py`** — Python script generate context brief จาก memory files อัตโนมัติ
  - อ่าน HANDOFF.md → extract status table + pending tasks (skip struck-through)
  - อ่าน issues-log.md → extract open issues top 3 (เฉพาะที่ไม่มี ✅)
  - อ่าน glossary.md → extract tables ทั้งหมด (Platform Modules, Technical Terms, n8n Workflows)
  - Hard rules 10 ข้อ built-in
  - Output: `_context_brief.md` (~10,000 chars)
- ✅ **`memory/_context_brief.md`** — generated แล้ว พร้อมใช้
- **วิธีใช้:** รัน `python context_loader.py` ก่อนเริ่ม session หรือหลัง "ปิดงาน"
- **Session commands:** พิมพ์ "ปิดงาน" → Claude update memory + รัน loader | พิมพ์ "เริ่มงาน" → Claude อ่าน _context_brief.md

---

## ✅ Done (Jun 29, 2026) — session 16 — WF1 Callback Fix

### WF1 "Notify Hub Published" callback fix
- ✅ **Root cause found** → n8n Webhook node v2.1 wraps POST body ไว้ใน `.body` key — ทำให้ `$input.first().json.hub_callback_url` = `undefined` เสมอ
- ✅ **Fix: `Build Schedule Context`** → เปลี่ยนอ่าน field ทุกตัวผ่าน `wb = $input.first().json.body || $input.first().json` (รองรับทั้ง v1 และ v2.1)
- ✅ **Fix: `Notify Hub Published`** → URL = `$node['Build Schedule Context'].json.hub_callback_url`, body runId = `$node['Build Schedule Context'].json.runId` (ไม่มี auth — token อยู่ใน URL แล้ว)
- 🔴 **ยังรอ verify** → ไฟล์ `(8_wb_fix).json` สร้างแล้ว แต่ยังไม่ได้ import และ test จริง
- **ไฟล์:** `memory/n8n-workflows/Finnhouses WF1 — Article + Publish (8_wb_fix).json`
- **Journey:** v5(wrong expr) → v6(undefined→empty) → v7(debug+body fallback→401) → v8(wb pattern, รอ test)

### Bug ที่ค้นพบเพิ่ม (ผลพลอยได้จากการ debug)
- **category ผิดตลอด**: WF1 ใช้ category 13 (fallback) แทน 12 ที่ Hub ส่งมา — เพราะ Webhook body wrapping ทำให้ทุก field เป็น undefined จนถึงวันนี้
- **keyword ผิดตลอด**: Build Schedule Context ได้ `keyword=''` แล้ว Topic Engine PRO gen ใหม่เอง — บทความออกปกติแต่ไม่ใช่ keyword ที่ user เลือก

---

## ✅ Done (Jun 29, 2026) — session 15 — System Audit

### Full System Audit (4 Areas)
- ✅ **Audit Report** → `memory/Audit/audit_2026-06-29.md`
- ✅ **n8n Live Export ตรวจสอบ** → WF1 keyword fix อยู่ใน live แล้ว ✅, QC LINE v8 active แล้ว ✅, WF2 fixed JSON สร้างพร้อม import
- ✅ **Area 1 n8n Workflows** → พบ 1 critical: WF2 Notify Hub headers missing (→ 401); WF1 ✅ already fixed; QC v8 ✅ already active
- ✅ **Area 2 Auth & Secrets** → tokens.md Jun 26 vs Aug 2 contradiction; market-intel/insights unauthenticated + service key
- ✅ **Area 3 Supabase RLS** → 6 tables RLS disabled (sites, line_users, qc_*); anon callable SECURITY DEFINER function; hub_state anon_update too permissive
- ✅ **Area 4 Production** → WF2→Hub notification broken; Hub v2 smoke/monitor pending
- ✅ **HANDOFF updated** → pending list reordered with new findings

---

## ✅ Done (Jun 28, 2026) — session 14 — AI_TEAM.md Governance

### สร้าง AI_TEAM.md v1.0.0
- ✅ **`docs/AI_TEAM.md`** — Engineering Constitution 9 sections จาก docx brief ของ Archi
  - Team Roles (PO/CTO/Lead Engineer), Architecture Principles, Engineering Principles
  - AI Collaboration Workflow (Mermaid), PR Checklist, Decision Rules, Repository Rules, Future Vision
  - Current System State table สะท้อน Hub v2 79% + QC Line LIVE

### อัพเดท AI_TEAM.md v1.1.0 (Architecture Governor revision)
- ✅ **A1** — Document metadata table (Version 1.1.0, Status, Owner, Review Cycle 90 days)
- ✅ **A2** — Section 4.1 Knowledge Principles (7 หลักการ + อธิบาย why Knowledge OS เป็น first-class)
- ✅ **A3** — Section 4.2 AI Provider Policy (routing table: Claude→Reasoning, GPT→Vision, Gemini→Translation + rule ห้าม hardcode provider)
- ✅ **A4** — PR Checklist เพิ่ม 4 items (Performance, AI Cost, Breaking change, Backward compatibility)
- ✅ **A5** — ADR Mandatory Triggers table (7 categories: Architecture, AI Provider, Database, Auth, Event Model, Security, Public API)
- ✅ **B1** — สร้าง `docs/ADR/0000-template.md` (Context/Decision/Alternatives/Consequences/References)
- ✅ **B2** — Engineering North Star statement ที่ end ของ doc
- ✅ **B3** — Section 9 Observability Principles (Metrics/Tracing/Audit/AI Cost/Performance/Monitoring)
- ✅ **B4** — Section 10 Service Registry Principle (table + rule)
- ✅ **C** — Section 11 Future Architecture (Priority C — document only, Knowledge OS/Agent Layer/Executive Intel/Self-Improving Loop)
- ✅ Version footer → v1.1.0, next review Sep 28, 2026

### อัพเดท HTML files ทั้งหมด (9 ไฟล์ — session 14)
- ✅ `memory/ap_home_platform_os_map.html` — Hub v2 progress (30/38, 79%), HealthMonitor 5min, QC calibration, Pending section
- ✅ `memory/achida_intelligence_loop_roadmap.html` — QC Line badge=done, Jun 28
- ✅ `memory/platform-docs/ap-home-architecture.html` — v1 LIVE · v2 SHADOW badge, Hub v2 detail
- ✅ 6 other platform-docs HTML files — date + Hub v2 + QC Line status

---

## ✅ Done Today (Jun 6, 2026) — session 5
- ✅ **ap-home-system-flow.html** — สร้าง System Flow Visualizer (interactive) ใน `memory/platform-docs/`
  - 3-column layout: App Nav (left) | Feature Settings Panel (center) | SVG Flow Canvas (right)
  - Step-bar bottom: progress bar + step title/description + play controls
  - **Blog Runner** — dual mode: 🔄 Auto (n8n Cron 09:05) / ✋ Manual (user trigger), แต่ละ mode มี step flow แยก
  - **AI Content** — 6 tabs (✨ Keyword / 📝 Blog / 🏠 Listing / 🕓 History / 📋 Queue / 🧠 Intel) แต่ละ tab มี step array + panel HTML แยกกันสมบูรณ์
  - **AIC_TAB_STEPS**: keyword 14 steps (Image Engine v6 + fallback chain), blog 8 steps, listing 8 steps, history 4 steps, queue 6 steps, intel 5 steps
  - **Orthogonal routing**: เปลี่ยนจาก Bezier diagonal → H→V→H 3-segment path พร้อม rounded corners ไม่มีเส้นลากข้ามหน้าจอ
  - fb_back node มี flow step ถูกต้อง: hub→fb_back→facebook

### ✅ Done Today (Jun 6, 2026) — session 4
- ✅ **S-10 FB Backend Auth** — `server.js` auth middleware + Hub ส่ง `x-hub-token` 2 จุด + Railway `easygoing-friendship` ตั้ง `HUB_SECRET` — commit `1a43fd2`
- ✅ **S-07 leads allow_all** — DROP POLICY ผ่าน Supabase MCP — เหลือแค่ anon INSERT + SELECT
- ✅ **S-05 fb_sellers/fb_listings/fb_listing_history** — RLS enabled + anon_insert policy ถูกต้องแล้ว (verified จาก Supabase)
- ✅ **Build Schedule Context** — แก้ใน n8n WF1 แล้ว (คุณแก้ตรงใน n8n)
- ✅ **S-08 n8n key scan** — scan 8 files + archive, sanitize `FB Market Intelligence — Sheet to Supabase (2).json` (keys → REDACTED)
- ✅ **Phase A Security push** — 13 proxy routes + next.config.ts + MarketIntel.tsx + delete server.js — commit `ca5d467`
- ✅ **Group B Intelligence Tables** — สร้าง 6 tables ใหม่: hub_state, hub_queue, construction_records, reno_deals, defect_log, seller_profiles (migration: phase_b_intelligence_tables)

---

### ✅ Done (Jun 7, 2026) — session 6
- ✅ **ทดสอบ Blog Runner** — Topic Engine PRO `is_manual_run: true` ✅ (confirmed by user)
- ✅ **Delete server.js** — ยืนยันแล้วว่า commit `ca5d467` ลบไปแล้ว (`D services/backend-hub/server.js`)
- ✅ **push-fix-blog-categories.bat** — ยืนยันแล้วว่า commit `9cfadf7` deployed แล้ว
- ✅ **push-fix-bizcards.bat** — ยืนยันแล้วว่า commit `fb63896` deployed แล้ว
- ✅ **WF2 Hub auth fix** — เพิ่ม `x-hub-token` header ใน 3 nodes: Notify Hub Image Done / Notify Hub Image Failed / Notify Hub Binary Failed (แก้ตรงใน n8n)

### ✅ Done (Jun 7, 2026) — session 7
- ✅ **FB Post Performance Tracker** — n8n workflow fixed + Published + Telegram ทำงาน ✅
  - Root cause: `alwaysOutputData: true` ต้องอยู่ top-level ของ node object (ไม่ใช่ใน `parameters.options`)
  - File: `memory/n8n-workflows/wf_fb_post_performance_tracker.json`
- ✅ **Phase 2 — CRM Note Parser** — n8n workflow built + Published + Telegram ทำงาน ✅
  - 7 nodes: Schedule (22:00) → Config → Get Unparsed Leads → Parse with Claude Haiku → Save to Supabase → Build Telegram Message → Send Telegram
  - Parse: Claude Haiku → trigger_type / awareness_level / emotional_need / content_angle / urgency
  - Save: PATCH leads.intent + leads.urgency + INSERT buyer_context_signals
  - File: `memory/n8n-workflows/wf_crm_note_parser.json`
  - Bugs fixed: Invalid cron → `0 22 * * *` · `fetch not defined` → `this.helpers.httpRequest()` · 401 Telegram → native Telegram node (credential `gmqmxxSq3X1Y6Ykr`)

### ✅ Done (Jun 8, 2026) — session 8
- ✅ **Market Intelligence Collector v1** — workflow ทำงาน end-to-end แล้ว 🎉
  - Root cause: `EXECUTIONS_MODE=queue` → Code nodes รันบน Worker (Railway container แยก) → `$env` block เสมอ
  - Fix: hardcode `SUPABASE_SERVICE_KEY` โดยตรงใน 3 Code nodes (market_insights / buyer_context / content_frames)
  - File: `memory/n8n-workflows/Finnhouses — Market Intelligence Collector v1 (hardcoded).json`
  - Telegram bot: @finnhouses_intel_bot (chatId: 8589960853) — ต้อง /start ก่อน 1 ครั้ง
  - Flow confirmed: FB/Manual webhook → Parse → Supabase (3 tables) → Claude generate → Telegram ✅

### ✅ Done (Jun 11, 2026) — session 9 — Ahrefs 404 Fix
- ✅ **Ahrefs 404 fix** — แก้ครบ 5 URL จาก Ahrefs crawl Jun 11, 2026
  - **2 blog post 404s** → `.htaccess` RedirectMatch 301 วางใน cPanel ก่อน `# BEGIN WordPress`:
    - `/สร้างบ้านเอง-vs-บริษัทรับสร้างบ้าน` → `/สร้างบ้านเอง-vs-บริษัทรับ/`
    - `/สร้างบ้าน-2-ชั้น-งบ-5-ล้าน` → `/งบ-5-ล้านบาท-สร้างได้ขนาด/`
  - **3 category 404s** → WP Admin ยืนยันทั้ง 3 category มี Parent = None แล้ว:
    - `งบสร้างบ้าน` (ID=10) — เปลี่ยน parent → None (session นี้)
    - `รับสร้างบ้าน` (ID=12) — Parent = None อยู่แล้ว ✅
    - `แบบบ้าน` — category มีอยู่แล้ว, Parent = None, slug = แบบบ้าน ✅
  - Root cause: WP Blog Runner AI generate category URL โดยเดา slug แทนใช้ URL จริง → ต้อง inject category URL map ใน Topic Engine PRO prompt (long-term fix)
  - File: `D:\ARCHI\03_DOCUMENTS\finnhouses-htaccess-404-fix-jun11.txt`

### ✅ Done (Jun 12, 2026) — session 10
- ✅ **FB Publish 401 fix** — เพิ่ม `x-hub-token: process.env.HUB_SECRET` ใน `/app/api/fb/publish/route.ts` — commit `b129bf1` — pushed & Vercel deploying
  - Root cause: route เรียก FB Backend โดยตรง (bypass Hub) แต่ไม่มี x-hub-token ที่ FB Backend's auth middleware require
- ✅ **ลาดหลุมแก้ว Landing Page** — HTML file `ladlumkaeo-landing.html` สร้างแล้ว — SEO long-form ~1,500 คำ, 4 H2 sections + FAQ + CTA → paste เข้า WP
- ✅ **WF1 Article Gen Keyword Lock fix** — แก้ไข 2 bugs ใน WF1:
  - Bug 1: `CATEGORY_URL_MAP` ถูกใช้แต่ไม่ได้ define ใน Topic Engine PRO → เพิ่ม const ที่หายไป
  - Bug 2: Article Gen prompt มี category mapping table ทำให้ GPT remap content → category เอง → เขียนบทความผิดหัวข้อ → แทนด้วย KEYWORD LOCK + ABSOLUTE category rule
  - File: `WF1_fixed_keyword_lock.json` → import to n8n แทนเวอร์ชันเก่า (WF2 ไม่ต้องแก้)

### ✅ Done (Jun 28, 2026) — session 13 — QC Calibration + WF1 Fix

**QC AI ประเมินผิด (false positive บนคอนกรีตโครงสร้าง):**
- ✅ **วิเคราะห์รูปจาก `D:\Finnhouses brand\งานคอนกรีต\`** — ยืนยันว่า texture ขรุขระจากแบบไม้ = ลักษณะปกติ ไม่ใช่ defect
- ✅ **แก้ `QC_SYSTEM_PROMPT` ใน `server.cjs` (v1 Railway)** — เพิ่มการแยก 3 ประเภทคอนกรีต:
  - A) โครงสร้าง (ฐานราก/เสา) — ผิวขรุขระ/รอยแบบ = ปกติ; defect = Honeycombing ≥1cm
  - B) พื้น/ทางเดิน — ผิวขรุขระ = defect
  - C) Pre-pour — ตรวจเหล็ก+แบบหล่อ ไม่ใช่ผิวคอนกรีต + Rule 8: benefit of doubt
- ✅ **แก้ `QC_PROMPT` ใน `QcUseCase.ts` (v2 Hub)** — calibration เดียวกัน (ใช้ตอน deploy v2)
- ✅ **git push origin main** → Railway auto-deploy → QC_SYSTEM_PROMPT v1 live แล้ว
- ✅ **WF1_fixed_keyword_lock.json** — ย้ายจาก `CORE/threme web/finnhouses-theme/` → `memory/n8n-workflows/`

**Pending หลัง session 13:**
- [ ] **Import WF1_fixed_keyword_lock.json เข้า n8n** — n8n → "Finnhouses WF1" → ... → Import from file → `D:\ARCHI\01_PROJECTS\memory\n8n-workflows\WF1_fixed_keyword_lock.json` → Save → Activate
- [ ] **Verify QC fix** — ส่งรูปคอนกรีตโครงสร้างจาก LINE OA → ตรวจว่า score ≥80 ไม่มี "ผิวขรุขระ" เป็น defect
- [ ] **QC LINE end-to-end test** (ยังค้างจาก session 12) — import wf_qc_line_hardcoded.json v8 → Activate → ส่งรูปทดสอบ

---

### ✅ Done (Jun 26, 2026) — session 12 — QC LINE System

**เป้าหมาย:** LINE OA → n8n → Supabase Storage → Hub /api/qc/ingest → GPT-4o Vision → LINE reply ภาษาไทย

**สิ่งที่แก้สำเร็จวันนี้:**
- ✅ **401 Download Image from LINE** — LINE channel access token หมดอายุ → ขอ token ใหม่จาก LINE Developers Console → update workflow
- ✅ **415 Upload to Supabase Storage** — n8n ส่ง `Content-Type: application/octet-stream` default → Supabase ไม่รับ → hardcode `Content-Type: image/jpeg` ใน Upload node
- ✅ **จัดเก็บ env vars ลงเครื่อง** — บันทึกครบทั้ง 3 services: `backend-hub/.env`, `memory/secrets/n8n.env`, `memory/secrets/fb-backend.env`
- ✅ **Root cause ของ 400 POST Hub** — `express.json()` ต้องรับ `Content-Type: application/json` เท่านั้น แต่ n8n HTTP Request v4 ที่ใช้ `specifyBody:"keypairs"` + `bodyContentType:"json"` ส่ง Content-Type ผิดหรือไม่ส่ง → `req.body = {}` → 400
- ✅ **เขียน wf_qc_line_hardcoded.json v5** — แทน 3 HTTP POST nodes ด้วย Function nodes (raw Node.js `https`) ไม่มี n8n body quirks
  - `memory/qc-line-system/02-n8n/wf_qc_line_hardcoded.json`

**🔴 พรุ่งนี้เช้า — ทำก่อนอื่น:**
1. n8n → ลบ workflow `wf_qc_line` เดิมออก
2. Import `wf_qc_line_hardcoded.json` v5 ใหม่
3. Activate workflow
4. ส่งรูปจาก LINE OA → ดู execution log ทีละ node
5. ถ้า POST Hub ผ่าน → QC Line ทำงาน end-to-end ✅

**เหลือ (หลัง session 12):**
- [ ] Full end-to-end test หลัง import v5
- [ ] Phase 2: Switch GPT-4o → Gemini (ลด cost)
- [ ] FB_PAGE_ACCESS_TOKEN renew (Aug 2, 2026)

---

### ✅ Done (Jun 26, 2026) — session 11 — n8n Cost Optimization
- ✅ **Switch n8n EXECUTIONS_MODE** → `own` (จาก `queue`) ใน Railway Primary env vars
- ✅ **ลบ Worker service** — Railway → optimistic-light project → Worker service deleted
- ✅ **ลบ Redis service** — Railway → optimistic-light project → Redis service deleted
- ✅ **ทดสอบ CRM Note Parser** — Execute workflow → ทุก node ✅ items flow ครบ
- ✅ **ผลประหยัด** — ~$2-3/month (ไม่มี Worker + Redis compute อีกต่อไป)
- ✅ **$env ใช้งานได้** — Code nodes ใน own mode เข้า `$env.*` ได้โดยตรง (ไม่ต้อง hardcode key)
- ✅ **อัพเดท CLAUDE.md** — Railway n8n Architecture section แก้ให้ตรงกับ own mode

### ✅ Done (Jun 26, 2026) — session 11 (cont.)
- ✅ **System Health Check workflow** — health-check-v2.json, 4 nodes (Schedule→Supabase→Code→Telegram), ทำงานแล้ว ✅
  - URL: `hub_state?key=eq.default&select=value` → parse `value.fb.queue`
  - File: `memory/platform-docs/health-check-v2.json`
- ✅ **Import WF1_fixed_keyword_lock.json** → activate แล้ว
- ✅ **ทดสอบ FB Publish** ✅
- ✅ **Publish ลาดหลุมแก้ว page ใน WP** ✅
- ✅ **สร้าง WP page** slug=`contact` ✅
- ✅ **Ahrefs crawl** — เช็ค Health Score ✅

### ⏰ ยังไม่ถึงเวลา
- [ ] **FB Token renew** — หมดอายุ **Aug 2, 2026** (~36 วัน) → renew ผ่าน Graph API Explorer → easygoing-friendship `FB_PAGE_ACCESS_TOKEN`

### 🟢 เหลืออยู่ (เริ่มตรงนี้)
- [ ] **กรอกฟอร์ม Market Intelligence** Section 1.3 (ลูกค้าเหนื่อย), 7.1 (Unwritten Rules), Section 8
- ✅ **Fix .env.local + Vercel SUPABASE vars** — เพิ่ม `SUPABASE_URL` + `SUPABASE_SERVICE_KEY` ทั้ง local และ Vercel → Redeployed ✅ (Market Intel tab ใช้ service_role key แล้ว)
- [ ] **Phase 2: Gemini** เป็น primary image model (ลดค่า OpenAI)

---

## ✅ Done Today (Jun 5, 2026)

### Platform Audit & Security (Phase A):
- ✅ **4 Audit docs** สร้าง: PROJECT_AUDIT.md, SECURITY_AUDIT.md, ARCHITECTURE_V2.md, IMPLEMENTATION_PLAN.md → `D:\ARCHI\01_PROJECTS\CORE\ap-home-platform\`
- ✅ **Intelligence Loop Roadmap** — 4 BU × 7 Intelligence Layers — Phase 1–5 วาง
- ✅ **Phase A Security** deployed:
  - next.config.ts: `allowedOrigins: ["*"]` → production domains
  - 13 Vercel→Hub proxy routes: เพิ่ม `x-hub-token` header ทุก route
  - market-intel route: hardcoded URL → env var `N8N_MARKET_INTEL_WEBHOOK`
  - MarketIntel.tsx: `/api/market-intel/submit` → `/api/market-intel` (consolidate)
  - Supabase RLS: all 13 tables enabled (applied via MCP migration)
  - 3 stale n8n workflows archived → `memory/archive/n8n/`
- ✅ **HUB_SECRET + N8N_MARKET_INTEL_WEBHOOK** set ใน Vercel
- ✅ Hub server.cjs (local) — มี CORS fix + X-Hub-Token auth + Supabase state แล้ว (ยังไม่ deploy)

### n8n WF1 Bug Fix (partial):
- ✅ **Topic Engine PRO** — เพิ่ม manual override logic + category mapping 33/34/35/36
  - Import เข้า n8n แล้ว: workflow "Finnhouses WF1 — Article + Publish"
  - File: `memory/n8n-workflows/Finnhouses_WF1_Article_Publish.json` (อัพเดทแล้ว)
- ❌ **Build Schedule Context ยังไม่แก้** — root cause จริงที่ทำให้ keyword หาย (ดู decisions.md)
  - ต้องแก้ node นี้ใน n8n โดยตรง (ไม่ต้อง import ไฟล์)

---

## ✅ Done Today (Jun 4, 2026)

### Code Fixes (รอ deploy):
- ✅ `DashboardOS.tsx` — BizCard counts: `??` → `||` (empty string business_unit fallback to "build")
- ✅ `budget/page.tsx` — intent → business_unit map: renovate→reno, buy→list, build→build
- ✅ `Marketing.tsx` — KEYWORD_POOLS keys แก้ให้ตรง WP category IDs จริง: 14→33, 15→34, 16→35, 17→36
- ✅ `.bat` files: push-fix-bizcards.bat + push-fix-blog-categories.bat สร้างแล้ว

### WordPress (deployed):
- ✅ `footer.php` — ลบ 5 broken footer links (build-house, list-property, house-plans, portfolio, mortgage-calculator) → upload cPanel แล้ว
  - **Root cause ของ 1,428 broken link rows** = footer ทุกหน้า ไม่ใช่ WP menu
- ✅ **Yoast SEO** installed → Meta desc + OG + Twitter card auto-generated ทุกหน้า
- ✅ **WP Categories** สร้างใหม่ 4 อัน: ที่ดิน (ID=33), รีโนเวทเพื่อขาย (34), ราคารายโซน (35), ฝากขาย (36)
- ✅ **Comment Moderation** — Manual approve + Auto-close 90 วัน + Spam 4 รายการลบแล้ว

### Supabase:
- ✅ **content_frames table** สร้างแล้ว (RLS disabled)

### n8n:
- ✅ **Market Intelligence Collector v1** — เพิ่ม node "💾 Supabase: content_frames" ระหว่าง Claude Generate → Telegram
  - Import + Publish แล้ว (deactivate เวอร์ชันเก่าก่อน)
  - หลังจากนี้ทุกครั้งที่บันทึก Market Intel → Tab "Positioned Content" จะมีข้อมูล

### SEO Analysis:
- Ahrefs Jun 2 crawl: Health Score **22/100** (Weak)
- Root cause: footer.php 5 broken links → 1,428 rows (77% ของ errors)
- ประมาณการ Jun 9: **55-65** หลัง footer fix + Yoast

---

## WP Category ID Map (สำคัญ — ห้ามลืม)
| KEYWORD_POOLS key | WP Category | WP ID |
|-----------------|-------------|-------|
| 10 | งบสร้างบ้าน | 10 |
| 12 | รับสร้างบ้าน | 12 |
| 13 | วัสดุก่อสร้าง | 13 |
| 33 | ที่ดิน | 33 |
| 34 | รีโนเวทเพื่อขาย | 34 |
| 35 | ราคารายโซน | 35 |
| 36 | ฝากขาย | 36 |

---

## Strategic Roadmap

### Phase 1 — Stabilize Core Engine ✅ COMPLETE
### Phase 2 — Build Proprietary Data Advantage 🟡 ~30% (Jun 4)
- ✅ buyer_profiles, area_memory (4), buyer_context_signals (5) — Supabase
- ✅ content_frames table + n8n save node — Positioned Content tab พร้อมใช้
- ✅ BRAND_FACTS update (buyer intelligence)
- [ ] Market Intel Form sections ที่เหลือ (1.3, 7.1, 8)
- [ ] CRM note → auto-parse → buyer_context_signals

### Phase 3 — Intelligence Loop 🟢 FUTURE

---

## WordPress Theme — Quick Reference
| ต้องการแก้ | ไฟล์ local | Upload ไปที่ |
|-----------|-----------|-------------|
| Footer links | `finnhouses-theme/footer.php` | `public_html/.../footer.php` |
| Blog layout/sidebar | `finnhouses-theme/single.php` | `public_html/.../single.php` |
| Property detail/gallery | `finnhouses-theme/single-property.php` | `public_html/.../single-property.php` |
| Homepage | `finnhouses-theme/front-page.php` | `public_html/.../front-page.php` |
| WP REST endpoint / CPT | `finnhouses-theme/functions.php` | `public_html/.../functions.php` |
- Upload ผ่าน cPanel File Manager เสมอ (ไม่มี FTP)

---

## Reference
- Stack, rules, deployed history → `CLAUDE.md`
- Credentials & FB Token → `tokens.md`
- Architecture decisions → `decisions.md`
- Brand voice → `Finnhouses_Brand_Messaging_3T.md`
- Market Intelligence Form → `Finnhouses Market Intelligence Memory Form v1-e356cfea.docx`
