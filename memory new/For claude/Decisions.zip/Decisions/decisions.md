# decisions.md — Finnhouses Platform
*บันทึกว่า "ทำไมถึงเลือกแบบนี้" — อ่านก่อน suggest alternative ใดๆ*

---

## 🔴 กฎบังคับ — Pre-Task Assessment (Jun 26)

**ทุกครั้งก่อนเริ่มงานใดๆ Claude ต้องประเมิน 3 อย่างนี้ก่อนเสมอ:**

| มิติ | ต้องประเมิน |
|------|------------|
| ⏱ ระยะเวลา | งานนี้ใช้เวลาประมาณกี่นาที/ชั่วโมง? มีขั้นตอนอะไรบ้าง? |
| ⚠️ ความเสี่ยง | อะไรผิดพลาดได้? side effect ต่อระบบอื่น? irreversible? |
| 💰 ค่าใช้จ่าย | มี API cost, token cost, ค่า Railway compute, หรือ Supabase storage ไหม? |

**รูปแบบที่ต้องแจ้งก่อนเริ่ม:**
> **ก่อนเริ่ม:** [งาน X] ใช้เวลา ~Y นาที | ความเสี่ยง: [Z] | ค่าใช้จ่าย: [W]

**ยกเว้น:** งานเล็กที่ชัดเจน (เช่น แก้ typo, อ่านไฟล์, ตอบคำถาม) ไม่ต้องทำ formal assessment — แต่ถ้างานมีหลายขั้นตอนหรือแตะ production ต้องทำเสมอ

---

## QC AI Assessment

### แยกคอนกรีตเป็น 3 ประเภท — QC_SYSTEM_PROMPT (Jun 28, 2026)
**ที่มา:** session 13 — QC ประเมินผิด flagging รูปคอนกรีตฐานราก (texture ขรุขระจากแบบไม้) เป็น "defect"
**Root cause:** prompt เดิมบอกแค่ "concrete = ตรวจความเรียบผิว" โดยไม่แยกว่าเป็นงานโครงสร้างหรือพื้น
**การแบ่งที่ถูกต้อง:**
- **A) คอนกรีตโครงสร้าง** (ฐานราก/ฟุตติ้ง/เสา/คานใต้ดิน): ผิวขรุขระ/รอยต่อแบบ/สีไม่สม่ำเสมอ = **ปกติ**; defect จริง = Honeycombing ≥1cm, รอยแตกขวางหน้าตัด
- **B) คอนกรีตพื้น/ทางเดิน**: ผิวขรุขระผิดปกติ = **defect** (ต้องการผิวเรียบ)
- **C) Pre-pour**: ตรวจเหล็ก+แบบ ไม่ใช่ผิวคอนกรีต; เหล็กสนิมแดงเล็กน้อย = ปกติ
**Rule 8 (benefit of doubt):** ถ้าไม่แน่ใจว่า defect หรือลักษณะปกติ → ให้เป็นปกติ
**Files แก้แล้ว:**
- `server.cjs` (v1 Railway) — QC_SYSTEM_PROMPT → deployed ผ่าน Railway auto-deploy (git push Jun 28)
- `QcUseCase.ts` (v2 Hub) — QC_PROMPT → ใช้ตอน deploy Hub v2 ใน future
**อย่าลืม:** v1 (`server.cjs`) คือสิ่งที่ n8n เรียกผ่าน Railway — v2 (`QcUseCase.ts`) ยังไม่ live จนกว่า Hub v2 จะ deploy

### QC_SYSTEM_PROMPT อยู่ที่ไหน (สำคัญ — v1 vs v2)
**v1 (LIVE บน Railway ผ่าน n8n):** `services/backend-hub/server.cjs` → ค้นหา `QC_SYSTEM_PROMPT`
**v2 (local dev / ยังไม่ deploy):** `services/backend-hub/src/modules/qc/QcUseCase.ts` → ค้นหา `QC_PROMPT`

### เริ่มต้น "self-improving loop" ที่ QC Line ก่อน ไม่ใช่ Market Intel (Jul 2, session 19d)
**บริบท:** user ถามว่าแพลตฟอร์มจะพัฒนาไปเป็น "AI-native Human-Centered Real Estate Intelligence Operating System" ยังไง — พบว่าทั้งระบบไม่มีกลไกเก็บ feedback ว่า AI ตัดสินถูกหรือผิดเลยสักจุดเดียว (generate อย่างเดียว ไม่เคย "เรียนรู้")
**ทางเลือกที่พิจารณา:** (1) QC Line — เพิ่มปุ่มยืนยันถูก/ผิดหลังผลตรวจ, (2) Market Intel — track ว่า content ที่ AI เสนอถูกเอาไปใช้จริงไหม/ผลตอบรับเป็นยังไง
**เลือก QC Line เพราะ:**
- ทดสอบ end-to-end ผ่านจริงแล้ววันเดียวกัน (session 19b) — มี momentum และ inspector ใช้งานสม่ำเสมอ
- ตัดสิน "ถูก/ผิด" ได้ตรงไปตรงมากว่า (ผนังแตกจริงไหม) ต่างจากโพสต์ FB ที่ต้องรอ engagement เป็นสัปดาห์
- ของเดิมรองรับพอดี (LINE Quick Reply ทำได้เลย ไม่ต้องสร้าง integration ใหม่) ต่างจาก Market Intel ที่ต้องต่อกับ FB Post Performance Tracker ก่อนถึงจะวัดผลได้
**Scope ที่ทำจริง (v1 ของ feedback loop):** แค่เก็บข้อมูลดิบ (`human_feedback: correct|incorrect` ต่อ inspection) — **ยังไม่ทำ** อะไรกับข้อมูลนี้ต่อ (ไม่ auto-retrain, ไม่มี dashboard สรุป % ความแม่นยำ) เจตนาให้เริ่มจากจุดเล็กที่สุดที่ยืนยันได้ว่า pipeline เก็บข้อมูลถูกต้องก่อน ค่อยต่อยอด
**Market Intel ยังไม่ได้ทำ:** เป็น candidate ที่ 2 สำหรับ feedback loop รอบต่อไป ถ้า QC Line ทำงานได้ดีและมีข้อมูลมากพอ

### Backfill content_frames: เขียนใหม่ vs กู้ของจริง (Jul 2, session 19e)
**บริบท:** หลังแก้บั๊ก column mismatch ที่ทำให้ `content_frames` ว่างเปล่ามาตลอด พบว่า Positioned Content ที่เคย generate จริง 27 ครั้งไม่เหลือร่องรอยใน DB เลย มีแค่ในข้อความ Telegram เก่า
**ทางเลือก:** (1) เขียนคอนเทนต์ใหม่จาก `market_insights` เดิม แล้ว insert ย้อนหลัง — เร็ว แต่ไม่ใช่ข้อความต้นฉบับ 100%; (2) ไปดึงข้อความจริงจาก Telegram/n8n execution history ทีละอัน — ได้ของจริง แต่ต้องเข้าไปเปิดดูเองทีละ execution (ไม่มี API access ให้ Claude ดึงอัตโนมัติ); (3) ไม่กู้คืน ปล่อยผ่าน
**user เลือก:** (1) เขียนใหม่ เพราะเร็วกว่ามาก และยอมรับได้ว่าเนื้อหาจะไม่ตรงกับต้นฉบับ 100%
**ทำยังไง:** เขียน FB post ใหม่ 26 โพสต์ (ข้าม 1 แถวที่ไม่มีข้อมูลจริงพอจะเขียนถึง) ตามกฎ system prompt เดียวกับที่ workflow ใช้จริง (ภาษาพูดธรรมชาติ ≤180 คำ, ตอบ fear/need, CTA 2 แบบ) แล้ว insert ผ่าน Supabase MCP โดยตั้ง `created_at` ให้ตรงกับวันที่ของ insight เดิม ไม่ใช่วันที่ backfill จริง — เพื่อให้ timeline ใน Dashboard ดูถูกต้อง
**ข้อจำกัดที่ต้องรู้:** ถ้าต้องการข้อความต้นฉบับจริง (ไม่ใช่เขียนใหม่) ต้องให้ user เปิด Telegram bot "Telegram Intel Bot" (chat_id 8589960853) เลื่อนดูประวัติเอง — Claude ไม่มีสิทธิ์เข้าถึง Telegram message history หรือ n8n execution log โดยตรงในเซสชันนี้
**กฎ:** แก้ QC behavior → ต้องแก้ `server.cjs` + push → ไม่ใช่แค่แก้ `QcUseCase.ts`

### qc_standards รองรับหลายรูปอ้างอิงต่อหมวด (Jul 2, session 19b)
**ที่มา:** ขยายรูปอ้างอิงจาก 4 หมวด (1 รูป/หมวด) เป็น 7 หมวด — พบว่าตาราง `qc_standards` มี `UNIQUE(category)` ล็อกไว้แค่ 1 แถว/หมวด ทั้งที่โค้ด `qcCallOpenAI()` ใน `server.cjs` ออกแบบมาให้ loop ผ่าน `refs.forEach()` รองรับหลายรูปต่อหมวดอยู่แล้ว
**การตัดสินใจ:** แก้ constraint เป็น `UNIQUE(category, photo_url)` แทน — อนุญาตหลายรูป/หมวด แต่กันรูปซ้ำเป๊ะในหมวดเดียวกัน
**ผลกระทบต้นทุน:** รูปอ้างอิงทุกรูปส่งด้วย `detail:"low"` (รูปงานจริงที่ตรวจใช้ `detail:"high"`) — เพิ่มรูปอ้างอิงหลายรูปไม่กระทบ token cost มาก
**Field `description` มีผลจริง:** ข้อความใน `qc_standards.description` ถูกแทรกเป็น text ก่อนรูปแต่ละรูปในพรอมต์ vision (`server.cjs:1941`) — เขียน description ให้เจาะจง/มีตัวเลขจริง (เช่น "cover block", "≥2.5 ซม.") มีผลโดยตรงต่อคำตอบ AI ไม่ใช่แค่ metadata เฉยๆ

### FB Queue ต้องเป็น manual เสมอ — ห้าม auto-post (Jul 2, session 19c)
**ที่มา:** user ชี้แจงว่าตั้งใจทำ AI Content Studio (FB) เป็น manual เพราะกลัว OpenAI token หมดเร็วจาก image gen — ตรวจแล้วพบว่า FB Queue templates (`FB_QUEUE_TEMPLATES`) เป็นข้อความตายตัว **ไม่ได้เรียก AI gen รูปจริง** แต่ user ยังคง**ต้องการให้ FB Queue เป็น manual อยู่ดี** (ไม่ใช่แค่เรื่อง token cost — เป็นเรื่องการควบคุมเนื้อหาโดยรวม)
**ผลคือ:** n8n workflow "Content Queue Weekly Builder" **v2 ที่เพิ่งสร้างและ import ไปก่อนหน้านี้ในเซสชันเดียวกัน ผิดจาก requirement จริง** เพราะ FB branch มัน auto-build+auto-post queue เองเมื่อ fb_queue ว่าง — ต้อง supersede ด้วย v3
**v3 ทำอะไรต่างจาก v2:** Blog branch เหมือนเดิม (auto-refill — เป็น cadence ที่ยอมรับอยู่แล้ว) / FB branch เปลี่ยนจาก "auto-generate + POST /api/fb/queue/build" เป็น **"ส่ง Telegram แจ้งเตือนอย่างเดียว"** (ใช้ pattern เดียวกับ health check bot — httpRequest ตรงไปที่ Telegram Bot API ไม่ต้องใช้ credential node) — user ต้องเข้า Dashboard กดปุ่ม "สร้าง Queue 7 วัน" เองเสมอ
**ไฟล์:** `memory/n8n-workflows/Content Queue Weekly Builder (3).json` — supersede (2)
**บทเรียน:** อย่าสรุปว่า "ไม่มี AI cost = โอเคที่จะ auto" — ต้องถามตรงๆ ว่า manual ที่ user หมายถึงคือขอบเขตไหนกันแน่ เพราะเหตุผลที่พูดออกมา (token cost) อาจไม่ใช่เหตุผลเดียวที่แท้จริง (ที่นี่คือ content control ด้วย)

### PowerShell script + Thai path ต้องมี UTF-8 BOM (Jul 2, session 19b)
**อาการ:** สคริปต์ `.ps1` ที่มี string literal เป็นภาษาไทย (เช่น path `D:\Finnhouses brand\งานคอนกรีต\...`) รันผ่าน `powershell.exe -File` แล้ว parse error ทั้งไฟล์ ("Unexpected token", "hash literal was incomplete") ทั้งที่ syntax ถูกต้อง
**Root cause:** ไฟล์ที่เขียนด้วย Write tool ได้ UTF-8 **ไม่มี BOM** — Windows PowerShell 5.1 (`powershell.exe`) ไม่มี BOM จะ fallback ไปอ่านด้วย system codepage (ไม่ใช่ UTF-8) → อักขระไทยกลายเป็นตัวอักษรมั่ว ทำให้ quote/brace ปิดผิดตำแหน่ง
**วิธีแก้:** prepend byte `\xEF\xBB\xBF` (UTF-8 BOM) ที่ต้นไฟล์ `.ps1` ทุกครั้งที่มีอักขระไทยอยู่ใน string literal
**กฎใหม่:** เขียน `.ps1` ที่มีภาษาไทยด้วย Write tool แล้ว **ต้องเติม BOM เองเสมอ** ก่อนส่งให้ user รัน — อย่าคิดว่า UTF-8 เฉยๆ พอ

---

## Frontend / CSS

### ห้ามใช้ `display:flex` บน `.blog-layout` (single.php)
**ทำไม:** WP plugins หลายตัว inject `display:flex !important` ซึ่ง override float ใน flex children ทำให้ sidebar ไม่ float right
**วิธีที่ใช้:** Float-only layout — `.blog-layout aside { float:right }` + `.blog-layout article { overflow:hidden }` (BFC)
**อย่าเปลี่ยน:** ถ้าเปลี่ยนกลับไป flex → sidebar จะพัง

### Gallery ใน single-property.php ใช้ flex ไม่ใช่ CSS Grid (May 27)
**ทำไม:** CSS Grid `grid-template-rows:1fr` ใน child div ไม่ inherit definite height จาก parent grid cell → รูป overflow และโดน clip
**วิธีที่ใช้:** Flex column บน right container + `height:520px` inline + `min-height:0` บนแต่ละรูป
**Key insight:** `min-height:0` override default `min-height:auto` ของ flex item ซึ่งเป็นต้นเหตุ overflow
**อย่าเปลี่ยน:** ห้าม revert กลับ `position:absolute;inset:0` หรือ nested grid

### height:520px ใส่เป็น inline style บน .gallery-main
**ทำไม:** CSS class `.gallery-main` บน server อาจมี height ต่างจากที่ expect หรือไม่มี `position:relative` → ทำให้ absolute child escape
**วิธีที่ใช้:** Inline style ทุก case — ไม่ depend on CSS class เลย

---

## Backend / API

### Server-side Proxy Pattern สำหรับทุก API call จาก browser
**ทำไม:** Browser ไม่สามารถ call Railway โดยตรงได้ (CORS block)
**วิธีที่ใช้:** browser → Vercel API route → Railway service
**อย่าเปลี่ยน:** ห้าม call Railway URL โดยตรงจาก client-side code

### ใช้ Page Token เสมอสำหรับ Facebook API (ไม่ใช่ User Token)
**ทำไม:** User Token หมดอายุเร็ว (~1 ชั่วโมง) และมี permission จำกัด
**ที่เก็บ:** Railway `easygoing-friendship` env var `FB_PAGE_TOKEN`
**หมดอายุ:** ทุก ~60 วัน → generate ใหม่จาก Graph API Explorer

---

## n8n

### WEBHOOK_URL ใน Railway n8n Primary ต้องเป็น base domain เท่านั้น
**ที่มา:** May 30, 2026 — WEBHOOK_URL ตั้งเป็น `.../webhook/blog-run` ทำให้ Telegram Trigger register webhook ผิด path เป็น `blog-run/webhook/finnhouses-telegram-intel-01/webhook` → 404 ทุก request จาก Telegram
**ค่าที่ถูกต้อง:** `https://primary-production-8158a.up.railway.app/` (trailing slash, ไม่มี path)
**อย่าเปลี่ยน:** ห้ามใส่ path suffix ใดๆ ใน WEBHOOK_URL เด็ดขาด
**Bot ที่ใช้กับ Telegram → Market Intel:** @AIfinnhousesbot (credential "Telegram account") — ไม่ใช่ bot ใหม่

### Telegram Trigger + n8n queue mode — การ debug
**วิธี diagnose:** เปิด URL `https://api.telegram.org/bot{TOKEN}/getWebhookInfo` → ดู `url` และ `last_error_message`
**วิธี set webhook ตรง:** `https://api.telegram.org/bot{TOKEN}/setWebhook?url={N8N_WEBHOOK_URL}`
**403 Forbidden:** มักแก้ได้ด้วย toggle Inactive→Active workflow ใน n8n เพื่อ force re-register
**ห้าม:** สร้าง bot ใหม่โดยไม่ตรวจ webhook info ก่อน

### n8n 2.21.4 block `$env.XXX` ใน node expressions
**ทำไม:** `EXECUTIONS_MODE=queue` — Code nodes รันบน Worker service (Railway container แยก) ซึ่งไม่ inherit flag `N8N_BLOCK_ENV_ACCESS_IN_NODE=false` จาก Primary service การ set env var บน Primary ไม่มีผลต่อ Worker
**Root cause ลึก:** แม้ set `N8N_RUNNERS_ENV_ALLOWLIST`, `N8N_RUNNERS_ENABLED=false`, `OFFLOAD_MANUAL_EXECUTIONS_TO_WORKERS=false` ก็ยังไม่แก้ปัญหาได้ — webhook executions ยังถูก route ไป Worker เสมอ
**วิธีที่ใช้:** Hardcode API keys โดยตรงใน Code node — ทั้ง `SUPABASE_SERVICE_KEY` และ URL
**Workflow ที่ใช้:** `memory/n8n-workflows/Finnhouses — Market Intelligence Collector v1 (hardcoded).json`
**n8n Variables ($vars):** ต้องการ paid plan — ไม่ใช่ option สำหรับ free tier
**ทางเลือก (ยังไม่ได้ทำ):** ใช้ n8n Credentials system + HTTP Request node แทน Code node

### n8n Code node ห้ามใช้ `fetch` — ใช้ `this.helpers.httpRequest()` เสมอ
**ที่มา:** Jun 7, 2026 — wf_crm_note_parser โยน `fetch is not defined [line 7]`
**Root cause:** n8n 2.21.4 task runner sandbox ไม่ expose `fetch`, `axios`, หรือ browser-like global HTTP APIs
**วิธีที่ใช้:**
```javascript
const result = await this.helpers.httpRequest({
  method: 'POST',
  url: 'https://api.example.com/endpoint',
  headers: { 'content-type': 'application/json', 'x-api-key': KEY },
  body: { key: 'value' },  // plain JS object — ไม่ต้อง JSON.stringify
  json: true               // auto-serialize body + auto-parse response
});
```
**สำคัญ:** `body` คือ JS object ตรงๆ (ไม่ใช่ string), `json: true` จัดการ serialization ให้ทั้งสองทาง
**อย่าเปลี่ยน:** ห้าม revert กลับ `fetch()` ใน Code node ใดๆ

### Telegram ใน n8n — ใช้ native node (ไม่ใช่ Code node + httpRequest)
**ที่มา:** Jun 7, 2026 — Code node เรียก Telegram API ตรงด้วย token จาก `.env.local` → 401 Unauthorized
**Root cause:** Bot token อาจทำงานผ่าน n8n credential system แต่ return 401 เมื่อใช้เป็น raw HTTP call
**Pattern ที่ถูกต้อง:** แยกเป็น 2 nodes เสมอ:
1. **Code node ("Build X Message")** — คำนวณ `{chat_id, message, parse_mode}` เท่านั้น ไม่ทำ HTTP
2. **Native Telegram node** (`n8n-nodes-base.telegram`) + credential `gmqmxxSq3X1Y6Ykr` ("Telegram account")
**Workflow ที่ใช้ pattern นี้:** wf_fb_post_performance_tracker · wf_crm_note_parser
**อย่าเปลี่ยน:** ห้ามรวม HTTP call เข้าไปใน Code node สำหรับ Telegram

### `alwaysOutputData: true` ต้องอยู่ top-level ของ node object
**ที่มา:** Jun 7, 2026 — wf_fb_post_performance_tracker: Supabase node คืน 0 rows → workflow หยุด
**Root cause:** `alwaysOutputData: true` ใส่ไว้ใน `parameters.options` แทนที่จะเป็น top-level → n8n ไม่อ่านค่า
**วิธีที่ถูกต้อง:**
```json
{
  "name": "Get Leads",
  "type": "n8n-nodes-base.supabase",
  "alwaysOutputData": true,   ← top-level
  "parameters": {
    "options": { ... }         ← ไม่ใส่ alwaysOutputData ไว้ที่นี่
  }
}
```
**อย่าเปลี่ยน:** เมื่อ node ต้องการ output data แม้ result ว่าง → ตรวจ top-level เสมอ

### FB Market Intelligence ไม่ activate schedule (manual run เท่านั้น)
**ทำไม:** Archi ตัดสินใจ run manual เพื่อ control quality และ cost
**อย่าเปลี่ยน:** ห้าม activate schedule trigger โดยไม่ถามก่อน

### n8n LINE Seller workflow — notes = full raw LINE text
**ทำไม (v6 fix):** GPT เคยถูก prompt ให้สรุป notes → ข้อมูล LINE หายไป
**วิธีที่ใช้:** `notes: lineData.text` เสมอ — ไม่ผ่าน GPT summary
**GPT ยังทำ:** extract title/price/location/bedrooms/bathrooms/area ตามปกติ

---

## Database (Supabase)

### RLS disabled บน fb_sellers, fb_listings, fb_listing_history
**ทำไม:** ไม่มี `SUPABASE_SERVICE_KEY` ใน env (มีแค่ anon key) + ไม่ต้องการ expose service key ใน n8n workflow
**ผลที่ตาม:** anon key ใช้ write ได้โดยตรง
**Risk:** tables เหล่านี้เปิด public — ยอมรับได้เพราะเป็น market data ไม่ใช่ข้อมูลลูกค้า
**อย่าเปิด RLS:** ถ้าจะเปิดต้องเพิ่ม policy ที่ allow anon insert ก่อน

### CRM stage names ห้ามเปลี่ยน
**ทำไม:** `new/followup/qualified/closed` ถูก hardcode ใน DashboardOS `useLeadCounts` และ CRM Kanban
**ถ้าจะเปลี่ยน:** ต้อง migrate data + อัพเดท code พร้อมกัน

---

## WordPress

### Upload ผ่าน cPanel เท่านั้น
**ทำไม:** ไม่มี FTP access, ไม่มี SSH, ไม่มี WP CLI
**วิธี:** cPanel File Manager → `public_html/wp-content/themes/finnhouses-theme/`
**OPcache:** PHP cache server-side → รอ 5 นาทีหลัง upload หรือ purge ใน cPanel

### `finn_gallery` = array ของ WP attachment IDs (ไม่ใช่ URLs)
**ทำไม:** WP best practice — URL เปลี่ยนได้ถ้า migrate server แต่ attachment ID ไม่เปลี่ยน
**ใช้:** `wp_get_attachment_url($id)` เพื่อแปลงเป็น URL ตอน render

---

## Content & Brand

### ห้ามใช้ "ลิงก์ใน Bio" และ "ปรึกษาฟรี" ใน Facebook copy
**ทำไม:** "ลิงก์ใน Bio" เป็น Instagram convention ไม่ใช่ FB / "ปรึกษาฟรี" ทำให้ดูถูกตลาด
**CTA ที่ใช้:** "ดูผลงานที่ finnhouses.com" และ "ทักมาปรึกษาเลย 0627946152"

---

---

## กฎการทำงานของ Claude (บังคับใช้ทุก session)

### ห้าม suggest action ใดๆ โดยไม่มีหลักฐานก่อน
**ที่มา:** May 30, 2026 — Claude แนะนำให้สร้าง Telegram bot ใหม่โดยเดาว่า bot เดิม conflict แต่ความจริงระบบทำงานได้ปกติ ทำให้เสียเวลา เสียเงิน เสีย token โดยเปล่าประโยชน์
**กฎ:** ก่อน suggest ให้ผู้ใช้ทำอะไร ต้องตรวจสอบให้มีหลักฐานก่อนเสมอ เช่น:
- อ่าน log / execution history ก่อนบอกว่า error
- เช็ค webhook info ก่อนบอกว่า conflict
- อ่านไฟล์จริงก่อนบอกว่าผิด
**ห้าม:** เดาสาเหตุแล้ว suggest action ใหญ่ (สร้างใหม่, ลบ, เปลี่ยน) โดยไม่มี evidence

### อัพเดท memory ทุกครั้งที่มีการเปลี่ยนแปลง
**ที่มา:** หลาย session ที่ผ่านมา Claude รับปากอัพเดท docs แต่ไม่ได้ทำ ทำให้ mindmap/flowchart/คู่มือล้าสมัย
**กฎ:** เมื่อ deploy หรือแก้ปัญหาสำเร็จ ต้องอัพเดท CLAUDE.md + HANDOFF.md ทันที และถามผู้ใช้ว่าต้องการอัพเดท mindmap/flowchart/คู่มือด้วยไหม

### LINE OA → Market Intel ยกเลิก — ใช้ Telegram แทน
**ที่มา:** May 31, 2026
**เหตุผล:** LINE OA ใช้ Telegram แทนได้ง่ายกว่า ไม่ต้องทำ routing ใน LINE Seller workflow
**ผลที่ตาม:** Intel input channel = Telegram เท่านั้น + Dashboard UI + AI Content tab

### Market Intel GPS = manual lat/lng fields (ไม่ใช่ browser geolocation)
**ที่มา:** May 31, 2026
**เหตุผล:** User ต้องการพิมพ์เองมากกว่าให้ browser detect อัตโนมัติ
**วิธีที่ใช้:** 2 input fields (Latitude, Longitude) — optional, ไม่บังคับ

### Hub withRetry — FB calls เท่านั้น (ไม่ใช่ทุก call)
**ที่มา:** May 31, 2026
**เหตุผล:** FB Backend อาจ timeout ชั่วคราว retry 2x/4s ช่วยได้ แต่ไม่ apply กับ n8n/WP เพราะ idempotency concerns
**ที่ใช้:** `/api/fb/publish` และ `/action/fb/queue/run-next`

### WF2 Analyze Roof Vision — ต้อง Continue on Error เสมอ
**ที่มา:** Jun 2, 2026 — OpenAI gpt-4o-mini vision API rate limit → WF2 crash ที่ "Analyze Roof Vision" → โพสต์ขึ้นแต่ไม่มีรูป
**วิธีที่ใช้:** `onError: continueRegularOutput` บน Analyze Roof Vision node + Parse Vision QA fallback = `{roof_ok:true, style_ok:true, needs_regeneration:false}`
**ผลลัพธ์:** Vision rate limit → bypass QA → รูปยังขึ้นได้ปกติ
**อย่าเปลี่ยน:** ห้ามตั้ง fallback กลับเป็น `roof_ok:false` — จะทำให้รูปไม่ขึ้นเมื่อ Vision rate limit

### FB Token ใน easygoing-friendship (ไม่ใช่ Hub)
**ที่มา:** Jun 2, 2026 — Token เก็บใน `easygoing-friendship` service → `FB_PAGE_ACCESS_TOKEN`
**ไม่ใช่:** `ap-home-platform` Hub service
**หมดอายุ:** Jun 26, 2026 → ต้อง renew ผ่าน Graph API Explorer → เลือก Finnhouses Page Token

### n8n WF1 — "Build Schedule Context" ต้อง pass webhook data ผ่านมาเสมอ
**ที่มา:** Jun 5, 2026 — Blog Runner ส่ง keyword/category มาถูกต้อง แต่บทความผิด category เพราะ node นี้ไม่ส่งต่อ
**Root cause:** Build Schedule Context สร้าง json ใหม่ทั้งหมด → `keyword`, `category`, `runId`, `visual_hint` จาก webhook หาย → Topic Engine PRO เห็น `ctx.keyword = undefined` → `isManual = false` → auto-rotation
**วิธีที่ใช้:** return object ต้องมี 4 fields นี้เสมอ:
```js
keyword:     $input.first().json.keyword     || '',
category:    $input.first().json.category    || 13,
runId:       $input.first().json.runId       || '',
visual_hint: $input.first().json.visual_hint || 'contemporary',
```
**อย่าลืม:** ทุกครั้งที่แก้ Build Schedule Context ต้อง verify ว่า 4 fields นี้ยังอยู่ใน return

### n8n — ต้อง inspect nodes จริงก่อน suggest แก้ workflow ใดๆ
**ที่มา:** Jun 5, 2026 — Claude suggest แก้ V3.2 FIXED แต่ workflow ที่ใช้จริงคือ WF1 + WF2 แยกกัน
**กฎ:** ก่อน suggest แก้ n8n workflow ใดๆ ต้อง:
1. `python3 -c "import json; wf=json.load(open(PATH)); print([n['name'] for n in wf['nodes']])"` list nodes จริง
2. ระบุ file + workflow name ที่จะแก้ก่อนเสมอ
**ห้าม:** assume จากชื่อไฟล์ว่า workflow นั้นยังใช้อยู่

### Finnhouses = Marketing Brand Only (ไม่ใช่ชื่อบริษัท)
**ที่มา:** Jun 5, 2026 — ยืนยันในการวาง roadmap
**บริษัท:** บจก.อาชิดา (Achida Co., Ltd.)
**Platform:** AP-Home Platform OS
**Brand:** Finnhouses — ใช้สำหรับ marketing และ website เท่านั้น
**อย่าเรียก:** Platform ว่า "Finnhouses Platform" — ชื่อที่ถูกต้องคือ "AP-Home Platform OS"

### ap-home-system-flow.html — SVG Orthogonal Routing
**ทำไม:** Bezier curve ที่ใช้ control point แบบ fraction ของ dx/dy สร้างเส้น diagonal ตัดข้ามหน้าจอ ดูไม่เป็น flow diagram
**วิธีที่ใช้:** 3-segment H→V→H routing พร้อม quadratic corner rounding (radius=min(10, adx*0.45, ady*0.45))
- เส้นแนวตั้งเกือบ: straight `V`
- เส้นแนวนอนเกือบ: straight `H`
- เส้นทแยง: `H midX → Q-bend → V → Q-bend → H b.x`
**Label:** วางบน vertical segment ที่ midpoint จริง (ไม่ใช่ linear midpoint)
**Arrowhead:** angle จาก direction ของ segment สุดท้าย (0° หรือ 180° สำหรับ H, ±90° สำหรับ V)

### AI Content 6 Tabs — per-tab step arrays (ไม่ใช่ monolithic steps[])
**ทำไม:** แต่ละ tab ใช้ service node ต่างกัน (keyword ใช้ OpenAI+Claude, history ใช้แค่ Supabase ฯลฯ) การรวม steps ทำให้ flow ไม่สื่อความหมาย
**วิธีที่ใช้:** `AIC_TAB_STEPS` object 6 keys → getter `get steps(){ return AIC_TAB_STEPS[activeTab] }` + `setAicTab()` reset flow เมื่อเปลี่ยน tab
**Panel HTML:** `AIC_TAB_PANELS` object แยก 6 key — render ใน `#aic-tab-body` เมื่อ click tab

### Market Intelligence Collector — bot @finnhouses_intel_bot ต้อง /start ก่อน
**ที่มา:** Jun 8, 2026 — Telegram node throw "Bad Request: chat not found" แม้ chatId ถูกต้อง
**Root cause:** Telegram bot ไม่สามารถ initiate conversation ได้ — user ต้อง /start ก่อนเสมอ
**วิธีแก้:** เปิด Telegram → search @finnhouses_intel_bot → กด Start
**บันทึก:** @finnhouses_intel_bot ตอนนี้ใช้สำหรับ Market Intel notifications (ไม่ใช่ @AIfinnhousesbot)

### n8n HTTP Request node v4 — ห้ามใช้ keypairs สำหรับ JSON POST ที่สำคัญ
**ที่มา:** Jun 26, 2026 — QC LINE System session 12
**ปัญหา:** HTTP Request node v4 ที่ตั้ง `specifyBody:"keypairs"` + `bodyContentType:"json"` อาจส่ง Content-Type ผิดหรือไม่ได้ส่ง → server ที่ใช้ `express.json()` ไม่ parse body → `req.body = {}` → 400 error
**Root cause จาก Hub server.cjs:** `app.use(express.json(...))` — parse เฉพาะ `Content-Type: application/json` เท่านั้น
**วิธีที่ใช้:** แทน HTTP Request node ด้วย **Function node + `require('https')`** (raw Node.js) สำหรับ JSON POST ทุก call ที่สำคัญ — ควบคุม Content-Type และ body ได้ 100%
**ใช้ใน:** POST Hub /api/qc/ingest, LINE Reply API, Log Latency (ทั้งหมดใน wf_qc_line v5)
**Pattern:**
```javascript
const https = require('https');
const bodyStr = JSON.stringify({...});
const result = await new Promise((resolve, reject) => {
  const req = https.request({
    hostname: '...', path: '/api/...', method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(bodyStr) }
  }, res => { let d=''; res.on('data',c=>d+=c); res.on('end',()=>resolve(JSON.parse(d))); });
  req.on('error', reject); req.write(bodyStr); req.end();
});
```
**อย่าเปลี่ยน:** ห้าม revert กลับ HTTP Request + keypairs สำหรับ endpoint ที่ใช้ `express.json()`

### n8n QC LINE — LINE Reply ต้องการ messages เป็น array (ไม่ใช่ string)
**ที่มา:** Jun 26, 2026
**ปัญหา:** HTTP Request keypairs mode แปลง value ทุกอันเป็น string — `messages: "[{...}]"` (string) ≠ `messages: [{...}]` (array) ที่ LINE API ต้องการ
**วิธีที่ใช้:** Function node สร้าง `messages: [{ type: 'text', text: String(p.text) }]` ตรงใน body object

---

## Hub v2 Migration + Git Hygiene (Jul 1, 2026)

### Migrate route ไป Hub v2 ต้องทำทั้งกลุ่ม endpoint พร้อมกัน (ไม่ใช่ทีละตัว) — และห้ามสลับ HUB_URL ก่อน verify
**ที่มา:** session 18 — `blog/queue/*` ถูกอัพเดทเป็น Hub v2 scheme (`/api/blog/queue/*` + `x-hub-secret`) แต่ `fb/queue/*` (3 endpoints) ตกหล่น ยังใช้ `/action/fb/queue/*` + `x-hub-token` เก่า → 404 ทันทีที่ `HUB_URL` ถูกเปลี่ยนไป Hub v2
**อัพเดท (หลัง debug ลึก):** แม้แก้ `fb/queue/*` ให้ตรง Hub v2 convention แล้ว (commit `e0692a3`) ก็ยัง 404 — เพราะ **Hub v2 ไม่มี route `/api/fb/queue/*` และ `/api/blog/queue/*` implement จริงเลยสักตัว** สรุปคือ Archi แก้โค้ด Vercel proxy ให้ชี้ path ใหม่ + สลับ `HUB_URL` ไป v2 ทั้งระบบ **ก่อน**ที่ Hub v2 backend จะมี route เหล่านี้จริง
**ทางแก้สุดท้าย (Jul 1):** revert ทั้ง 6 route กลับ Hub v1 convention + revert `HUB_URL` กลับ Hub v1 — verified ผ่าน n8n execution #720
**กฎ:**
1. เมื่อ migrate endpoint group ใดไป Hub v2 (fb/*, blog/*, property/*) ต้องแก้ **ทุก route ในกลุ่มพร้อมกันในคอมมิตเดียว** และ grep หา path/header เก่า (`/action/`, `x-hub-token`) ทั้ง repo ก่อนปิดงาน
2. **ห้ามเปลี่ยน `HUB_URL` ไปชี้ Hub v2 จนกว่าจะยิง request จริงทดสอบทุก route ที่ n8n/Dashboard เรียกใช้แล้วผ่านหมด** — `HUB_URL` กระทบทุก route พร้อมกัน จะ cutover ทีละ route ไม่ได้ด้วยวิธีเปลี่ยน env var ตัวเดียว (ต้องรอ Hub v2 มีครบทุก endpoint ก่อน หรือทำ per-route feature flag/fallback แทน)

### `.gitignore` ต้อง anchor ด้วย `/` เสมอถ้าหมายถึง root-only
**ที่มา:** session 18 — `build/` (ไม่มี `/` นำหน้า) ทำให้ Git ignore `app/api/fb/queue/build/route.ts` มาตั้งแต่สร้างไฟล์ — ไฟล์ไม่เคยขึ้น GitHub แม้ `git add` โฟลเดอร์แม่จะไม่ error (แค่ warning ที่มองข้ามง่าย)
**กฎ:** pattern ใน `.gitignore` ที่หมายถึง root-only (เช่น build output) ต้องขึ้นต้นด้วย `/` เสมอ (`/build/` ไม่ใช่ `build/`) — และก่อนเชื่อว่า `git push` ครบ ให้เช็ค `git status` + นับจำนวนไฟล์ใน commit message ให้ตรงกับที่ตั้งใจแก้จริง (ไม่ใช่แค่ exit code สำเร็จ)
**สถานะ:** ✅ แก้แล้ว — commits `e0692a3`, `1012ec3`

### Revert/migration ที่กระทบหลายไฟล์ ต้อง `git show --stat <commit>` ก่อนเชื่อว่า revert ครบ
**ที่มา:** session 18 (ต่อ) — revert Hub v2→v1 ตอนแรกทำแค่ 6 route queue files แต่คอมมิตต้นทาง (`a0aa978`) แก้ไปทั้งหมด 7 จุดใน `app/`, ไฟล์ที่ 7 (`blog/state/route.ts`) หลุดไป ยังส่ง `x-hub-secret` ทิ้งไว้ — ค้นพบตอนทำ full-repo grep audit หลังผู้ใช้ถาม "มั่นใจได้ยังไงว่าทุก module กลับมาทำงาน"
**กฎ:** เมื่อจะ revert ผลจาก commit ใดๆ ให้ `git show --stat <commit hash>` ดูรายชื่อไฟล์ทั้งหมดก่อนเสมอ อย่า revert แค่ไฟล์ที่จำได้/คิดว่าเกี่ยวข้อง — และหลัง fix เสร็จให้ grep ทั้ง repo หา pattern เก่า (เช่น header/path convention) เพื่อยืนยันว่าไม่มีไฟล์ตกหล่นอีก
**Commit:** `56ab7f5`
**สถานะ:** ✅ แก้แล้ว — audit ยืนยันไม่มีไฟล์อื่นหลุด — รอ verify runtime จริง (Dashboard blog status card)

---

## AI Team Governance (Jun 28, 2026)

### AI_TEAM.md คือ Engineering Constitution — อ่านก่อนเสมอ
**ที่มา:** session 14 — สร้างจาก brief ของ Archi + ผ่าน Architecture Governor (ChatGPT) review
**ไฟล์:** `CORE/ap-home-platform/docs/AI_TEAM.md` (v1.1.0)
**กฎสำคัญที่เพิ่มใหม่:**
- **Knowledge OS เป็น first-class component** — memory/ + docs/ คือสมองของระบบ ต้องอัพเดททุก session
- **AI Provider เลือกที่ Hub เท่านั้น** — ห้าม import openai/gemini ตรงใน Use Case — ต้องใช้ `IAiProvider` port
- **ADR บังคับ** เมื่อเปลี่ยน Architecture / AI Provider / Database / Auth / Event Model / Security / Public API
- **Observability บังคับ** ทุก production service — Metrics, Tracing, Audit, AI Cost, Performance, Monitoring
- **Service Registry** — ทุก module ต้อง register ผ่าน Hub ห้าม hidden dependency
**ADR Template:** `CORE/ap-home-platform/docs/ADR/0000-template.md`

### Provider Routing Policy (Jun 28, 2026 — confirmed)
| Task | Primary | Fallback |
|------|---------|---------|
| Reasoning | Claude Sonnet | GPT-4o |
| Vision/QC | GPT-4o Vision | Gemini Vision |
| Embedding | OpenAI text-embedding-3-small | — |
| Translation/Thai | Gemini | GPT-4o |
| Content gen | GPT-4o | Claude Sonnet |

**กฎ:** เปลี่ยน provider → ต้องทำ ADR ก่อน — ห้ามเปลี่ยนโดยไม่มีเอกสาร

---

## Blog Runner — WF1 Publish Guard (Jul 13, 2026, session 24)

### Fallback value ต้องเช็คกับทุก validation ที่อยู่ downstream เสมอ ไม่ใช่แค่ "กัน undefined"
**ที่มา:** Blog Runner ค้าง "running" 11+ ชั่วโมง — root cause คือ node "Edit Fields" มี fallback `article_slug = ... || 'post'` เวลา AI model ไม่คืนค่า slug มา แต่ node "Publish Guard" เช็คว่า slug ต้องยาว ≥6 ตัวอักษรถึงผ่าน — "post" มีแค่ 4 ตัว **ไม่มีทางผ่านได้เลย** เป็น fallback ที่ตั้งไว้ "กันพัง" แต่จริงๆ รับประกันว่าจะพังทุกครั้งที่ใช้งาน
**บทเรียน:** เวลาตั้ง default/fallback value ต้องไล่เช็คว่ามี validation/guard ตัวไหนอยู่ downstream บ้าง แล้วเทียบว่า fallback ผ่านเกณฑ์นั้นจริงไหม — ไม่ใช่แค่คิดว่า "มีค่าอะไรสักอย่างดีกว่า undefined"
**การแก้ที่ใช้:** เปลี่ยนเป็น fallback chain — ลองค่าจากโมเดลก่อน → ถ้าไม่ผ่านเกณฑ์ลอง derive จาก title → ถ้ายังไม่ผ่านอีก fallback เป็นค่าที่การันตีผ่านเกณฑ์เสมอ (เช่น `post-<timestamp>` ที่ยาวเกิน 6 ตัวแน่นอน)

### ทุก branch ที่จบ workflow แบบไม่ publish ต้อง callback กลับ Hub เสมอ — ห้ามจบเงียบ
**ที่มา:** เดียวกับข้างบน — เมื่อ Publish Guard บล็อก workflow เดินไปจบที่ node "Blocked Log" ซึ่งแค่ log ข้อมูลไว้ในตัว execution เอง ไม่มี HTTP call ไปไหนเลย ทำให้ Hub ไม่รู้ว่า run นี้จบแล้ว (ไม่ว่าจะสำเร็จหรือล้มเหลว) — `state.blog`/`content_queue` เลยค้าง "running" ตลอดไปจนกว่า Health Check cron จะแจ้งเตือน (ค้างไป 11+ ชม.ก่อนมีคนสังเกต)
**รูปแบบเดิมที่เจอปัญหาคล้ายกัน:** `content_frames` insert fail เงียบๆ (session 19e) — try/catch ที่แค่ log ไม่ throw/notify ต่อ
**กฎที่ใช้แก้:** ทุก node ที่เป็น "จุดจบ" ของ workflow (ไม่ว่า path ไหน — published, blocked, error, skipped) ต้อง callback กลับ Hub เสมอเพื่อ unstick state — เพิ่ม node "Notify Hub Blocked" (status:"failed") ต่อจาก Blocked Log ให้ตรงกับ pattern เดียวกับ "Notify Hub Published"
**ผลข้างเคียงที่พบเพิ่ม:** "Notify Hub Published" (path สำเร็จ) เองก็ไม่ได้ส่ง `queue_item_id` — ทำให้ `content_queue` item ที่ publish สำเร็จจริงก็ค้างโชว์ "running" เหมือนกัน (แก้พร้อมกันในรอบเดียว)
**ไฟล์:** `memory/n8n-workflows/Finnhouses WF1 — Article + Publish (9_queue_sync_fix).json`
**ดู:** `docs/issues-log.md` ISSUE-012

### Dashboard "Manual Reset" ปุ่มแก้แค่ `state.blog` ไม่ sync กับ `content_queue` item
**ที่มา:** เดียวกับข้างบน — user กดปุ่ม Manual Reset แล้ว `state.blog.status` เปลี่ยนเป็น "idle" ถูกต้อง แต่ item ที่ตรงกันใน `content_queue` array ยังค้าง `status:"running"` เหมือนเดิม (คนละ object กัน ปุ่มนี้ไม่ได้เขียนพร้อมกันทั้งคู่)
**วิธีแก้ชั่วคราวที่ใช้:** Claude แก้ `content_queue` item ตรงผ่าน Supabase MCP `execute_sql` (match ด้วย `id` แล้ว `jsonb_set` เฉพาะ element นั้น) แทนการรอ fix ปุ่มในโค้ด
**ยังไม่แก้ที่ต้นเหตุ:** ปุ่ม Manual Reset ใน Dashboard ควร sync ทั้ง 2 ที่พร้อมกัน — ยังไม่ได้ทำในรอบนี้ (งานค้างสำหรับ session ถัดไปถ้าจะแก้ถาวร)

---

## ADR-005 — Market Intelligence Collector v2: 9-signal schema (Jul 7-8, 2026, session 22)

**สรุปสั้น** (รายละเอียดเต็ม → `CORE/ap-home-platform/docs/decisions.md` ADR-005): เพิ่ม `signals JSONB` (9 keys — 8 มาจาก Claude Haiku ต่อโพสต์ + `liquidity` ที่บังคับด้วยโค้ดเสมอ ไม่ใช่ LLM), `positioned_content`, `ai_summary`, `collector_version` ใน `content_frames` — deploy ผ่าน dry run (test path, เจอ+แก้ 3 บั๊ก: native Supabase node แทน Code node ที่ `getCredentials()`/`$env` ใช้ไม่ได้, category whitelist, confidence clamp) → production cutover (v2 แทน v1(2), webhook path เดิม, 15/15 smoke test PASS) → เจอบั๊กจริงวันเดียวกัน (Claude Haiku ตอบยาวเกิน `maxTokens:1600` บนโพสต์ละเอียด → JSON ตัดกลางคำ → แก้เป็น 3000)

**บทเรียนสำคัญ:** mocked test ไม่เคยสร้าง output ยาว/ซับซ้อนพอชนขอบ token limit จริง — ต้อง dry run ด้วย real model call ก่อน cutover เสมอ และ monitor organic traffic ต่ออีกสักพักหลัง cutover ไม่ใช่แค่ smoke test เอง

**Files:** `memory/n8n-workflows/Finnhouses — Market Intelligence Collector v2 (ADR-005).json`, `CORE/ap-home-platform/docs/issues-log.md` ISSUE-010, `CORE/ap-home-platform/docs/ADR/2026-07-08-market-intel-v2-*.md`

*Last updated: Jul 13, 2026 (session 24)*
